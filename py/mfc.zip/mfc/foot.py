"""Two-segment foot model anchored by FSR stance.

While any part of the foot is on the floor it is stationary, so
p_sensor = p_contact - R(q) r_contact and nothing is integrated. The
accelerometer is integrated only in swing. Ref: "Foot model" in
docs/mfc_processing_reference.md.

Foot frame: x forward (heel to toe), y left, z up out of the sole, origin at
the heel contact point; up comes from gravity at R (shoe flat on the floor).
Segment 2 (ball to heel, L2) carries the IMU; segment 1 (toe tip to ball, L1)
is either in line with it or flat on the floor.

position and velocity are owned by the Processor and passed through step().
"""

import math

import numpy as np

from . import config as cfg
from .mathutil import rotate_about

Z_UP = np.array([0.0, 0.0, 1.0])


def foot_points(r, L1, C, rot, pos, state, toe_dir, mtp0, lift_t, t):
    """World heel, ball and toe tip for a sensor at pos with attitude rot. The
    toe is flat along toe_dir in toe contact, relaxes its lift-off ball-joint
    angle mtp0 (display only) in swing, and is rigid otherwise. A pure function
    of its arguments so the offline swing code draws the very same foot."""
    heel = pos + rot @ r["heel"]
    ball = pos + rot @ r["ball"]
    if state == "toe":
        toe = ball + L1 * toe_dir
    elif state == "swing" and mtp0 and lift_t is not None and cfg.FOOT_MTP_RELAX_S > 0:
        ang = mtp0 * math.exp(-(t - lift_t) / cfg.FOOT_MTP_RELAX_S)
        rear = rot @ C[:, 0]
        toe = ball + L1 * rotate_about(rear, rot @ C[:, 1], ang)
    else:
        toe = pos + rot @ r["toe"]
    return heel, ball, toe


class FootModel:
    def __init__(self, cal, stance):
        self.cal = cal                       # segment lengths
        self.stance = stance                 # for the onset-stamped lookup
        self.up_b = np.array(cfg.FOOT_UP_BODY, dtype=float)
        self.C = np.eye(3)                   # foot frame to body frame
        self.r = {}                          # lever arms, body frame, sensor to point
        self.ground_z = None                 # world z of the floor, from R
        self.toe_dir = np.array([1.0, 0.0, 0.0])   # toe segment direction while flat
        self.mtp0 = 0.0                      # signed ball-joint angle at lift-off, rad
        self.lift_t = None
        self.pitch = 0.0                     # rear segment against the ground, deg
        self.mtp = 0.0                       # toe segment against the rear, deg
        self.toe_clear = 0.0                 # toe tip above the floor, m
        self.heel_clear = 0.0                # heel point above the floor, m
        self.reset()
        self.build()

    # -- frame and lever arms ------------------------------------------------
    @staticmethod
    def _flip():
        """FOOT_MODEL_FLIP_DEG as a rotation in foot coordinates."""
        ax, ay, az = (math.radians(a) for a in cfg.FOOT_MODEL_FLIP_DEG)
        cx, sx = math.cos(ax), math.sin(ax)
        cy, sy = math.cos(ay), math.sin(ay)
        cz, sz = math.cos(az), math.sin(az)
        rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
        ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
        rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
        return np.round(rz @ ry @ rx, 12)           # exact for multiples of 90

    @staticmethod
    def _frame(fwd_body, up, warn=True):
        """Columns forward, left, up of the foot, in sensor axes, before the flip."""
        fwd = np.asarray(fwd_body, dtype=float)
        fwd = fwd / float(np.linalg.norm(fwd))
        fwd = fwd - float(fwd @ up) * up            # into the sole plane
        if float(np.linalg.norm(fwd)) < 0.30:
            if warn:
                print("[foot] FOOT_FORWARD_BODY points almost straight up with the "
                      "shoe flat, so it cannot be the heel-to-toe axis. Using a "
                      "placeholder until it is set.")
            fwd = np.cross(up, [1.0, 0.0, 0.0] if abs(up[0]) < 0.9 else [0.0, 1.0, 0.0])
        fwd = fwd / float(np.linalg.norm(fwd))
        return np.column_stack((fwd, np.cross(up, fwd), up))

    def build(self, up_b=None):
        """Foot frame and every lever arm from the sensor to the heel, ball and
        toe tip. Rebuilt at R, when gravity says which way the sole faces."""
        if up_b is not None:
            self.up_b = np.asarray(up_b, dtype=float) / float(np.linalg.norm(up_b))
        self.C = self._frame(cfg.FOOT_FORWARD_BODY, self.up_b) @ self._flip()
        L1, L2 = self.cal.foot_L1, self.cal.foot_L2
        sensor = np.array([cfg.IMU_FROM_HEEL_M, cfg.IMU_LATERAL_M, cfg.IMU_ABOVE_SOLE_M])
        points = {"heel": (0.0, 0.0, 0.0),
                  "ball": (L2, 0.0, 0.0),
                  "toe": (L2 + L1, 0.0, 0.0)}
        self.r = {k: self.C @ (np.array(v) - sensor) for k, v in points.items()}

    def reset(self):
        self.state = None                    # stance the model is propagating
        self.anchor = None                   # world position of the anchored point
        self.pts = None                      # world heel, ball, toe tip, for drawing
        # The foot as the contact panel draws it: (state, (heel, ball, toe,
        # sensor)) in a footprint-fixed frame; holds the last contact in swing.
        self.contact_view = None
        self._axis_M = np.zeros((3, 3))      # rotation-axis scatter seen in contact
        self._axis_sign = np.zeros(3)        # net rotation seen in toe contact
        self._axis_rot = 0.0                 # degrees of contact rotation so far
        self._axis_done = False
        self.axis_msg = "forward axis not checked yet"

    def _on_ground(self, p):
        p = np.array(p, dtype=float)
        if cfg.FOOT_SNAP_TO_GROUND and self.ground_z is not None:
            p[2] = self.ground_z
        return p

    # -- propagation ---------------------------------------------------------
    def _enter(self, new, pos, vel, rot, t):
        """A contact change. Each anchor is taken from where the sensor is now,
        then put back on the floor, so the last phase's error is replaced here
        rather than carried on. Returns (pos, vel)."""
        old = self.state
        self.state = new
        if new == "heel":
            self.anchor = self._on_ground(pos + rot @ self.r["heel"])
        elif new == "toe":
            self.anchor = self._on_ground(pos + rot @ self.r["ball"])
            # The toe segment lies flat along the heading and stays there.
            fwd = rot @ self.C[:, 0]
            flat = np.array([fwd[0], fwd[1], 0.0])
            n = float(np.linalg.norm(flat))
            self.toe_dir = flat / n if n > 1e-6 else np.array([1.0, 0.0, 0.0])
        elif new == "flat":
            # From the toe the foot came down about the ball; otherwise the heel.
            key = "ball" if old == "toe" else "heel"
            self.anchor = self._on_ground(pos + rot @ self.r[key])
            pos = self.anchor - rot @ self.r[key]
            vel = np.zeros(3)
        elif new == "swing":
            # The ball-joint angle at lift-off is kept and relaxed (display only).
            self.lift_t = t
            self.mtp0 = 0.0
            if old == "toe" and self.pts is not None:
                heel, ball, toe = self.pts
                rear = (ball - heel) / self.cal.foot_L2
                front = (toe - ball) / self.cal.foot_L1
                left = rot @ self.C[:, 1]
                self.mtp0 = math.atan2(float(np.cross(rear, front) @ left),
                                       float(rear @ front))
        return pos, vel

    def step(self, t, dt, rot, omega_b, lin, pos, vel):
        """One IMU sample through the foot model. Returns (pos, vel)."""
        stance = self.stance.at(t)
        if stance not in ("heel", "toe", "flat", "swing"):
            stance = "swing"
        if stance != self.state:
            pos, vel = self._enter(stance, pos, vel, rot, t)

        if self.state in ("heel", "toe"):
            arm = rot @ self.r["heel" if self.state == "heel" else "ball"]
            pos = self.anchor - arm
            # d/dt (p_c - R r) with p_c fixed; keeps lift-off a velocity to start from.
            vel = -np.cross(rot @ omega_b, arm)
            self._axis_update(self.state, omega_b, dt)
        elif self.state == "flat":
            vel = np.zeros(3)
        else:
            vel = vel + lin * dt
            pos = pos + vel * dt
        self._geometry(rot, t, pos)
        return pos, vel

    def _geometry(self, rot, t, pos):
        """World heel, ball and toe tip, and the angles the model reports."""
        L1, L2 = self.cal.foot_L1, self.cal.foot_L2
        heel, ball, toe = foot_points(self.r, L1, self.C, rot, pos, self.state, self.toe_dir,
                                      self.mtp0, self.lift_t, t)
        self.pts = (heel, ball, toe)
        rear = (ball - heel) / L2
        # Toe up is positive: heel strike reads positive, heel-off negative.
        self.pitch = math.degrees(math.asin(max(-1.0, min(1.0, float(rear[2])))))
        front = (toe - ball) / L1
        self.mtp = math.degrees(math.acos(max(-1.0, min(1.0, float(rear @ front)))))
        floor = self.ground_z if self.ground_z is not None else 0.0
        self.toe_clear = float(toe[2] - floor)
        self.heel_clear = float(heel[2] - floor)

        # Contact panel frame: anchored point pinned where it sits in the flat
        # footprint (heel at origin, ball L2 ahead), heading turned onto +x.
        if self.state in ("heel", "toe", "flat"):
            if self.state == "toe":
                head = self.toe_dir
                anchor, anchor_x = ball, L2
            else:
                f = rot @ self.C[:, 0]
                head = np.array([f[0], f[1], 0.0])
                anchor, anchor_x = heel, 0.0
            n = float(np.linalg.norm(head))
            if n > 1e-6:
                head = head / n
                side = np.cross(Z_UP, head)
                local = []
                for p in (heel, ball, toe, pos):
                    d = p - anchor
                    local.append(np.array([anchor_x + float(d @ head),
                                           float(d @ side), float(p[2] - floor)]))
                self.contact_view = (self.state, tuple(local))

    # -- forward-axis check --------------------------------------------------
    def forward_from_lateral(self, lateral, up_b):
        """Heel to toe in sensor axes from the foot's measured left axis and up.
        Returns (forward, agreement with the model's forward, the
        FOOT_FORWARD_BODY that would produce it under the current flip)."""
        fwd_seen = np.cross(lateral, up_b)
        fwd_seen = fwd_seen / max(float(np.linalg.norm(fwd_seen)), 1e-9)
        agree = float(fwd_seen @ self.C[:, 0])
        flip = self._flip()
        best, best_score = None, -2.0
        for k in range(3):
            for sign in (1.0, -1.0):
                cand = [0.0, 0.0, 0.0]
                cand[k] = sign
                score = float((self._frame(cand, up_b, warn=False) @ flip)[:, 0]
                              @ fwd_seen)
                if score > best_score:
                    best, best_score = cand, score
        if best_score > math.cos(math.radians(25.0)):
            suggest = "({:.0f}, {:.0f}, {:.0f})".format(*best)
        else:
            suggest = "({:+.2f}, {:+.2f}, {:+.2f}) before the flip".format(*fwd_seen)
        return fwd_seen, agree, suggest

    def _axis_update(self, stance, omega_b, dt):
        """Contact phases rotate the foot about its lateral axis and almost
        nothing else, so the principal axis of the rotation seen there IS the
        lateral axis in sensor coordinates; the toe phase fixes its sign."""
        if self._axis_done:
            return
        self._axis_M += np.outer(omega_b, omega_b) * dt
        self._axis_rot += math.degrees(float(np.linalg.norm(omega_b)) * dt)
        if stance == "toe":
            self._axis_sign = self._axis_sign + omega_b * dt
        if self._axis_rot < cfg.FOOT_AXIS_CHECK_DEG or not np.any(self._axis_sign):
            return
        self._axis_done = True
        vals, vecs = np.linalg.eigh(self._axis_M)
        lateral = vecs[:, -1]
        purity = float(vals[-1] / max(float(vals.sum()), 1e-12))
        if float(lateral @ self._axis_sign) < 0.0:   # heel rising = +rotation about left
            lateral = -lateral
        fwd_seen, agree, suggest = self.forward_from_lateral(lateral, self.up_b)
        if agree > 0.9:
            self.axis_msg = "forward axis agrees ({:.2f})".format(agree)
            print(f"[foot] {self.axis_msg}, rotation {purity:.0%} about one axis")
        else:
            self.axis_msg = "forward axis? try {}".format(suggest)
            print("[foot] the rotation seen during heel and toe contact ({:.0%} about "
                  "one axis) says the foot points along ({:+.2f}, {:+.2f}, {:+.2f}) "
                  "in sensor axes, against the model's ({:+.2f}, {:+.2f}, {:+.2f}) "
                  "(agreement {:+.2f}). With FOOT_MODEL_FLIP_DEG {} that is "
                  "FOOT_FORWARD_BODY = {}, if the shoe was walked normally.".format(
                      purity, *fwd_seen, *self.C[:, 0], agree,
                      tuple(cfg.FOOT_MODEL_FLIP_DEG), suggest))
