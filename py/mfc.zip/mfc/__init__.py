"""MFC Tracker receiver package. See MFC CLAUDE.md for the module map."""

__version__ = "2026.10.13"
