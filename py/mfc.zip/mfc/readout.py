"""The step readout of the G window and the consoles: per step the length, the heights and a
timeline of the gait events, and a summary of the run (mean, spread, speed, cadence).
All from the selected method's post-processed trajectory. Ref: "Step readout" in
docs/mfc_processing_reference.md.

Events per step (device seconds): HO heel-off (the foot leaves flat), TO toe-off (the last
contact before the swing), HS initial contact (heel strike, or the ball where it lands on
it), FF foot-flat (flat again). One tracker is one foot, so the intervals across steps
(stance, HS-HS, ...) need the step before and are a dash for the first step, or after a
step that could not be processed.
"""

import re

import numpy as np

from . import gait

EVENTS = ("HO", "TO", "HS", "FF")
MAX_GAP_S = 0.4                 # a step that starts later than this after the last one ended does not follow it


def step_events(s):
    """{"HO", "TO", "HS", "FF"} device times of one StepResult, and the HO row."""
    state, i0, i1 = s.state, s.i0, s.i1
    flat_before = [k for k in range(min(i0, len(state) - 1), -1, -1) if state[k] == "flat"]
    ho = flat_before[0] + 1 if flat_before else 0
    ff = next((k for k in range(i1 + 1, len(state)) if state[k] == "flat"), len(state) - 1)
    return {"HO": s.t_start + float(s.t[ho]), "TO": s.t_start + s.events["t_toe_off"],
            "HS": s.t_start + s.events["t_heel_strike"], "FF": s.t_start + float(s.t[ff])}, ho


def step_values(walk):
    """One dict per step: the events, the in-step phases, the intervals from the step
    before (None where there is none), the length and the heights (mm)."""
    out = []
    turns = gait.step_turns(walk.steps)
    prev = None
    for k, s in enumerate(walk.steps):
        tr = s.traj[walk.method]
        ev, ho = step_events(s)
        heel_max = float(tr.heel[ho:s.i1 + 1, 2].max()) * 1000.0
        toe_max = tr.peak_toe_m * 1000.0
        v = dict(ev, n=k + 1, length=tr.stride_m, foot_max=max(toe_max, heel_max),
                 toe_max=toe_max, heel_max=heel_max, mfc=tr.mfc_m * 1000.0, turn=turns[k],
                 lands=tr.land, push=ev["TO"] - ev["HO"], swing=ev["HS"] - ev["TO"],
                 load=ev["FF"] - ev["HS"], flags=s.flags)
        # consecutive steps meet in the flat between them; a step that could not be
        # processed leaves a gap of at least its own swing
        joined = prev is not None and s.t_start - prev["end"] < MAX_GAP_S
        v.update({key: None for key in ("stance", "flat", "HS-HS", "TO-TO", "HO-HO", "swing%")})
        if joined:
            v.update({"stance": ev["TO"] - prev["HS"], "flat": ev["HO"] - prev["FF"],
                      "HS-HS": ev["HS"] - prev["HS"], "TO-TO": ev["TO"] - prev["TO"],
                      "HO-HO": ev["HO"] - prev["HO"]})
            v["swing%"] = 100.0 * v["swing"] / v["HS-HS"] if v["HS-HS"] > 0 else None
        v["end"] = s.t_start + s.duration_s
        out.append(v)
        prev = v
    return out


def _fmt(v, spec):
    if v is None:
        return "-"
    return "{:{}}".format(v, spec) if spec else str(v)


def grid(groups, rows, labels, cur=None):
    """Monospace table in groups split by " | ". groups: [(group title, [(column title,
    key, format spec or None for text)])]. rows: dicts. cur: the row to mark ">"."""
    cols = [c for _, cs in groups for c in cs]
    cells = [[_fmt(r[key], spec) for _, key, spec in cols] for r in rows]
    widths = [max(len(t), *(len(c[j]) for c in cells)) for j, (t, _, _) in enumerate(cols)]
    lw = max(len(str(lab)) for lab in labels) + 2
    j = 0
    for g, cs in groups:                    # a group title wider than its columns widens the last one
        j += len(cs)
        widths[j - 1] += max(0, len(g) - (sum(widths[j - len(cs):j]) + 2 * (len(cs) - 1)))

    def join(parts):
        out, j = [], 0
        for _, cs in groups:
            out.append("  ".join(parts[j:j + len(cs)]))
            j += len(cs)
        return " | ".join(out)

    spans, j = [], 0
    for _, cs in groups:
        spans.append(sum(widths[j:j + len(cs)]) + 2 * (len(cs) - 1))
        j += len(cs)
    head = " " * lw + " | ".join("{:<{}}".format(g, w) for (g, _), w in zip(groups, spans))
    lines = [head.rstrip(),
             " " * lw + join(["{:>{}}".format(t, w) for (t, _, _), w in zip(cols, widths)])]
    for i, (lab, c) in enumerate(zip(labels, cells)):
        lines.append("{}{:<{}}".format(">" if cur == i else " ", lab, lw - 1)
                     + join(["{:>{}}".format(v, w) for v, w in zip(c, widths)]))
    return lines


def _labels(vals):
    return ["{}/{}".format(v["n"], len(vals)) for v in vals]


def steps_table(walk, cur=None, vals=None):
    vals = vals or step_values(walk)
    return grid([("step", [("length m", "length", ".2f")]),
                 ("max height mm", [("foot", "foot_max", ".0f"), ("toe", "toe_max", ".0f"),
                                    ("heel", "heel_max", ".0f")]),
                 ("clearance", [("MFC mm", "mfc", ".0f")]),
                 ("", [("turn deg", "turn", "+.0f"), ("lands", "lands", None)])],
                vals, _labels(vals), cur)


def timeline_table(walk, cur=None, vals=None):
    vals = vals or step_values(walk)
    t0 = vals[0]["HO"]
    rows = [dict(v, **{e + "_t": v[e] - t0 for e in EVENTS}) for v in vals]
    lines = grid([("events s", [(e, e + "_t", ".2f") for e in EVENTS]),
                  ("in the step s", [("push", "push", ".2f"), ("swing", "swing", ".2f"),
                                     ("load", "load", ".2f")]),
                  ("from the step before s", [("stance", "stance", ".2f"), ("flat", "flat", ".2f"),
                                              ("HS-HS", "HS-HS", ".2f"), ("TO-TO", "TO-TO", ".2f"),
                                              ("HO-HO", "HO-HO", ".2f")])],
                 rows, _labels(vals), cur)
    lines.append("HO heel-off  TO toe-off  HS heel strike  FF foot flat (from the first HO)")
    lines.append("push HO-TO  swing TO-HS  load HS-FF")
    lines.append("stance: HS before to TO  flat: FF before to HO")
    return lines


def _stat_row(name, xs, spec, unit=""):
    pts = [(v, i) for i, v in enumerate(xs, 1) if v is not None]
    if not pts:
        return None
    a = np.array([p[0] for p in pts])
    mean = float(a.mean())
    sd = float(a.std(ddof=1)) if len(a) > 1 else None
    cv = 100.0 * sd / abs(mean) if sd is not None and mean else None
    lo, hi = min(pts), max(pts)
    return {"name": name + (" " + unit if unit else ""), "mean": mean, "sd": sd, "cv": cv,
            "min": "{:{}} ({})".format(lo[0], spec, lo[1]), "max": "{:{}} ({})".format(hi[0], spec, hi[1]),
            "spec": spec, "n": len(a)}


def summary_stats(vals):
    """The per-metric statistics of the summary: name -> row dict (None if no value)."""
    col = lambda key: [v[key] for v in vals]                      # noqa: E731
    return {"length": _stat_row("length", col("length"), ".2f", "m"),
            "foot_max": _stat_row("foot max", col("foot_max"), ".0f", "mm"),
            "toe_max": _stat_row("toe max", col("toe_max"), ".0f", "mm"),
            "heel_max": _stat_row("heel max", col("heel_max"), ".0f", "mm"),
            "mfc": _stat_row("MFC", col("mfc"), ".0f", "mm"),
            "swing": _stat_row("swing", col("swing"), ".2f", "s"),
            "stance": _stat_row("stance", col("stance"), ".2f", "s"),
            "HS-HS": _stat_row("stride time", col("HS-HS"), ".2f", "s"),
            "swing%": _stat_row("swing", col("swing%"), ".0f", "% of cycle")}


def short_flag(text):
    """The name of a flag without its numbers: "held-out +23 mm (over 10)" -> "held-out"."""
    if text.startswith("a_p"):
        return "a_p vs a_v"
    if text.startswith("toe phase"):
        return "toe phase rebuilt" if "rebuilt from" in text else "toe phase not rebuilt"
    if text.endswith("attitude not de-drifted"):
        return "attitude not de-drifted"
    m = re.search(r"\s[-+]?\d", text)
    return (text[:m.start()] if m else text.split(":")[0]).strip()


def summary_table(walk, vals=None, short=False):
    """short: the flags by name only (the window; D shows them in full)."""
    vals = vals or step_values(walk)
    stats = [r for r in summary_stats(vals).values() if r is not None]
    w = max(len(r["name"]) for r in stats)
    lines = ["{:<{}}  {:>6}  {:>5}  {:>5}  {:>9}  {:>9}".format("", w, "mean", "SD", "CV%", "min", "max")]
    for r in stats:
        lines.append("{:<{}}  {:>6}  {:>5}  {:>5}  {:>9}  {:>9}".format(
            r["name"], w, _fmt(r["mean"], r["spec"]), _fmt(r["sd"], r["spec"]), _fmt(r["cv"], ".1f"),
            r["min"], r["max"]))
    total = sum(v["length"] for v in vals)
    heel = walk.chain.heel
    disp = float(np.hypot(*(heel[-1, :2] - heel[0, :2])))
    t_walk = vals[-1]["FF"] - vals[0]["HO"]
    lines.append("")
    lines.append("{} step{}, {:.2f} m walked ({:.2f} m start to end) in {:.1f} s: {:.2f} m/s".format(
        len(vals), "" if len(vals) == 1 else "s", total, disp, t_walk, total / t_walk if t_walk > 0 else 0.0))
    cyc = [v["HS-HS"] for v in vals if v["HS-HS"]]
    if cyc:
        spm = 60.0 / float(np.mean(cyc))
        lines.append("cadence {:.0f} strides/min, about {:.0f} steps/min with both feet".format(spm, 2 * spm))
    turns = [v["turn"] for v in vals if v["turn"] is not None]
    low = min(vals, key=lambda v: v["mfc"])
    lines.append("lowest MFC {:.0f} mm (step {}){}".format(
        low["mfc"], low["n"], "   net turn {:+.0f} deg".format(sum(turns)) if turns else ""))
    flagged = [v for v in vals if v["flags"]]
    lines.append("flagged steps: {}".format(len(flagged)) + (" (D for the numbers)" if flagged and short else ""))
    for v in flagged:
        lines.append("  step {}: {}".format(v["n"], ", ".join(short_flag(f) for f in v["flags"]) if short
                                            else "; ".join(v["flags"])))
    return lines


def readout(walk, cur=None, vals=None, short=False):
    """(steps lines, timeline lines, summary lines) of a WalkResult (vals: its
    step_values, if already worked out; short: flags by name only)."""
    vals = vals or step_values(walk)
    return (["STEPS   method " + walk.method] + steps_table(walk, cur, vals),
            ["TIMELINE"] + timeline_table(walk, cur, vals),
            ["SUMMARY"] + summary_table(walk, vals, short))


def lines(walk):
    """The readout as console lines."""
    out = []
    for part in readout(walk):
        out += part + [""]
    return out
