"""Decoder of the compact frames in the tracker's run files (the encoder is
firmware/mfc_codec.py, which has the format). Every record decodes to the exact bytes of the
frame the unit would have streamed, so everything after it (devrec, replay) is unchanged.
"""

import struct

HEADER = "<IBBHB"
# flags -> (channels, format of one sample, size of one sample): the same table as the encoder's
STREAMS = {1: (6, "<H6h", 14), 2: (3, "<H3h", 8), 4: (2, "<H2H", 6)}


def _get(data, p):
    shift = u = 0
    while True:
        b = data[p]
        p += 1
        u |= (b & 127) << shift
        if b < 128:
            return u, p
        shift += 7


def _unzz(u):
    return (u >> 1) if not u & 1 else -((u + 1) >> 1)


class Decoder:
    """The state of one run's compact frames, fed in file order."""

    def __init__(self):
        self.prev = {1: [0] * 6, 2: [0] * 3, 4: [0] * 2}
        self.iv = {1: 0, 2: 0, 4: 0}
        self.last_base = 0

    def decode(self, data):
        """The frame bytes of one compact record. Raises ValueError for a record that is not one."""
        try:
            flags, seq, count = data[0], data[1], data[2]
            spec = STREAMS.get(flags)
            if spec is None:
                raise ValueError("unknown stream {:#x}".format(flags))
            nv, fmt, _sz = spec
            u, p = _get(data, 3)
            iv = self.iv[flags] + _unzz(u)
            self.iv[flags] = iv
            u, p = _get(data, p)
            base = (self.last_base + _unzz(u)) & 0xFFFFFFFF
            self.last_base = base
            mask, p = _get(data, p)
            offsets = []
            for i in range(count):
                r = 0
                if mask >> i & 1:
                    u, p = _get(data, p)
                    r = _unzz(u)
                if i == 0:
                    t = r
                elif i == 1:
                    t = r + offsets[0] + iv
                else:
                    t = r + 2 * offsets[i - 1] - offsets[i - 2]
                offsets.append(t)
            prev = self.prev[flags]
            out = bytearray(struct.pack(HEADER, base, seq, count, iv, flags))
            for i in range(count):
                row = []
                for j in range(nv):
                    u, p = _get(data, p)
                    prev[j] += _unzz(u)
                    row.append(prev[j])
                out += struct.pack(fmt, offsets[i], *row)
            if p != len(data):
                raise ValueError("{} bytes left over".format(len(data) - p))
            return bytes(out)
        except (IndexError, struct.error) as exc:
            raise ValueError("damaged compact frame: {}".format(exc))
