"""Mahony-style PI complementary attitude filter.

The gyro propagates the pose. Gravity corrects roll and pitch, but only while
the device is genuinely at rest. The magnetometer corrects heading only, as a
rotation about world vertical, so dip and hard iron cannot tilt the pose. The
I terms hand persistent disagreement back to the gyro as a bias.
Ref: "Attitude filter", "Stationary gate", "Is the compass a compass".

Heading zero is the direction the device pointed at the last R; the field
only has to hold yaw against that, so only the CHANGE in field bearing is used.
"""

import math
from collections import deque

import numpy as np

from . import config as cfg
from .mathutil import euler_from_q, q_from_matrix, q_integrate, q_matrix, wrap_pi


class AttitudeFilter:
    def __init__(self):
        self.g_mag = 9.80665
        self.reset()

    def reset(self):
        """R is a clean slate for the session state. The persisted terms (C, T)
        live in the Calibration and are not touched."""
        self.q = np.array([1.0, 0.0, 0.0, 0.0])
        self.gyro_bias = np.zeros(3)            # deg/s, measured by R
        self.gyro_bias_online = np.zeros(3)     # deg/s, learned by the slow branch
        self.accel_bias_trim = np.zeros(3)      # m/s^2, body, R phase 2
        self.accel_noise = np.zeros(3)          # m/s^2 rms, world, R phase 2
        self.quiet_since = None
        self.stationary = False
        self._acc_win = deque()                 # sliding window for the spread test
        self.mag_norm_ref = None                # |m| reference for disturbance rejection
        self.mag_ref_angle = None               # rad, field bearing that defines yaw 0
        self.mag_ok = True                      # was the last field sample accepted
        self.mag_reject = ""                    # why not, "" if it is
        self.yaw_mag = 0.0                      # deg, the magnetometer's own heading
        self._mag_last_raw = None
        self._mag_last_change_t = None
        self._track_hist = deque()              # (t, fused yaw, field bearing)
        self.track_slope = None                 # d(bearing)/d(yaw): 0 compass, 1 not
        self._track_warned = False

    # -- compass sanity ------------------------------------------------------
    def _update_tracking(self, t, yaw, bearing):
        """Slope of the field's world bearing against the fused yaw. Zero means
        the field held still while the device turned (a compass); one means it
        turned with the device (body-fixed). None until the device has turned
        far enough for the regression to mean anything."""
        if self._track_hist and t - self._track_hist[-1][0] < 0.1:   # 10 Hz is plenty
            return self.track_slope
        self._track_hist.append((t, yaw, bearing))
        while self._track_hist and t - self._track_hist[0][0] > cfg.MAG_TRACK_WINDOW_S:
            self._track_hist.popleft()
        if len(self._track_hist) < 8:
            return self.track_slope

        rows = np.asarray(self._track_hist, dtype=float)
        yaws = np.unwrap(rows[:, 1])
        bearings = np.unwrap(rows[:, 2])
        span = float(yaws.max() - yaws.min())
        if math.degrees(span) < cfg.MAG_TRACK_MIN_YAW_DEG:
            return self.track_slope

        var = float(np.var(yaws))
        if var < 1e-9:
            return self.track_slope
        self.track_slope = float(np.cov(bearings, yaws, bias=True)[0, 1] / var)
        if self.track_slope > cfg.MAG_TRACK_MAX_SLOPE and not self._track_warned:
            self._track_warned = True
            print(f"\n[!] the field's bearing is tracking the device's own rotation "
                  f"(slope {self.track_slope:.2f}, a compass gives about 0).")
            print("    Something body-fixed dominates the reading: hard iron, or a")
            print("    magnetometer returning the same register contents. Heading")
            print("    correction is off until it tracks again. Run C away from steel")
            print("    and batteries, or check the magnetometer.\n")
        return self.track_slope

    # -- one sample ----------------------------------------------------------
    def level_tilt(self, acc_mean):
        """Snap roll and pitch to gravity as measured by acc_mean (body frame, a foot-flat's
        mean): the smallest rotation that turns the measured up onto world vertical, so the
        heading is kept. Returns the correction in degrees."""
        a_hat = np.asarray(acc_mean, dtype=float)
        a_hat = a_hat / np.linalg.norm(a_hat)
        rot = q_matrix(self.q)
        w = rot @ a_hat
        axis = np.array([w[1], -w[0], 0.0])           # w x z
        s, c = float(np.linalg.norm(axis)), float(w[2])
        if s < 1e-9:
            return 0.0
        axis = axis / s
        k = np.array([[0.0, -axis[2], axis[1]], [axis[2], 0.0, -axis[0]], [-axis[1], axis[0], 0.0]])
        corr = np.eye(3) + s * k + (1.0 - c) * (k @ k)
        self.q = q_from_matrix(corr @ rot)
        return math.degrees(math.atan2(s, c))

    def update(self, t, dt, acc, gyr, last_mag, cal, correcting, in_run):
        """acc (m/s^2) and gyr (deg/s) are already bias corrected. Returns
        (rot, lin): body-to-world rotation and gravity-free world acceleration.
        correcting=False freezes the corrections (drift capture); in_run enables
        the compass test."""
        omega = np.radians(gyr)

        a_norm = float(np.linalg.norm(acc))
        self._acc_win.append((t, acc[0], acc[1], acc[2]))
        while self._acc_win and t - self._acc_win[0][0] > cfg.STILL_ACC_WINDOW_S:
            self._acc_win.popleft()
        win = np.asarray(self._acc_win, dtype=float)[:, 1:]
        acc_spread = float(np.max(win.max(axis=0) - win.min(axis=0)))

        quiet = (float(np.linalg.norm(gyr)) < cfg.STILL_GYRO_DPS
                 and abs(a_norm - self.g_mag) < cfg.STILL_ACC_TOL
                 and acc_spread < cfg.STILL_ACC_SPREAD)
        if quiet:
            if self.quiet_since is None:
                self.quiet_since = t
        else:
            self.quiet_since = None
        self.stationary = (self.quiet_since is not None
                           and (t - self.quiet_since) >= cfg.STILL_HOLD_S)

        # Slow branch: each absolute reference as a body-frame rotation error.
        rot_now = q_matrix(self.q)
        e_tilt = np.zeros(3)
        e_head = np.zeros(3)

        if self.stationary and a_norm > 1e-6:
            a_hat = acc / a_norm
            w, x, y, z = self.q
            v = np.array([2 * (x * z - w * y), 2 * (y * z + w * x),
                          1 - 2 * (x * x + y * y)])
            e_tilt = np.cross(a_hat, v)

        # Tilt-compensated compass heading; the fused yaw cancels out of it, so
        # it is the magnetometer's own estimate.
        self.mag_ok = False
        self.mag_reject = "no field"
        if last_mag is not None and self.mag_ref_angle is not None:
            # A stalled QMC6309 still answers the aux read with the last
            # conversion, so a frozen reading looks alive.
            if self._mag_last_raw is None or not np.array_equal(last_mag, self._mag_last_raw):
                self._mag_last_raw = last_mag
                self._mag_last_change_t = t
            stale = (self._mag_last_change_t is not None
                     and t - self._mag_last_change_t > cfg.MAG_TIMEOUT_S)

            m_cal = (last_mag - cal.mag_bias) / cal.mag_scale
            m_norm = float(np.linalg.norm(m_cal))
            disturbed = (self.mag_norm_ref is not None and m_norm > 1e-6
                         and abs(m_norm - self.mag_norm_ref) / self.mag_norm_ref
                         > cfg.MAG_DISTURB_TOL)
            m_world = rot_now @ m_cal
            bearing = math.atan2(m_world[1], m_world[0])
            yaw_now = euler_from_q(self.q)[2]

            slope = self._update_tracking(t, yaw_now, bearing) if in_run else None
            not_a_compass = slope is not None and slope > cfg.MAG_TRACK_MAX_SLOPE

            yaw_err = wrap_pi(bearing - self.mag_ref_angle)
            self.yaw_mag = math.degrees(wrap_pi(yaw_now - yaw_err))

            if stale:
                self.mag_reject = "stale"
            elif disturbed:
                self.mag_reject = "disturbed"
            elif not_a_compass:
                self.mag_reject = "not tracking"
            elif abs(m_world[0]) + abs(m_world[1]) <= 1e-6:
                self.mag_reject = "degenerate"
            else:
                self.mag_ok = True
                self.mag_reject = ""
                e_head = rot_now.T @ np.array([0.0, 0.0, -yaw_err])   # about world vertical

        # Crossover. P runs whenever its branch is valid. I runs only at rest:
        # gyro bias is a body-frame quantity but the heading error is about world
        # vertical, so while turning the integrator would smear it across axes.
        if correcting:
            omega = omega + cfg.ACC_KP * e_tilt + cfg.MAG_KP * e_head
            if self.quiet_since is not None and (t - self.quiet_since) >= cfg.STILL_HOLD_BIAS_S:
                self.gyro_bias_online = np.clip(
                    self.gyro_bias_online
                    - np.degrees(cfg.ACC_KI * e_tilt + cfg.MAG_KI * e_head) * dt,
                    -cfg.GYRO_BIAS_LIMIT_DPS, cfg.GYRO_BIAS_LIMIT_DPS)

        self.q = q_integrate(self.q, omega, dt)
        rot = q_matrix(self.q)
        lin = rot @ acc - np.array([0.0, 0.0, self.g_mag])
        return rot, lin
