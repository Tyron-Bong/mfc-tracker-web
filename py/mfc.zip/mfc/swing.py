"""Offline trajectory of one recorded step: clean the signals, rebuild the contact
phases from kinematics, and integrate the swing with a choice of correction.

Everything here is pure numpy on the arrays of one step (the recorder's rows), in
the world frame of the live foot model. gait.py calls it from process_step.
Ref: "Swing trajectory methods" in docs/mfc_processing_reference.md.

Physical model, per step (ground level and flat):
  1. contact phases (heel, toe, flat): the position is the foot model's
     kinematics from the gyro attitude R, p_sensor = anchor - R r, no accelerometer;
  2. swing: the gyro attitude rotates the body accel into the world frame, gravity
     is removed (lin = R a - g) and lin is integrated for velocity and position
     from the kinematic state at toe-off;
  3. at heel strike the heel (ball after a toe strike) is anchored on the floor
     and the velocity follows the pinned kinematics, at foot-flat it is zero
     (ZUPT) and the position is held;
  4. the integrated swing misses the floor height and the heel-strike velocity
     because of accelerometer and attitude errors: the swing methods below
     correct that, each a named function in METHODS so they can be compared.
"""

import math
from dataclasses import dataclass, field

import numpy as np

from . import config as cfg
from .foot import foot_points
from .mathutil import q_from_matrix, q_integrate, q_matrix

STAGES = {"accel": {}}


def stage(kind, name):
    """Register fn(data) as a stage. accel stages get a StepData and edit its
    signals (acc_b, omega, rot, lin) before any method runs."""
    def register(fn):
        STAGES[kind][name] = fn
        return fn
    return register


def run_stages(kind, names, data):
    for name in names:
        if name not in STAGES[kind]:
            raise KeyError("unknown {} stage '{}'; registered: {}".format(
                kind, name, sorted(STAGES[kind])))
        STAGES[kind][name](data)


# -- signals -----------------------------------------------------------------
def lowpass_zero_phase(x, fc, fs):
    """Forward-backward 2nd-order Butterworth low-pass (zero phase) on the columns
    of x. Ends are padded by odd reflection about the end points and the filter
    state starts at the first value, so there is no start-up transient. fc None
    or too close to the sample rate returns x unchanged."""
    x = np.asarray(x, dtype=float)
    if fc is None or fc <= 0.0 or fc >= 0.45 * fs or len(x) < 8:
        return x.copy()
    w = math.tan(math.pi * fc / fs)
    norm = 1.0 + math.sqrt(2.0) * w + w * w
    b0 = w * w / norm
    b1, b2 = 2.0 * b0, b0
    a1 = 2.0 * (w * w - 1.0) / norm
    a2 = (1.0 - math.sqrt(2.0) * w + w * w) / norm
    pad = min(len(x) - 1, int(round(3.0 * fs / fc)))

    def run(y):
        y = y - y[0]                                  # zero state is then steady for the first value
        out = np.empty_like(y)
        z1 = np.zeros(y.shape[1])
        z2 = np.zeros(y.shape[1])
        for n in range(len(y)):                       # direct form II transposed
            o = b0 * y[n] + z1
            z1 = b1 * y[n] - a1 * o + z2
            z2 = b2 * y[n] - a2 * o
            out[n] = o
        return out

    ext = np.concatenate((2.0 * x[0] - x[pad:0:-1], x, 2.0 * x[-1] - x[-2:-pad - 2:-1]))
    first = ext[0].copy()
    y = run(ext) + first
    back = y[::-1]
    first = back[0].copy()
    y = (run(back) + first)[::-1]
    return y[pad:len(y) - pad]


def integrate_attitude(rot, omega, dt, k0, bias=None):
    """Body-to-world attitude per row: rows up to k0 are kept, later rows are the
    gyro (omega minus an optional constant body-frame bias) integrated forward
    with the receiver's own quaternion step."""
    out = np.array(rot, dtype=float)
    q = q_from_matrix(out[k0])
    for k in range(k0 + 1, len(out)):
        w = omega[k] if bias is None else omega[k] - bias
        q = q_integrate(q, w, dt[k])
        out[k] = q_matrix(q)
    return out


def world_lin(rot, acc, g):
    """Gravity-free world acceleration per row, lin = R a - g (as the live chain)."""
    gv = np.array([0.0, 0.0, g])
    return np.array([rot[k] @ acc[k] - gv for k in range(len(acc))])


# -- one step as arrays --------------------------------------------------------
def longest_swing(state):
    best, run0 = None, None
    for k, s in enumerate(list(state) + [None]):
        if s == "swing":
            run0 = k if run0 is None else run0
        elif run0 is not None:
            if best is None or k - run0 > best[1] - best[0]:
                best = (run0, k)
            run0 = None
    return best                                          # [start, stop) or None


@dataclass
class StepData:
    """Everything the offline chain works on. The arrays cover the whole
    recording; the live (FSR-timed) swing is rows i0 + 1 .. i1. Stages may edit
    acc_b, omega, rot and lin (never the live copies)."""
    t: np.ndarray
    dt: np.ndarray
    state: list
    lin: np.ndarray                 # N x 3 world linear accel, gravity off
    acc_b: object                   # N x 3 calibrated body accel (None in old rows)
    omega: np.ndarray               # N x 3 body gyro, rad/s
    rot: np.ndarray                 # N x 3 x 3 body to world
    pos_live: np.ndarray
    vel_live: np.ndarray
    pts_live: np.ndarray
    anchor: list                    # per row: world anchor of the pivot, or None
    mtp0: np.ndarray
    lift_t: list
    toe_dir: np.ndarray
    r: dict                         # body-frame lever arms: heel, ball, toe
    C: np.ndarray
    L1: float
    L2: float
    g: float
    ground_z: object                # world floor height, or None
    i0: int                         # last contact row before the live swing
    i1: int                         # last live swing row
    f0: int                         # last flat row before the foot starts to move
    f1: int                         # first flat row after landing
    notes: dict = field(default_factory=dict)

    def __post_init__(self):
        self.rot_live = self.rot.copy()
        self.lin_live = self.lin.copy()
        self.acc_raw = None if self.acc_b is None else self.acc_b.copy()   # never filtered
        self.floor = 0.0 if self.ground_z is None else float(self.ground_z)

    @property
    def fs(self):
        return 1.0 / float(np.median(self.dt[1:]))


def from_rows(rows, ground_z, mount):
    """StepData from the recorder's rows and the mount dict. Raises ValueError,
    with a reason fit to display, if the rows are not a usable step."""
    t = np.array([r[0] for r in rows])
    dt = np.array([r[1] for r in rows])
    state = [r[2] for r in rows]
    span = longest_swing(state)
    if span is None or t[span[1] - 1] - t[span[0]] + dt[span[1] - 1] < cfg.STEP_MIN_SWING_S:
        raise ValueError("no real swing in that step")
    i0, i1 = span[0] - 1, span[1] - 1
    if i0 < 1 or i1 + 1 >= len(rows):
        raise ValueError("step is missing its flat start or end")
    j = 0
    while j < len(state) and state[j] == "flat":
        j += 1
    if j == 0:
        raise ValueError("step is missing its flat start")
    f0 = j - 1
    f1 = next((k for k in range(i1 + 1, len(state)) if state[k] == "flat"), None)
    if f1 is None:
        raise ValueError("step is missing its flat end")
    mount = mount or {}
    acc = None
    if all(len(r) > 9 and r[9] is not None for r in rows):
        acc = np.array([r[9] for r in rows], dtype=float)
    anchor = [r[10] if len(r) > 10 else None for r in rows]
    if any(anchor[k] is None for k in range(f0 + 1, i0 + 1)):
        raise ValueError("this recording predates the offline signals (no foot anchor saved)")
    n = len(rows)
    return StepData(
        t=t, dt=dt, state=state, lin=np.array([r[3] for r in rows], dtype=float),
        acc_b=acc, omega=np.array([r[8] for r in rows], dtype=float),
        rot=np.array([r[7] for r in rows], dtype=float),
        pos_live=np.array([r[4] for r in rows], dtype=float),
        vel_live=np.array([r[5] for r in rows], dtype=float),
        pts_live=np.array([np.asarray(r[6], dtype=float) for r in rows]),
        anchor=anchor,
        mtp0=np.array([r[11] if len(r) > 11 else 0.0 for r in rows], dtype=float),
        lift_t=[r[12] if len(r) > 12 else None for r in rows],
        toe_dir=np.array([r[13] if len(r) > 13 and r[13] is not None else [1.0, 0.0, 0.0]
                          for r in rows], dtype=float),
        r=mount.get("r") or {}, C=mount.get("C", np.eye(3)), L1=mount.get("L1", 0.0),
        L2=mount.get("L2", 0.0), g=mount.get("g_mag") or 9.80665, ground_z=ground_z,
        i0=i0, i1=i1, f0=f0, f1=f1)


def _need_signals(d):
    if d.acc_b is None or not d.r:
        raise ValueError("this recording predates the offline signals (no body accel or "
                         "lever arms saved)")


def on_ground(d, p):
    p = np.array(p, dtype=float)
    if cfg.FOOT_SNAP_TO_GROUND and d.ground_z is not None:
        p[2] = d.ground_z
    return p


# -- signal stages ------------------------------------------------------------------
def _resignal(d):
    """After a stage changed acc_b or omega: re-integrate the attitude from the last
    quiet flat row and recompute lin (rows up to that flat keep their live values)."""
    d.rot = integrate_attitude(d.rot_live, d.omega, d.dt, d.f0)
    d.lin = world_lin(d.rot, d.acc_b, d.g)
    d.lin[:d.f0 + 1] = d.lin_live[:d.f0 + 1]


def advance(x, t, tau):
    """x(t + tau) per column by linear interpolation, the ends held."""
    if tau == 0.0:
        return x.copy()
    return np.column_stack([np.interp(t + tau, t, x[:, c]) for c in range(x.shape[1])])


@stage("accel", "lag_compensation")
def _lag_compensation(d):
    """Advance the accel and the gyro by the delays of their on-die filters
    (STEP_ACCEL_LAG_S, STEP_GYRO_LAG_S; a one-pole filter at fc lags by
    1 / (2 pi fc)), so they describe the same instant again. At toe-off the foot
    pitches at about 6 rad/s, so the 11 ms a 14.2 Hz gyro filter adds is 3.8 degrees
    of attitude error, about 11 mm of toe-tip height. Only as good as the delay
    figures; the firmware option (filters off) removes the cause."""
    _need_signals(d)
    d.acc_b = advance(d.acc_b, d.t, cfg.STEP_ACCEL_LAG_S)
    d.omega = advance(d.omega, d.t, cfg.STEP_GYRO_LAG_S)
    _resignal(d)


@stage("accel", "zero_phase")
def _zero_phase(d):
    """Low-pass body accel and body gyro with the same zero-phase filter, then
    re-integrate the attitude from the last quiet flat row and recompute lin. The
    two signals then share one delay (none), which an on-die filter pair with
    different corners cannot give: a few milliseconds of mismatch at toe-off
    (about 6 rad/s) is more than a degree of attitude error."""
    _need_signals(d)
    fs = d.fs
    d.acc_b = lowpass_zero_phase(d.acc_b, cfg.STEP_FILTER_HZ, fs)
    d.omega = lowpass_zero_phase(d.omega, cfg.STEP_FILTER_HZ, fs)
    _resignal(d)


@stage("accel", "start_level")
def _start_level(d):
    """Re-level the step's starting attitude from gravity over its start foot-flat, only when the
    live attitude is grossly off (STEP_START_LEVEL_DEG: an IMU gap, not drift). The correction is
    the smallest rotation that turns the measured up (the mean accel, in the world frame of the
    live attitude) onto vertical; it is applied in the world frame to every row, so the gyro's
    relative motion and the heading are kept. Rows up to the start flat keep their live lin
    recomputed with the corrected attitude."""
    _need_signals(d)
    k1 = d.f0 - int(round(0.03 * d.fs))         # leave out the last 30 ms: heel-off may have begun
    if k1 < 8:
        return
    # Only the rows after the last jump of the live attitude: Receiver Live re-levels at the first
    # foot-flat after an IMU gap, and a mean over a flat that holds that jump mixes the two attitudes
    # (LIN-4 step 1: 37 degrees applied where 0 was right). A jump is a row-to-row turn the gyro
    # does not explain by more than 1 degree.
    k0 = 0
    for k in range(k1):
        rel = d.rot_live[k].T @ d.rot_live[k + 1]
        turn = math.acos(max(-1.0, min(1.0, (float(np.trace(rel)) - 1.0) / 2.0)))
        if turn - float(np.linalg.norm(d.omega[k + 1])) * float(d.dt[k + 1]) > math.radians(1.0):
            k0 = k + 1
    if k1 - k0 < 8:
        return
    sl = slice(k0, k1 + 1)
    if float(np.median(np.degrees(np.linalg.norm(d.omega[sl], axis=1)))) > cfg.STEP_START_LEVEL_STILL_DPS:
        return
    a = d.acc_raw[sl].mean(axis=0)
    a_hat = a / np.linalg.norm(a)
    w = np.mean([d.rot_live[k] @ a_hat for k in range(k0, k1 + 1)], axis=0)
    w = w / np.linalg.norm(w)
    z = np.array([0.0, 0.0, 1.0])
    axis = np.cross(w, z)
    s, c = float(np.linalg.norm(axis)), float(w @ z)
    ang = math.degrees(math.atan2(s, c))
    if ang <= cfg.STEP_START_LEVEL_DEG or s < 1e-9:
        return
    axis = axis / s
    K = np.array([[0.0, -axis[2], axis[1]], [axis[2], 0.0, -axis[0]], [-axis[1], axis[0], 0.0]])
    C = np.eye(3) + s * K + (1.0 - c) * (K @ K)
    d.rot_live = np.einsum("ij,njk->nik", C, d.rot_live)
    d.rot = np.einsum("ij,njk->nik", C, d.rot)
    d.lin_live = world_lin(d.rot_live, d.acc_b, d.g)
    d.lin = d.lin_live.copy()
    d.notes["start_level_deg"] = ang


def tail_tilt_error(d, rot, k_from):
    """Tilt error vector (body frame, rad) at the end foot-flat: gravity as the
    attitude predicts it against gravity as the accelerometer measures it over
    the flat tail, from unfiltered body accel. e = g_pred x a_hat is the
    rotation that turns the prediction onto the measurement."""
    tail = slice(k_from, len(d.t))
    a = d.acc_raw[tail].mean(axis=0)
    a_hat = a / np.linalg.norm(a)
    g_pred = np.mean([rot[k].T @ np.array([0.0, 0.0, 1.0]) for k in range(len(d.t))[tail]],
                     axis=0)
    g_pred = g_pred / np.linalg.norm(g_pred)
    return np.cross(g_pred, a_hat)


def settled_tail_start(d):
    """First row of the end foot-flat tail used for gravity: past the impact,
    flat to the end."""
    settle = int(round(0.05 * d.fs))             # skip the impact ring-down, keep 5 rows at least
    return min(d.f1 + settle, len(d.t) - 5)


@stage("accel", "tilt_dedrift")
def _tilt_dedrift(d):
    """Landing tilt correction (swing attitude de-drift). At the end foot-flat the
    tilt is known from gravity, so the tilt error accumulated by the gyro since
    the last quiet flat is measurable. It is spread back as a constant body-frame
    gyro bias b = e / T and the attitude re-run. Static gravity is the same
    through any low-pass, so the check does not depend on the filter stage."""
    _need_signals(d)
    k_tail = settled_tail_start(d)
    e0 = tail_tilt_error(d, d.rot, k_tail)
    span = float(d.t[k_tail] - d.t[d.f0])
    d.notes["tilt_before_deg"] = math.degrees(float(np.linalg.norm(e0)))
    d.notes["tilt_after_deg"] = d.notes["tilt_before_deg"]
    if span <= 0.0:
        return
    if d.notes["tilt_before_deg"] > cfg.STEP_TILT_MAX_DEG:
        d.notes["tilt_skipped"] = "landing tilt {:.1f} deg is too large to be gyro drift".format(
            d.notes["tilt_before_deg"])
        return
    bias = e0 / span
    d.rot = integrate_attitude(d.rot_live, d.omega, d.dt, d.f0, bias=bias)
    d.lin = world_lin(d.rot, d.acc_b, d.g)
    d.lin[:d.f0 + 1] = d.lin_live[:d.f0 + 1]
    e1 = tail_tilt_error(d, d.rot, k_tail)
    d.notes["tilt_after_deg"] = math.degrees(float(np.linalg.norm(e1)))
    d.notes["gyro_bias_dps"] = np.degrees(bias).tolist()


# -- contact kinematics ----------------------------------------------------------------
def _key(state):
    """Which point is anchored: the ball in toe contact, else the heel (a flat
    landing is a heel landing)."""
    return "ball" if state == "toe" else "heel"


def contact_track(d, k0, k1, state_eff, anchor_for, pos, vel, roll=0.0):
    """Fill pos and vel for rows k0 .. k1 - 1 with the foot model's contact
    rules (heel and toe: p = anchor - R r, v = -w x (R r); foot flat: the position
    held from entry, v = 0). anchor_for(k, state) gives the anchor for heel and
    toe rows. Row k0 - 1 of pos is the previous position (used at flat entry).
    roll (STEP_TOE_ROLL) moves the toe-phase pivot that fraction of the way from the
    ball to the toe tip: the real foot's ball lifts as the heel comes up."""
    for k in range(k0, k1):
        s = state_eff[k]
        if s in ("heel", "toe"):
            key = _key(s)
            anchor = anchor_for(k, s)
            r = d.r[key]
            if s == "toe" and roll > 0.0:
                anchor = anchor + roll * d.L1 * d.toe_dir[min(k, d.i0)]
                r = d.r["ball"] + roll * (d.r["toe"] - d.r["ball"])
            arm = d.rot[k] @ r
            pos[k] = anchor - arm
            vel[k] = -np.cross(d.rot[k] @ d.omega[k], arm)
        elif s == "flat":
            if k == 0 or state_eff[k - 1] != "flat":
                key = "ball" if k > 0 and state_eff[k - 1] == "toe" else "heel"
                anchor = on_ground(d, pos[k - 1] + d.rot[k] @ d.r[key])
                pos[k] = anchor - d.rot[k] @ d.r[key]
            else:
                pos[k] = pos[k - 1]
            vel[k] = 0.0
        else:                                         # a swing flicker inside contact: carry on
            pos[k] = pos[k - 1]
            vel[k] = vel[k - 1]


def effective_states(d, i0r, i1r):
    """The step's row labels with the swing window moved to the refined events:
    rows inside it are swing, rows the refinement moved out of the live swing take
    the contact label next to them."""
    st = list(d.state)
    land = d.state[d.i1 + 1]
    for k in range(i0r + 1, i1r + 1):
        st[k] = "swing"
    for k in range(i1r + 1, d.i1 + 1):                # landing came earlier than the FSR said
        st[k] = land
    for k in range(d.i0 + 1, i0r + 1):                # lift-off came later than the FSR said
        st[k] = d.state[d.i0]
    return st


def pre_swing(d, i0r, state_eff):
    """Position and velocity of every row up to the lift-off row i0r: the live
    rows up to the end of the start foot-flat, then the contact rules with the
    live anchors (the last live anchor if lift-off was moved later)."""
    pos, vel = d.pos_live.copy(), d.vel_live.copy()
    contact_track(d, d.f0 + 1, i0r + 1, state_eff,
                  lambda k, s: np.asarray(d.anchor[min(k, d.i0)]), pos, vel,
                  roll=cfg.STEP_TOE_ROLL)
    return pos, vel


# -- the window between lift-off and heel strike -----------------------------------------
@dataclass
class Window:
    i0: int                          # lift-off row (last contact row)
    e: int                           # first contact row after the swing (heel strike)
    key: str                         # which point lands: "heel" or "ball"
    land_state: str                  # "heel" or "toe"
    p0: np.ndarray                   # kinematic position at lift-off
    v0: np.ndarray                   # kinematic velocity at lift-off
    v_end: np.ndarray                # heel-pinned kinematic velocity at e
    z_end: float                     # sensor height that puts the landing point on the floor
    t: np.ndarray                    # rows i0 .. e
    T: float


def make_window(d, i0r, i1r, pos, vel, state_eff):
    e = i1r + 1
    land_state = state_eff[e]
    if land_state not in ("heel", "toe", "flat"):
        raise ValueError("the foot did not land on the heel, the ball or flat")
    key = _key(land_state)
    arm = d.rot[e] @ d.r[key]
    v0 = vel[i0r].copy()
    if state_eff[i0r] == "toe":
        # the kinematic velocity at toe-off: the pivot has rolled from the ball to the toe tip
        pivot = d.r["toe"] if cfg.STEP_TOEOFF_PIVOT == "toe_tip" else d.r["ball"]
        v0 = -np.cross(d.rot[i0r] @ d.omega[i0r], d.rot[i0r] @ pivot)
    return Window(i0=i0r, e=e, key=key, land_state=land_state, p0=pos[i0r].copy(),
                  v0=v0, v_end=-np.cross(d.rot[e] @ d.omega[e], arm),
                  z_end=float(d.floor - arm[2]), t=d.t[i0r:e + 1], T=float(d.t[e] - d.t[i0r]))


def integrate(d, w, v0, k_end=None):
    """lin integrated from (p0, v0) at row i0 to row k_end (default e), as the live
    swing does. Returns (p, v) for rows i0 .. k_end."""
    n = (w.e if k_end is None else k_end) - w.i0
    p = np.empty((n + 1, 3))
    v = np.empty((n + 1, 3))
    p[0], v[0] = w.p0, v0
    for j in range(1, n + 1):
        k = w.i0 + j
        v[j] = v[j - 1] + d.lin[k] * d.dt[k]
        p[j] = p[j - 1] + v[j] * d.dt[k]
    return p, v


def flat_to_flat(d, pos):
    """lin integrated from the start foot-flat (v = 0, kinematic position) to the
    end foot-flat, the window the flat-to-flat baselines use. Returns (p, v) for
    rows f0 .. f1."""
    n = d.f1 - d.f0
    p = np.empty((n + 1, 3))
    v = np.empty((n + 1, 3))
    p[0], v[0] = pos[d.f0], 0.0
    for j in range(1, n + 1):
        k = d.f0 + j
        v[j] = v[j - 1] + d.lin[k] * d.dt[k]
        p[j] = p[j - 1] + v[j] * d.dt[k]
    return p, v


# -- the methods -------------------------------------------------------------------------
@dataclass
class Swing:
    p: np.ndarray                    # sensor position, rows i0 + 1 .. e (n x 3)
    metrics: dict


METHODS = {}


def method(name):
    def register(fn):
        METHODS[name] = fn
        return fn
    return register


@method("none")
def _none(d, w, ctx):
    """Plain double integration of lin from the kinematic lift-off state
    (STEP_START_VELOCITY "integrated" starts from the velocity integrated from
    foot-flat instead). The baseline every correction is measured against."""
    v0 = w.v0 if cfg.STEP_START_VELOCITY == "kinematic" else ctx["v0_int"]
    p, v = integrate(d, w, v0)
    ctx["none_p"], ctx["none_v"] = p, v
    return Swing(p[1:], {"start": cfg.STEP_START_VELOCITY})


def _applied(p, ctx):
    """Largest distance a method moved the swing from the plain integration, mm."""
    return float(np.max(np.linalg.norm(p - ctx["none_p"][1:], axis=1)) * 1000.0)


@method("contact_bounded")
def _contact_bounded(d, w, ctx):
    """Window toe-off to heel strike with both ends taken from the contact model.
    Start: the position and the kinematic velocity at toe-off (the pivot at the toe
    tip, STEP_TOEOFF_PIVOT). Height at heel strike: the sensor height that puts the
    heel on the floor at the measured pitch. End velocity: the heel-pinned velocity
    at the FSR heel strike (STEP_END_CONDITION "heel_pinned"), or zero at the start
    of the end foot-flat, the ZUPT ("foot_flat", the default: the real heel is not
    pinned at the FSR heel strike, it is still settling). Vertical: a velocity offset
    dv and a constant acceleration da solved from the two constraints; horizontal:
    one constant acceleration from the end velocity (the end position is the
    measurement). With a foot-flat end the integration runs on to foot-flat and the
    constraints are dv te + da te^2 / 2 = dP at heel strike and dv + da tf = -v(tf)."""
    T = w.T
    foot_flat = cfg.STEP_END_CONDITION == "foot_flat" and d.f1 > w.e
    k_end = d.f1 if foot_flat else w.e
    p, v = integrate(d, w, w.v0, k_end)
    t = d.t[w.i0:k_end + 1] - d.t[w.i0]
    je = w.e - w.i0
    da = np.zeros(3)
    dv = np.zeros(3)
    if foot_flat:
        Tf = float(t[-1])
        dP = w.z_end - p[je, 2]
        dVf = -v[-1, 2]
        dv[2], da[2] = np.linalg.solve(np.array([[T, 0.5 * T * T], [1.0, Tf]]), np.array([dP, dVf]))
        da[:2] = -v[-1, :2] / Tf
        da_v = dVf / Tf                              # held-out: ZUPT alone, vertical
        held = float(p[je, 2] + 0.5 * da_v * T * T - w.z_end)
        tau = t[1:je + 1]
        out = p[1:je + 1] + dv * tau[:, None] + 0.5 * da * (tau * tau)[:, None]
    else:
        tau = w.t[1:] - w.t[0]
        dV = w.v_end - v[-1]
        dP_z = w.z_end - p[-1, 2]
        da[2] = 2.0 * (dV[2] * T - dP_z) / (T * T)
        dv[2] = dV[2] - da[2] * T
        da[:2] = dV[:2] / T
        out = p[1:] + dv * tau[:, None] + 0.5 * da * (tau * tau)[:, None]
        # Held-out check: the vertical fitted with the end velocity alone, and the
        # end height that fit predicts against the one the contact model gave.
        da_v = dV[2] / T
        held = float(p[-1, 2] + 0.5 * da_v * T * T - w.z_end)
    metrics = {"dv_z": float(dv[2]), "da_z": float(da[2]), "da_h": float(np.linalg.norm(da[:2])),
               "heldout_m": held, "T": T, "end": "foot_flat" if foot_flat else "heel_pinned"}
    ctx["cb"] = metrics
    return Swing(out, dict(metrics, applied_mm=_applied(out, ctx)))


@method("tilt")
def _tilt(d, w, ctx):
    """Same window and kinematic start as none; the end height only: rotate the
    swing path in the vertical plane along the stride about the toe-off point so
    the landing point ends on the floor. It keeps the start position, assumes the
    error grows linearly along the stride, and turns the start velocity by the
    tilt angle."""
    p = ctx["none_p"]
    rel = p - w.p0
    end = rel[-1]
    h = end[:2]
    r_h = float(np.linalg.norm(h))
    target = w.z_end - w.p0[2]
    r = math.hypot(r_h, float(end[2]))
    if r_h < 1e-6 or r < 0.05:
        return Swing(p[1:], {"tilt_deg": 0.0, "note": "path too short to tilt", "applied_mm": 0.0})
    u = h / r_h
    along, z = rel[:, :2] @ u, rel[:, 2]
    alpha = math.asin(max(-1.0, min(1.0, target / r))) - math.atan2(float(end[2]), r_h)
    c, s = math.cos(alpha), math.sin(alpha)
    na, nz = c * along - s * z, s * along + c * z
    out = p.copy()
    out[:, :2] = w.p0[:2] + np.outer(na, u) + (rel[:, :2] - np.outer(along, u))
    out[:, 2] = w.p0[2] + nz
    return Swing(out[1:], {"tilt_deg": math.degrees(alpha), "applied_mm": _applied(out[1:], ctx)})


def _f2f_metrics(d, w, pf, vf):
    """Flat-to-flat quantities every flat-to-flat method reports: the window, the
    height difference and end velocity of the plain integration, and the two
    constant accelerations they imply (equal when the error is a constant
    acceleration)."""
    T = float(d.t[d.f1] - d.t[d.f0])
    dz = float(pf[-1, 2] - pf[0, 2])
    return {"T_f2f": T, "dz": dz, "v_end": float(vf[-1, 2]), "a_p": 2.0 * dz / (T * T),
            "a_v": float(vf[-1, 2]) / T}


@method("benoussaad")
def _benoussaad(d, w, ctx):
    """Baseline (Benoussaad et al. 2016, Sensors 16(1):12): strides segmented at
    foot-flat, v = 0 and the start height there, velocity and vertical
    displacement each de-drifted linearly between the two foot-flats."""
    pf, vf = ctx["f2f"]
    t = d.t[d.f0:d.f1 + 1]
    T = t[-1] - t[0]
    s = ((t - t[0]) / T)[:, None]
    v = vf - vf[-1] * s                               # velocity de-drift, all axes
    p = np.empty_like(pf)
    p[0] = pf[0]
    for j in range(1, len(p)):
        p[j] = p[j - 1] + v[j] * d.dt[d.f0 + j]
    p[:, 2] -= (p[-1, 2] - pf[0, 2]) * s[:, 0]        # displacement de-drift, vertical
    a, e = w.i0 + 1 - d.f0, w.e - d.f0
    out = p[a:e + 1]
    m = _f2f_metrics(d, w, pf, vf)
    m["start_gap_mm"] = float(np.linalg.norm(p[w.i0 - d.f0] - w.p0) * 1000.0)
    m["applied_mm"] = _applied(out, ctx)
    return Swing(out, m)


@method("quadratic_dz")
def _quadratic_dz(d, w, ctx):
    """Flat-to-flat, one constant vertical acceleration fitted from the end
    height difference (level ground: the two foot-flats are at one height)."""
    pf, vf = ctx["f2f"]
    t = d.t[d.f0:d.f1 + 1]
    T = t[-1] - t[0]
    m = _f2f_metrics(d, w, pf, vf)
    da = -2.0 * m["dz"] / (T * T)
    p = pf.copy()
    p[:, 2] += 0.5 * da * (t - t[0]) ** 2
    a, e = w.i0 + 1 - d.f0, w.e - d.f0
    out = p[a:e + 1]
    m["da_fit"] = da
    m["start_gap_mm"] = float(np.linalg.norm(p[w.i0 - d.f0] - w.p0) * 1000.0)
    m["applied_mm"] = _applied(out, ctx)
    return Swing(out, m)


# -- how well the contact model's boundaries agree with the data -------------------------------
def sensor_in_foot(d):
    """The IMU position in the foot frame (x along the foot from the heel, y, z up
    from the sole), recovered from the heel lever arm: r_heel = C (0 - s)."""
    return -d.C.T @ d.r["heel"]


def implied_pivot_x(d, k, v_ref):
    """The pivot position (m from the heel, on the floor, along the foot) that makes
    the rigid-pivot velocity -w x R C (pivot - sensor) equal v_ref at row k. Linear in
    the position: v = a + x b. Returns (x, residual m/s)."""
    s = sensor_in_foot(d)
    R = d.rot[k]
    w = R @ d.omega[k]
    a = -np.cross(w, R @ (d.C @ (np.zeros(3) - s)))
    b = -np.cross(w, R @ (d.C @ np.array([1.0, 0.0, 0.0])))
    x = float(b @ (v_ref - a) / max(float(b @ b), 1e-12))
    return x, float(np.linalg.norm(v_ref - (a + x * b)))


def boundary_metrics(d, w, ctx, pos):
    """Does the foot model's rigid-pivot kinematics agree with the data at the two
    boundaries? The reference is the foot-flat to foot-flat integration (zero velocity
    at both ends, no lever arm, closes to a few mg on real steps), so these are
    independent of the method drawn. Toe-off: the residual of the kinematic start
    velocity with the pivot at the ball and at the toe tip, and the pivot position the
    data implies (mm from the heel; the ball is at L2, the tip at L2 + L1). Heel
    strike: the residual of the heel-pinned velocity at the FSR heel strike."""
    pf, vf = ctx["f2f"]
    vB0 = vf[w.i0 - d.f0]
    vBe = vf[w.e - d.f0]
    rot, om = d.rot[w.i0], d.omega[w.i0]
    kin_ball = -np.cross(rot @ om, rot @ d.r["ball"])
    kin_tip = -np.cross(rot @ om, rot @ d.r["toe"])
    xp, _ = implied_pivot_x(d, w.i0, vB0)
    rise_int = float(pf[w.i0 - d.f0, 2] - pf[0, 2])           # sensor rise, start flat to toe-off
    rise_model = float(pos[w.i0, 2] - pos[d.f0, 2])
    return {"pivot_mm": xp * 1000.0, "rise_int_mm": rise_int * 1000.0,
            "rise_model_mm": rise_model * 1000.0,
            "res_ball_mms": float(np.linalg.norm(kin_ball - vB0)) * 1000.0,
            "res_tip_mms": float(np.linalg.norm(kin_tip - vB0)) * 1000.0,
            "res_heel_mms": float(np.linalg.norm(w.v_end - vBe)) * 1000.0}


# -- assembling a method's step -------------------------------------------------------------
@dataclass
class StepPath:
    """One method's world-frame path through the whole step."""
    pos: np.ndarray                  # sensor, N x 3
    heel: np.ndarray
    ball: np.ndarray
    toe: np.ndarray
    state: list
    metrics: dict


def toe_dir_from(d, rot):
    fwd = rot @ d.C[:, 0]
    flat = np.array([fwd[0], fwd[1], 0.0])
    n = float(np.linalg.norm(flat))
    return flat / n if n > 1e-6 else np.array([1.0, 0.0, 0.0])


def assemble(d, w, i0r, state_eff, pos_pre, vel_pre, swing, metrics):
    """Contact before lift-off (kinematics), the method's swing, then the contact
    after heel strike by its own kinematics about the landing anchor (the heel, or
    the ball after a toe strike) put on the floor where the swing ended."""
    n = len(d.t)
    pos = pos_pre.copy()
    vel = vel_pre.copy()
    pos[i0r + 1:w.e] = swing.p[:-1]
    arm_e = d.rot[w.e] @ d.r[w.key]
    anchor_land = on_ground(d, swing.p[-1] + arm_e)
    contact_track(d, w.e, n, state_eff,
                  lambda k, s: anchor_land, pos, vel)
    # the foot at every row, with the lift-off ball-joint angle for the swing rows
    mtp0 = d.mtp0.copy()
    lift_t = list(d.lift_t)
    toe_dir = d.toe_dir.copy()
    heel_p = np.empty((n, 3))
    ball_p = np.empty((n, 3))
    toe_p = np.empty((n, 3))
    # ball-joint angle at lift-off, as FootModel._enter(swing) computes it
    h0, b0, t0 = foot_points(d.r, d.L1, d.C, d.rot[i0r], pos[i0r], state_eff[i0r],
                             d.toe_dir[min(i0r, d.i0)], 0.0, None, d.t[i0r])
    mtp_lift = 0.0
    if state_eff[i0r] == "toe":
        rear = (b0 - h0) / d.L2
        front = (t0 - b0) / d.L1
        left = d.rot[i0r + 1] @ d.C[:, 1]
        mtp_lift = math.atan2(float(np.cross(rear, front) @ left), float(rear @ front))
    tail_toe_dir = None
    for k in range(n):
        s = state_eff[k]
        if s == "swing":
            m, lt, td = mtp_lift, float(d.t[i0r]), d.toe_dir[min(i0r, d.i0)]
        elif s == "toe" and k >= w.e:
            if tail_toe_dir is None:
                tail_toe_dir = toe_dir_from(d, d.rot[k])
            m, lt, td = 0.0, None, tail_toe_dir
        elif s == "toe":
            m, lt, td = d.mtp0[k], d.lift_t[k], d.toe_dir[min(k, d.i0)] if k > d.i0 else d.toe_dir[k]
        else:
            m, lt, td = d.mtp0[k], d.lift_t[k], d.toe_dir[k]
        heel_p[k], ball_p[k], toe_p[k] = foot_points(d.r, d.L1, d.C, d.rot[k], pos[k], s, td,
                                                     m, lt, d.t[k])
    return StepPath(pos=pos, heel=heel_p, ball=ball_p, toe=toe_p, state=state_eff,
                    metrics=metrics)


# -- event refinement -------------------------------------------------------------------------
def refine_events(d):
    """Refine the FSR-timed lift-off and heel strike to within STEP_EVENT_WINDOW_S.
    Heel strike: the first large sample-to-sample jump of the unfiltered body
    accel magnitude (the impact, which any low-pass would smear away), if it stands clear of the swing's own jumps. Toe-off:
    the interior peak of the pitch rate about the foot's lateral axis. A shift is
    taken only when the signature is clear; otherwise the FSR time stands. Then the
    toe-off guard (always, unless STEP_TOEOFF_GUARD is None).
    Returns (i0r, i1r, info) with info the shifts in ms and what was found."""
    i0r, i1r, info = _refine(d)
    i0r, info["toe_off_guard"] = toe_off_guard(d, i0r)
    return i0r, i1r, info


def toe_off_guard(d, i0):
    """STEP_TOEOFF_GUARD: a toe-off placed after the push-off has ended (the pitch rate about
    the lateral axis down to under the guard fraction of its peak since foot-flat, or reversed)
    moves back to that peak. Returns (row, None) or (row, {"ms": shift, "frac": fraction})."""
    if cfg.STEP_TOEOFF_GUARD is None or i0 <= d.f0:
        return i0, None
    lat = np.degrees(d.omega @ d.C[:, 1])
    seg = lat[d.f0:i0 + 1]
    k = int(np.argmax(np.abs(seg)))
    peak = float(seg[k])
    if abs(peak) < cfg.STEP_EVENT_MIN_PEAK_DPS or d.f0 + k == i0:
        return i0, None
    frac = float(lat[i0]) / peak
    if frac >= cfg.STEP_TOEOFF_GUARD:
        return i0, None
    i0g = d.f0 + k
    return i0g, {"ms": 1000.0 * float(d.t[i0g] - d.t[i0]), "frac": frac}


def toe_phase_missing(state):
    """True when the FSR row labels show no toe row between the start foot-flat and the
    longest swing (flat > swing, or flat > heel > swing): the push-off was not seen.
    Labels only, so the recorder can ask it before it has built any arrays."""
    span = longest_swing(state)
    if span is None:
        return False
    i0 = span[0] - 1
    j = 0
    while j < len(state) and state[j] == "flat":
        j += 1
    if j == 0 or i0 < j - 1:
        return False
    return not any(s == "toe" for s in state[j:i0 + 1])


def repair_toe_phase(d):
    """STEP_TOE_REPAIR: rebuild the toe phase of a step whose FSRs missed it (see config.py).
    Returns None (nothing to do, or off), {"refused": why} (looked like a missed toe phase but
    the gyro does not show a clear push-off) or the figures of the repair; on a repair the
    labels, d.f0, d.i0, the anchors and the toe direction of the step are changed in place and
    the FSR ones are kept in d.notes["fsr_f0"], ["fsr_i0"]."""
    if not cfg.STEP_TOE_REPAIR or not toe_phase_missing(d.state):
        return None
    n = len(d.t)
    gyro = np.degrees(np.linalg.norm(d.omega, axis=1))
    quiet = [k for k in range(d.f0 + 1) if d.state[k] == "flat" and gyro[k] < cfg.STEP_TOE_REPAIR_STILL_DPS]
    if len(quiet) < 5:
        return {"refused": "no still foot-flat before the push-off in the recorded rows"}
    fz = np.array([float((d.rot[k] @ d.C[:, 0])[2]) for k in range(n)])
    rise = d.L2 * (float(np.median(fz[quiet[:40]])) - fz)          # heel above its flat height, toe down positive
    sm = np.convolve(rise, np.ones(5) / 5.0, mode="same")
    se = min(int(np.searchsorted(d.t, d.t[d.i0] + cfg.STEP_TOE_REPAIR_SEARCH_S)), d.i1 - 3, n - 1)
    kr = next((k for k in range(quiet[0] + 1, se + 1) if sm[k] > cfg.STEP_TOE_REPAIR_RISE_M), None)
    if kr is None:
        return {"refused": "the heel never rose {:.0f} mm in the gyro attitude".format(1000.0 * cfg.STEP_TOE_REPAIR_RISE_M)}
    kmax = kr + int(np.argmax(sm[kr:se + 1]))
    k_ho = kr
    while k_ho > quiet[0] and sm[k_ho] > cfg.STEP_TOE_REPAIR_HEELOFF_M:
        k_ho -= 1
    if k_ho > d.f0 + 2:
        # a heel that only rises after the FSRs said the foot had left is a swing, not a missed push-off
        # (a backward step: the toe lifts about the heel, the heel rises later in the swing)
        return {"refused": "the heel rose {:.0f} ms after the FSR lift-off, not before it".format(
            1000.0 * float(d.t[k_ho] - d.t[d.f0]))}
    lat = np.degrees(d.omega @ d.C[:, 1])
    k_to = k_ho + int(np.argmax(np.abs(lat[k_ho:kmax + 1])))
    peak = float(lat[k_to])
    if abs(peak) < cfg.STEP_EVENT_MIN_PEAK_DPS:
        return {"refused": "no push-off pitch rate (peak {:.0f} deg/s)".format(abs(peak))}
    k_ho = min(k_ho, d.f0)
    toe_s = float(d.t[k_to] - d.t[k_ho])
    if k_ho < 1 or toe_s < 0.04 or toe_s > cfg.STEP_TOE_REPAIR_MAX_S:
        return {"refused": "heel-off to toe-off {:.2f} s is not a push-off".format(toe_s)}
    if float(d.t[d.i1] - d.t[k_to]) < cfg.STEP_MIN_SWING_S:
        return {"refused": "no swing left after the push-off"}

    f0_old, i0_old = d.f0, d.i0
    seq = []
    for lab in d.state[f0_old:i0_old + 2]:
        if not seq or seq[-1] != lab:
            seq.append(lab)
    for k in range(k_ho + 1, k_to + 1):
        d.state[k] = "toe"
    for k in range(k_to + 1, max(i0_old, k_to) + 1):
        d.state[k] = "swing"
    # the ball anchored where the flat foot stood, as FootModel._enter("toe") does
    ke = k_ho + 1
    anchor = on_ground(d, d.pos_live[k_ho] + d.rot[ke] @ d.r["ball"])
    fwd = d.rot[ke] @ d.C[:, 0]
    flat = np.array([fwd[0], fwd[1], 0.0])
    norm = float(np.linalg.norm(flat))
    toe_dir = flat / norm if norm > 1e-6 else np.array([1.0, 0.0, 0.0])
    for k in range(ke, k_to + 1):
        d.anchor[k] = anchor.copy()
        d.toe_dir[k] = toe_dir
    d.f0, d.i0 = k_ho, k_to
    d.notes["fsr_f0"], d.notes["fsr_i0"] = f0_old, i0_old
    return {"fsr": ">".join(seq), "heel_off_ms": 1000.0 * float(d.t[k_ho] - d.t[f0_old]),
            "toe_off_ms": 1000.0 * float(d.t[k_to] - d.t[i0_old]), "peak_dps": abs(peak),
            "rise_mm": 1000.0 * float(sm[k_to]), "toe_s": toe_s}


def _refine(d):
    i0, i1 = d.i0, d.i1
    info = {"toe_off_ms": 0.0, "heel_strike_ms": 0.0, "toe_off_found": False,
            "heel_strike_found": False}
    which = cfg.STEP_REFINE_EVENTS
    if not which or d.acc_raw is None:
        return i0, i1, info
    n_w = max(1, int(round(cfg.STEP_EVENT_WINDOW_S * d.fs)))
    n = len(d.t)
    i0r, i1r = i0, i1

    # heel strike: first contact row e = i1 + 1 moves to the impact row
    jump = np.zeros(n)
    jump[1:] = np.abs(np.diff(np.linalg.norm(d.acc_raw, axis=1)))
    lo, hi = max(d.i0 + 3, i1 + 1 - n_w), min(n - 2, i1 + 1 + n_w)
    if "heel_strike" in which and hi > lo:
        peak = float(jump[lo:hi + 1].max())
        # the impact is the first jump that is a substantial part of the largest,
        # not the largest itself: the ring-down after it can be as big
        k = lo + int(np.argmax(jump[lo:hi + 1] >= 0.6 * peak))
        base = float(np.median(jump[d.i0 + 1:i1 + 1])) + 1e-9
        if peak >= cfg.STEP_EVENT_MIN_JUMP and peak >= 4.0 * base:
            i1r = k - 1
            info["heel_strike_found"] = True
            info["heel_strike_ms"] = 1000.0 * float(d.t[i1r] - d.t[i1])

    # toe-off: the interior peak of the pitch rate about the lateral axis
    lat = np.degrees(d.omega @ d.C[:, 1])
    lo, hi = max(d.f0 + 2, i0 - n_w), min(i1r - 3, i0 + n_w)
    if "toe_off" in which and hi - lo >= 2:
        seg = np.abs(lat[lo:hi + 1])
        j = int(np.argmax(seg))
        if 0 < j < len(seg) - 1 and seg[j] >= cfg.STEP_EVENT_MIN_PEAK_DPS:
            i0r = lo + j
            info["toe_off_found"] = True
            info["toe_off_ms"] = 1000.0 * float(d.t[i0r] - d.t[i0])
    return i0r, i1r, info


# -- the whole offline chain -----------------------------------------------------------------------
def run_methods(d, names):
    """Event refinement, the pre-swing contact, then every named method over the
    same window. Returns (paths {name: StepPath}, i0r, i1r, info, window)."""
    i0r, i1r, info = refine_events(d)
    state_eff = effective_states(d, i0r, i1r)
    pos_pre, vel_pre = pre_swing(d, i0r, state_eff)
    w = make_window(d, i0r, i1r, pos_pre, vel_pre, state_eff)
    v_b = np.zeros((len(d.t), 3))
    for k in range(1, len(d.t)):
        v_b[k] = v_b[k - 1] + d.lin[k] * d.dt[k]
    ctx = {"v0_int": v_b[i0r].copy(), "v_b_all": v_b}
    ctx["f2f"] = flat_to_flat(d, pos_pre)
    # none first: the others are measured against it
    order = ["none"] + [m for m in names if m != "none"]
    paths = {}
    for name in order:
        if name not in METHODS:
            raise KeyError("unknown swing method '{}'; registered: {}".format(
                name, sorted(METHODS)))
        sw = METHODS[name](d, w, ctx)
        m = dict(sw.metrics)
        m.setdefault("applied_mm", 0.0)
        paths[name] = assemble(d, w, i0r, state_eff, pos_pre, vel_pre, sw, m)
    ctx["window"] = w
    ctx["boundary"] = boundary_metrics(d, w, ctx, pos_pre)
    return paths, i0r, i1r, info, ctx
