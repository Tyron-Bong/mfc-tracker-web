"""Packed sessions (.mfcrec): the records of a .mfcraw stored as integer columns and
compressed with xz, so a session takes about a third of the space and every motion
frame comes back byte for byte.

A motion record holds exactly one wire frame. Its header (base timestamp, seq, count,
interval, flags) and its samples are split per sensor type into columns, each stored
as a difference from the row before it (the sample offset within a frame as a
difference inside the frame), in the smallest integer width that holds it, byte planes
together. Anything that is not a well-formed frame (text, key events, a damaged
notification) is kept as raw bytes, so the unpacked records are the packed ones. The
arrival time of a record is kept to the microsecond; nothing downstream reads the PC
clock closer than that (the frame's own timestamps carry the sample times).

  pack_records(records) -> bytes      unpack_records(blob) -> [(kind, t, payload)]

Ref: "Run captures and sessions" in docs/mfc_processing_reference.md.
"""

import lzma
import struct

import numpy as np

from .wire import (FLAG_BATT, FLAG_FSR, FLAG_IMU, FLAG_MAG, HEADER_FMT, HEADER_SIZE,
                   SAMPLE_SIZE)

PACKED_MAGIC = b"MFCREC\x00"
PACKED_FORMAT_VERSION = 2
T_MOTION = 1
TIME_STEP_US = 1e-6

_HDR = np.dtype([("base", "<u4"), ("seq", "u1"), ("count", "u1"), ("iv", "<u2"),
                 ("flags", "u1")])
_FIELDS = {
    FLAG_IMU: ("<u2",) + ("<i2",) * 6,       # dt, ax ay az gx gy gz
    FLAG_MAG: ("<u2",) + ("<i2",) * 3,       # dt, mx my mz
    FLAG_FSR: ("<u2",) * 3,                  # dt, toe, heel
    FLAG_BATT: ("<u2", "u1", "<u2", "u1"),   # dt, percent, millivolts, source flags
}
_SAMPLE = {f: np.dtype([("c%d" % i, t) for i, t in enumerate(fs)]) for f, fs in _FIELDS.items()}
assert _HDR.itemsize == HEADER_SIZE
assert all(_SAMPLE[f].itemsize == SAMPLE_SIZE[f] for f in _SAMPLE)

_WIDTHS = ((0, None), (1, np.int8), (2, np.int16), (3, np.int32), (4, np.int64))   # 0 = raw bytes


# -- blobs: named integer arrays or raw bytes ------------------------------------
def _put(blobs, name, data):
    if isinstance(data, (bytes, bytearray)):
        blobs.append((name, 0, len(data), bytes(data)))
        return
    a = np.asarray(data, dtype=np.int64).ravel()
    lo, hi = (int(a.min()), int(a.max())) if len(a) else (0, 0)
    for code, dt in _WIDTHS[1:]:
        info = np.iinfo(dt)
        if info.min <= lo and hi <= info.max:
            break
    b = a.astype(dt)
    planes = b.view(np.uint8).reshape(-1, b.dtype.itemsize).T.copy().tobytes()
    blobs.append((name, code, len(a), planes))


def _serialise(blobs):
    out = [struct.pack("<I", len(blobs))]
    for name, code, n, data in blobs:
        nb = name.encode("ascii")
        out.append(struct.pack("<B", len(nb)) + nb + struct.pack("<BII", code, n, len(data)) + data)
    return b"".join(out)


def _parse(buf):
    (count,) = struct.unpack_from("<I", buf, 0)
    off, out = 4, {}
    for _ in range(count):
        ln = buf[off]
        name = buf[off + 1:off + 1 + ln].decode("ascii")
        off += 1 + ln
        code, n, nbytes = struct.unpack_from("<BII", buf, off)
        off += 9
        data = buf[off:off + nbytes]
        off += nbytes
        if code == 0:
            out[name] = bytes(data)
        else:
            dt = np.dtype(dict(_WIDTHS)[code])
            planes = np.frombuffer(data, dtype=np.uint8).reshape(dt.itemsize, n)
            out[name] = np.ascontiguousarray(planes.T).view(dt).ravel().astype(np.int64)
    return out


# -- frames ------------------------------------------------------------------------
def _frame_of(payload):
    """(flags, count) of a payload that is exactly one well-formed wire frame, else None."""
    if len(payload) < HEADER_SIZE:
        return None
    _, _, count, _, flags = struct.unpack_from(HEADER_FMT, payload, 0)
    size = SAMPLE_SIZE.get(flags)
    if size is None or count == 0 or len(payload) != HEADER_SIZE + count * size:
        return None
    return flags, count


def _starts(counts):
    return np.concatenate(([0], np.cumsum(counts)[:-1])).astype(np.int64)


def _pack_frames(blobs, flag, heads, bodies):
    hdr = np.frombuffer(b"".join(heads), dtype=_HDR)
    counts = hdr["count"].astype(np.int64)
    _put(blobs, "h%d.base" % flag, np.diff(hdr["base"].astype(np.int64), prepend=0))
    _put(blobs, "h%d.seq" % flag, np.diff(hdr["seq"].astype(np.int64), prepend=0) % 256)
    _put(blobs, "h%d.count" % flag, counts)
    _put(blobs, "h%d.iv" % flag, hdr["iv"].astype(np.int64))
    smp = np.frombuffer(b"".join(bodies), dtype=_SAMPLE[flag])
    starts = _starts(counts)
    for i, name in enumerate(smp.dtype.names):
        c = smp[name].astype(np.int64)
        d = np.diff(c, prepend=0)
        if i == 0:                                   # the offset within a frame
            d[starts] = c[starts]
        _put(blobs, "s%d.%d" % (flag, i), d)


def _unpack_frames(cols, flag):
    base = np.cumsum(cols["h%d.base" % flag])
    seq = np.cumsum(cols["h%d.seq" % flag]) % 256
    counts = cols["h%d.count" % flag]
    hdr = np.empty(len(counts), dtype=_HDR)
    hdr["base"], hdr["seq"], hdr["count"] = base, seq, counts
    hdr["iv"], hdr["flags"] = cols["h%d.iv" % flag], flag
    n = int(counts.sum())
    smp = np.empty(n, dtype=_SAMPLE[flag])
    starts = _starts(counts)
    for i, name in enumerate(smp.dtype.names):
        d = cols["s%d.%d" % (flag, i)]
        if i == 0:
            cs = np.cumsum(d)
            # intp: the repeat counts must be the platform's index type (32-bit in the browser)
            c = cs - np.repeat(cs[starts] - d[starts], counts.astype(np.intp))
        else:
            c = np.cumsum(d)
        smp[name] = c
    return hdr.tobytes(), smp.tobytes(), counts


# -- the container -----------------------------------------------------------------
def pack_records(records):
    """records: iterable of (kind, t seconds, payload bytes). Returns the file bytes."""
    kinds, modes, flagcol, tus, raw_len, raw = [], [], [], [], [], []
    frames = {f: ([], []) for f in _SAMPLE}
    for kind, t, payload in records:
        kinds.append(kind)
        tus.append(int(round(t / TIME_STEP_US)))
        fr = _frame_of(payload) if kind == T_MOTION else None
        if fr is None:
            modes.append(1)
            raw_len.append(len(payload))
            raw.append(bytes(payload))
        else:
            modes.append(0)
            flagcol.append(fr[0])
            frames[fr[0]][0].append(payload[:HEADER_SIZE])
            frames[fr[0]][1].append(payload[HEADER_SIZE:])
    blobs = []
    _put(blobs, "kind", kinds)
    _put(blobs, "mode", modes)
    _put(blobs, "flag", flagcol)
    _put(blobs, "t_us", np.diff(np.array(tus, dtype=np.int64), prepend=0))
    _put(blobs, "raw_len", raw_len)
    _put(blobs, "raw", b"".join(raw))
    for flag, (heads, bodies) in frames.items():
        if heads:
            _pack_frames(blobs, flag, heads, bodies)
    body = lzma.compress(_serialise(blobs), format=lzma.FORMAT_XZ, preset=9)
    return PACKED_MAGIC + struct.pack("<H", PACKED_FORMAT_VERSION) + body


def unpack_records(blob):
    """The records pack_records was given: [(kind, t, payload)], t to the microsecond."""
    if blob[:len(PACKED_MAGIC)] != PACKED_MAGIC:
        raise ValueError("not a packed session (.mfcrec)")
    (version,) = struct.unpack_from("<H", blob, len(PACKED_MAGIC))
    if version != PACKED_FORMAT_VERSION:
        raise ValueError("packed session format {}; this receiver reads format {}".format(
            version, PACKED_FORMAT_VERSION))
    try:
        cols = _parse(lzma.decompress(blob[len(PACKED_MAGIC) + 2:]))
    except (lzma.LZMAError, struct.error, IndexError, KeyError) as exc:
        raise ValueError("the packed session is damaged or cut short ({})".format(exc))
    kinds, modes = cols["kind"], cols["mode"]
    t = np.cumsum(cols["t_us"]) * TIME_STEP_US
    flags = cols["flag"]
    raw_len, raw = cols["raw_len"], cols["raw"]
    parts = {}
    for flag in _SAMPLE:
        if "h%d.base" % flag in cols:
            hbytes, sbytes, counts = _unpack_frames(cols, flag)
            parts[flag] = [hbytes, sbytes, counts, 0, 0, 0]       # next frame, next sample, next raw
    out, fi, ri, roff = [], 0, 0, 0
    for i in range(len(kinds)):
        if modes[i] == 0:
            flag = int(flags[fi])
            fi += 1
            hbytes, sbytes, counts, k, soff, _ = parts[flag]
            n = int(counts[k]) * SAMPLE_SIZE[flag]
            payload = hbytes[k * HEADER_SIZE:(k + 1) * HEADER_SIZE] + sbytes[soff:soff + n]
            parts[flag][3], parts[flag][4] = k + 1, soff + n
        else:
            n = int(raw_len[ri])
            payload = raw[roff:roff + n]
            ri += 1
            roff += n
        out.append((int(kinds[i]), float(t[i]), payload))
    return out


def same_records(a, b):
    """True if two record lists carry identical payloads and kinds and arrival times
    within the packed resolution."""
    if len(a) != len(b):
        return False
    for (k1, t1, p1), (k2, t2, p2) in zip(a, b):
        if k1 != k2 or bytes(p1) != bytes(p2) or abs(t1 - t2) > 0.6 * TIME_STEP_US:
            return False
    return True
