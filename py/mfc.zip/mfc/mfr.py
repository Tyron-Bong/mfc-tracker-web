"""The tracker's own run file (/runs/NAME.mfr, written by firmware/mfc_offline.py).

  line 1   JSON header, ends with "\\n":  {"mfr": 1, "wire": 1, "name": ..., "steps": N,
           "status": [the tracker's status lines], ...}
  then     records [type u8][length u16 LE][payload] until the end of the file

  1  motion frame      the exact bytes the unit would have streamed (wire format 1)
  5  compact frame     the same frame as changes from the one before it (firmware/mfc_codec.py,
                       receiver/mfc/mfrcodec.py). parse() gives it back as a type 1 record with
                       the very same bytes, so a reader never sees the difference. A header with
                       "enc": 2 says the unit wrote them; older files have type 1 records only
  2  status text       one line, UTF-8, no newline
  4  end              <II duration in milliseconds, number of frames; the last record of a
                       run that was stopped (a file without it was cut short)
  3  marker            <I device microseconds of the moment it marks, then its name
                       (recal = start of the stand-still for R, fsr_cal = start of the
                       lifted foot for U, sync = a stomp, anything else is kept as a note)

A file cut short by a power loss ends in a partial record, which is dropped. Ref:
"Offline recording" in docs/mfc_processing_reference.md and docs/firmware_reference.md.
"""

import json
import struct

from .mfrcodec import Decoder

FORMAT = 1
T_FRAME, T_TEXT, T_MARK, T_END, T_CFRAME = 1, 2, 3, 4, 5
_REC = struct.Struct("<BH")


def parse(data):
    """(header dict, [(type, payload)]) of the bytes of an .mfr file."""
    nl = data.find(b"\n")
    if nl < 0:
        raise ValueError("not a tracker run file (no header line)")
    try:
        header = json.loads(data[:nl].decode("utf-8"))
    except ValueError as exc:
        raise ValueError("unreadable run header: {}".format(exc))
    if header.get("mfr") != FORMAT:
        raise ValueError("run file format {}; this receiver reads format {}".format(
            header.get("mfr"), FORMAT))
    records, off = [], nl + 1
    codec = Decoder()
    while off + _REC.size <= len(data):
        kind, n = _REC.unpack_from(data, off)
        if off + _REC.size + n > len(data):
            break                                     # cut short, drop the partial record
        payload = bytes(data[off + _REC.size:off + _REC.size + n])
        if kind == T_CFRAME:
            try:
                payload = codec.decode(payload)
            except ValueError as exc:
                raise ValueError("run file damaged at record {}: {}".format(len(records), exc))
            kind = T_FRAME
        records.append((kind, payload))
        off += _REC.size + n
    return header, records


def build(header, records):
    """The bytes of an .mfr file (the tests and the simulated tracker use this)."""
    head = dict(header, mfr=FORMAT)
    out = [json.dumps(head, separators=(",", ":")).encode("utf-8") + b"\n"]
    for kind, payload in records:
        out.append(_REC.pack(kind, len(payload)) + bytes(payload))
    return b"".join(out)


def marker(payload):
    """(device microseconds, name) of a marker record."""
    (us,) = struct.unpack_from("<I", payload, 0)
    return us, payload[4:].decode("utf-8", "replace")


def marker_payload(us, name):
    return struct.pack("<I", us & 0xFFFFFFFF) + name.encode("utf-8")
