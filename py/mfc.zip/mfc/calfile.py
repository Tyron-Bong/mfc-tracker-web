"""The persisted calibration (accel_drift_variables.json) and everything in it.

One file holds the C, T, U and I results so they can never be applied out of
step. Written atomically. Do not hand-edit; it is regenerated per device.
"""

import json
import os
import time

import numpy as np

from . import config as cfg
from .mathutil import fmt_vec


class Calibration:
    def __init__(self, path):
        self.path = path
        # C: accelerometer and magnetometer
        self.accel_bias = np.zeros(3)         # m/s^2, raw sensor units
        self.accel_scale = np.ones(3)
        self.g_local = None                   # m/s^2, fitted radius; None until a C
        self.mag_bias = np.zeros(3)           # uT, hard iron
        self.mag_scale = np.ones(3)           # soft iron, diagonal only
        self.mag_norm_fit = None              # uT, field magnitude the fit settled on
        # T: drift bias
        self.accel_drift_bias = np.zeros(3)   # m/s^2, after bias and scale
        self.drift_count = 0
        # U: FSR lifted level
        self.fsr_lifted = np.zeros(2)
        self.fsr_noise = np.zeros(2)
        self.fsr_present = False              # a lifted level was read from the file
        # I: foot segment lengths. Only a measured length is written to the file,
        # so editing FOOT_L1_M / FOOT_L2_M keeps working until I is run.
        self.foot_L1 = cfg.FOOT_L1_M
        self.foot_L2 = cfg.FOOT_L2_M
        self.foot_len_source = "hardcoded"
        self.foot_len_meta = None
        self.report = "no accel calibration on file"

    def load(self):
        """Pull the persisted values. Anything missing keeps its current value."""
        def vec3(data, key):
            if key not in data:
                return None
            v = np.asarray(data[key], dtype=float)
            if v.shape != (3,) or not np.all(np.isfinite(v)):
                raise ValueError(f"{key} is not a finite 3-vector")
            return v

        try:
            with open(self.path, "r") as fh:
                data = json.load(fh)
        except FileNotFoundError:
            print(f"[cal] no {os.path.basename(self.path)} yet, running uncalibrated. "
                  "Press C to build one.")
            return
        except Exception as e:                          # noqa: BLE001
            print(f"[cal] calibration file unreadable ({e}), running uncalibrated")
            return

        try:
            for key, attr in (("accel_bias", "accel_bias"),
                              ("accel_scale", "accel_scale"),
                              ("accel_drift_bias", "accel_drift_bias"),
                              ("mag_bias", "mag_bias"), ("mag_scale", "mag_scale")):
                v = vec3(data, key)
                if v is not None:
                    setattr(self, attr, v)
            g = data.get("g_local")
            self.g_local = float(g) if g else None
            norm = data.get("mag_norm")
            if "mag_scale" in data:
                self.mag_norm_fit = float(norm) if norm else None
            self.drift_count = int(data.get("drift_captures", 0))
        except Exception as e:                          # noqa: BLE001
            print(f"[cal] calibration file malformed ({e}), running uncalibrated")
            self.accel_bias, self.accel_scale = np.zeros(3), np.ones(3)
            self.accel_drift_bias, self.g_local = np.zeros(3), None
            return

        fsr = data.get("fsr_lifted")
        if fsr is not None:
            try:
                self.fsr_lifted = np.array([float(fsr[0]), float(fsr[1])])
                self.fsr_noise = np.asarray(data.get("fsr_noise", [0.0, 0.0]), dtype=float)
                self.fsr_present = True
            except Exception as e:                      # noqa: BLE001
                print(f"[cal] FSR level malformed ({e}), press U to recapture")

        if "foot_L1_m" in data and "foot_L2_m" in data:
            try:
                l1, l2 = float(data["foot_L1_m"]), float(data["foot_L2_m"])
                if not (cfg.FOOTCAL_L1_RANGE_M[0] <= l1 <= cfg.FOOTCAL_L1_RANGE_M[1]
                        and cfg.FOOTCAL_L2_RANGE_M[0] <= l2 <= cfg.FOOTCAL_L2_RANGE_M[1]):
                    raise ValueError("outside the plausible range")
                self.foot_L1, self.foot_L2 = l1, l2
                self.foot_len_source = "gauge calibration"
                meta = data.get("foot_len_cal")
                self.foot_len_meta = meta if isinstance(meta, dict) else {}
                print("[cal] foot lengths: ball to heel {:.1f} mm, toe to ball {:.1f} mm"
                      .format(l2 * 1000.0, l1 * 1000.0))
            except Exception as e:                      # noqa: BLE001
                print(f"[cal] foot lengths in the file unusable ({e}), using the "
                      "hardcoded ones. Press I to measure them.")

        if self.mag_norm_fit:
            print(f"[cal] hard iron {fmt_vec(self.mag_bias)} uT  "
                  f"soft iron {fmt_vec(self.mag_scale)}  field {self.mag_norm_fit:.1f} uT")
        if self.g_local:
            self.report = "accel cal: {} poses, {}, resid {:.1f} mm/s²".format(
                data.get("pose_count", "?"), data.get("fit_method", "?"),
                1000.0 * float(data.get("fit_residual_mps2", 0.0)))
            print(f"[cal] {self.report}")
            print(f"[cal] bias {fmt_vec(self.accel_bias)} m/s^2  "
                  f"scale {fmt_vec(self.accel_scale)}  g {self.g_local:.4f}")
        if np.any(self.accel_drift_bias):
            print(f"[cal] drift bias {fmt_vec(self.accel_drift_bias)} m/s^2 "
                  f"({self.drift_count} capture(s))")

    def save(self, fit=None):
        payload = {
            "accel_bias": [float(v) for v in self.accel_bias],
            "mag_bias": [float(v) for v in self.mag_bias],
            "mag_scale": [float(v) for v in self.mag_scale],
            "mag_norm": float(self.mag_norm_fit) if self.mag_norm_fit else None,
            "accel_scale": [float(v) for v in self.accel_scale],
            "accel_drift_bias": [float(v) for v in self.accel_drift_bias],
            "g_local": float(self.g_local) if self.g_local else None,
            "units": ("accel_bias m/s^2 and mag_bias uT in raw sensor units, the "
                      "scales unitless per axis, accel_drift_bias m/s^2 after bias "
                      "and scale"),
            "fsr_lifted": [float(v) for v in self.fsr_lifted],
            "fsr_noise": [float(v) for v in self.fsr_noise],
            "drift_captures": int(self.drift_count),
            "updated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        if self.foot_len_meta is not None:
            payload.update({"foot_L1_m": float(self.foot_L1),
                            "foot_L2_m": float(self.foot_L2),
                            "foot_len_cal": self.foot_len_meta})
        if fit:
            payload.update({"pose_count": int(fit["poses"]),
                            "fit_method": fit["method"],
                            "fit_residual_mps2": float(fit["residual"]),
                            "pose_coverage": float(fit["coverage"])})
        else:
            try:
                with open(self.path, "r") as fh:        # keep the C metadata intact
                    old = json.load(fh)
                for key in ("pose_count", "fit_method", "fit_residual_mps2",
                            "pose_coverage"):
                    if key in old:
                        payload[key] = old[key]
            except Exception:                           # noqa: BLE001
                pass

        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w") as fh:
                json.dump(payload, fh, indent=2)
            os.replace(tmp, self.path)                  # atomic, never a half file
            print(f"[cal] wrote {os.path.basename(self.path)}")
        except OSError as e:
            print(f"[cal] could not write calibration file: {e}")
