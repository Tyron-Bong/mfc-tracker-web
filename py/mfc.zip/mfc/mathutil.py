"""Pure math: quaternions, geometry helpers, and the sphere/ellipsoid fits.

No module state. Quaternions are [w, x, y, z], body to world.
"""

import math

import numpy as np

from . import config as cfg


def q_norm(q):
    n = math.sqrt(float(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]))
    return q / n if n > 1e-12 else np.array([1.0, 0.0, 0.0, 0.0])


def q_matrix(q):
    """Rotation matrix that maps a body vector to the world frame."""
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
    ])


def q_from_euler(roll, pitch, yaw):
    cr, sr = math.cos(roll / 2), math.sin(roll / 2)
    cp, sp = math.cos(pitch / 2), math.sin(pitch / 2)
    cy, sy = math.cos(yaw / 2), math.sin(yaw / 2)
    return q_norm(np.array([
        cr * cp * cy + sr * sp * sy,
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy,
    ]))


def euler_from_q(q):
    """Aerospace ZYX, in radians."""
    w, x, y, z = q
    roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    pitch = math.asin(max(-1.0, min(1.0, 2 * (w * y - z * x))))
    yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
    return roll, pitch, yaw


def q_from_matrix(m):
    """Quaternion [w, x, y, z] of a body-to-world rotation matrix (inverse of q_matrix)."""
    t = m[0, 0] + m[1, 1] + m[2, 2]
    if t > 0.0:
        s = 0.5 / math.sqrt(t + 1.0)
        q = [0.25 / s, (m[2, 1] - m[1, 2]) * s, (m[0, 2] - m[2, 0]) * s, (m[1, 0] - m[0, 1]) * s]
    elif m[0, 0] > m[1, 1] and m[0, 0] > m[2, 2]:
        s = 2.0 * math.sqrt(1.0 + m[0, 0] - m[1, 1] - m[2, 2])
        q = [(m[2, 1] - m[1, 2]) / s, 0.25 * s, (m[0, 1] + m[1, 0]) / s, (m[0, 2] + m[2, 0]) / s]
    elif m[1, 1] > m[2, 2]:
        s = 2.0 * math.sqrt(1.0 + m[1, 1] - m[0, 0] - m[2, 2])
        q = [(m[0, 2] - m[2, 0]) / s, (m[0, 1] + m[1, 0]) / s, 0.25 * s, (m[1, 2] + m[2, 1]) / s]
    else:
        s = 2.0 * math.sqrt(1.0 + m[2, 2] - m[0, 0] - m[1, 1])
        q = [(m[1, 0] - m[0, 1]) / s, (m[0, 2] + m[2, 0]) / s, (m[1, 2] + m[2, 1]) / s, 0.25 * s]
    return q_norm(np.array(q))


def q_integrate(q, omega_rad, dt):
    wx, wy, wz = omega_rad
    w, x, y, z = q
    dq = 0.5 * np.array([
        -x * wx - y * wy - z * wz,
        w * wx + y * wz - z * wy,
        w * wy - x * wz + z * wx,
        w * wz + x * wy - y * wx,
    ])
    return q_norm(q + dq * dt)


def wrap_pi(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def angle_deg(a, b):
    """Angle between two vectors, degrees. atan2 of cross and dot: exact at
    small angles, where acos is not."""
    return math.degrees(math.atan2(float(np.linalg.norm(np.cross(a, b))),
                                   float(np.dot(a, b))))


def rotate_about(v, axis, ang):
    """Rodrigues: v turned by ang about the unit axis, right-handed."""
    c, s_ = math.cos(ang), math.sin(ang)
    return v * c + np.cross(axis, v) * s_ + axis * float(axis @ v) * (1.0 - c)


def fmt_vec(v):
    return "[{:+.4f} {:+.4f} {:+.4f}]".format(*v)


# ---------------------------------------------------------------------------
# Sphere / ellipsoid fits (ref: "C: accelerometer and magnetometer fit")
# ---------------------------------------------------------------------------
def fit_sphere(M):
    """|m - b| = r, linear in (b, c) with c = |b|^2 - r^2."""
    design = np.column_stack((2.0 * M, -np.ones(len(M))))
    sol, *_ = np.linalg.lstsq(design, np.sum(M * M, axis=1), rcond=None)
    bias = sol[:3]
    rad2 = float(bias @ bias - sol[3])
    if not np.isfinite(rad2) or rad2 <= 0:
        return None
    return bias, np.ones(3), float(math.sqrt(rad2))


def fit_ellipsoid(M):
    """sum p_k m_k^2 + sum q_k m_k + r = 0, homogeneous, null space by SVD."""
    design = np.column_stack((M * M, M, np.ones(len(M))))
    vec = np.linalg.svd(design, full_matrices=False)[2][-1]
    p, q, r = vec[:3].copy(), vec[3:6].copy(), float(vec[6])
    if np.all(p < 0):                               # sign of the null vector
        p, q, r = -p, -q, -r
    if not np.all(p > 0):                           # not an ellipsoid at all
        return None
    bias = -q / (2.0 * p)
    lam = float(np.sum(bias * bias * p) - r)        # fixes the arbitrary scale
    if lam <= 0:
        return None
    sg = 1.0 / np.sqrt(p / lam)                     # per axis, this is s_k * g
    if not np.all(np.isfinite(sg)) or np.any(sg <= 0):
        return None
    g = float(np.exp(np.mean(np.log(sg))))          # common factor is gravity
    return bias, sg / g, g


def fit_residual(M, bias, scale, g):
    return float(np.sqrt(np.mean(
        (np.linalg.norm((M - bias) / scale, axis=1) - g) ** 2)))


def pose_coverage(M):
    """Smallest eigenvalue of the direction scatter matrix. 1/3 is a perfect
    spread; under POSE_MIN_COVERAGE one axis was barely turned."""
    d = M - M.mean(axis=0)
    n = np.linalg.norm(d, axis=1, keepdims=True)
    if np.any(n < 1e-9):
        return 0.0
    d = d / n
    return float(np.min(np.linalg.eigvalsh(d.T @ d / len(d))))


def fit_field(M, radius_range):
    """Better of sphere and ellipsoid by residual. Works for the accelerometer
    and the magnetometer alike (both trace a sphere at rest). Returns a report
    dict, or None."""
    coverage = pose_coverage(M)
    sphere = fit_sphere(M)
    ellipsoid = fit_ellipsoid(M) if len(M) >= cfg.POSE_MIN else None

    if ellipsoid is not None:
        bias, scale, g = ellipsoid
        plausible = (np.all(np.abs(scale - 1.0) < 0.15)
                     and radius_range[0] < g < radius_range[1]
                     and coverage >= cfg.POSE_MIN_COVERAGE)
        if not plausible:
            ellipsoid = None

    best, method = None, None
    for candidate, name in ((ellipsoid, "ellipsoid"), (sphere, "sphere")):
        if candidate is None:
            continue
        res = fit_residual(M, *candidate)
        if best is None or res < best[0]:
            best, method = (res, candidate), name
    if best is None:
        return None
    res, (bias, scale, g) = best
    return {"bias": bias, "scale": scale, "g": g, "residual": res,
            "method": method, "coverage": coverage, "poses": len(M)}


def fit_sine_bar(caps):
    """L from h = L sin(theta), least squares through the origin. Returns the
    fit, each gauge's own answer, and the worst disagreement as a fraction."""
    h = np.array([c["gauge_mm"] / 1000.0 for c in caps])
    sn = np.array([math.sin(math.radians(c.get("pitch_deg", c["theta_deg"])))
                   for c in caps])
    length = float(np.sum(h * sn) / np.sum(sn * sn))
    each = h / sn
    spread = float(np.max(np.abs(each - length)) / length)
    return length, each, spread
