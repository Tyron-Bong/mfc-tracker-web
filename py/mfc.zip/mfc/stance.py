"""FSR calibration (key U) and stance classification.

Stance is swing / heel / toe / flat from the two FSRs, zeroed by their lifted
level. Contact = raw >= lifted * (1 + FSR_CONTACT_FRACTION), released at
FSR_RELEASE of the excess, and a new stance must hold FSR_DEBOUNCE_S.
Ref: "FSR stance" in docs/mfc_processing_reference.md.
"""

from collections import deque

import numpy as np

from . import config as cfg

STANCE_NAMES = ("heel", "toe", "flat", "swing")


def loaded_levels(fsr, gyro_dps, on, still_dps, min_samples):
    """The raw level of each FSR when the foot is on the floor: the median over the samples
    where both sensors are over their contact level `on` and the foot is still (gyro under
    still_dps). fsr is rows (t, toe, heel), gyro_dps rows (t, magnitude); None if there are
    fewer than min_samples such samples. Ref: FSR_OFFLINE_SPLIT in config.py."""
    fsr = np.asarray(fsr, dtype=float)
    g = np.asarray(gyro_dps, dtype=float)
    if len(fsr) == 0 or len(g) == 0:
        return None
    k = np.clip(np.searchsorted(g[:, 0], fsr[:, 0]), 0, len(g) - 1)
    ok = (fsr[:, 1] >= on[0]) & (fsr[:, 2] >= on[1]) & (g[k, 1] < still_dps)
    if int(ok.sum()) < min_samples:
        return None
    return np.median(fsr[ok, 1:3], axis=0)


class StanceDetector:
    def __init__(self):
        self.on = np.zeros(2)               # contact threshold, counts
        self.cal_ok = False
        self.cal_report = "no FSR calibration on file"
        self.zero = np.zeros(2)             # raw minus lifted
        self.raw = np.zeros(2)              # last raw pair, for the calibration readout
        self.contact = [False, False]
        self.stance = "unknown"
        self.since = None
        self._cand = None
        self._cand_since = None
        self.calibrating = False
        self._cal_since = None
        self.cal_msg = ""
        self._cal_win = deque()             # recent (t, toe, heel)
        self.hist = deque(maxlen=400)       # (t_onset, stance), for the IMU to look up
        self._lifted = np.zeros(2)
        self.split = None                   # (toe, heel) fraction of the way from the lifted to the loaded level
        self.loaded = None                  # where contact starts, or None to keep FSR_CONTACT_FRACTION (the live rule)
        self.min_excess = None              # (toe, heel) counts contact needs at least above lifted (FSR_RING_MIN_EXCESS), or None

    def derive(self, cal):
        """Thresholds from the lifted level. Called after a calibration and on
        every reload, so FSR_CONTACT_FRACTION can be retuned without recapturing."""
        lifted = cal.fsr_lifted
        if not np.all(np.isfinite(lifted)) or np.any(lifted < 0):
            self.cal_ok = False
            self.cal_report = "no FSR calibration on file"
            return
        self._lifted = lifted
        self.on = lifted * (1.0 + cfg.FSR_CONTACT_FRACTION)
        if self.split is not None and self.loaded is not None:
            # Between lifted and loaded, never below the plain rule: in swing the heel can read well
            # over its "lifted" level (it was captured with the foot held up, 10 to 23k against 13 to
            # 30k in early swing) and a threshold that low makes a heel phase out of the swing.
            for i in range(2):
                if self.split[i] is not None and self.loaded[i] > lifted[i]:
                    self.on[i] = max(self.on[i], lifted[i] + self.split[i] * (self.loaded[i] - lifted[i]))
        if self.min_excess is not None:
            for i in range(2):
                if self.min_excess[i] is not None:
                    self.on[i] = max(self.on[i], lifted[i] + self.min_excess[i])
        self.cal_ok = True
        self.cal_report = "FSR cal: lifted {:.0f}/{:.0f}, contact at {:.0f}/{:.0f}{}".format(
            lifted[0], lifted[1], self.on[0], self.on[1],
            "" if self.loaded is None else " (loaded {:.0f}/{:.0f})".format(self.loaded[0], self.loaded[1]))
        print("[cal] " + self.cal_report)
        # A threshold inside the lifted capture's noise flickers at touchdown.
        margin = self.on - lifted
        tight = [cfg.FSR_LABELS[i].split()[0] for i in range(2)
                 if cal.fsr_noise[i] > 0 and margin[i] < 3.0 * cal.fsr_noise[i]]
        if tight:
            print("[cal] {} {} within 3 sigma of its own noise ({:.0f} counts of "
                  "margin). Raise FSR_CONTACT_FRACTION or expect flicker at "
                  "touchdown.".format(" and ".join(tight),
                                      "sits" if len(tight) == 1 else "sit",
                                      float(np.min(margin))))

    def begin_cal(self):
        self.calibrating = True
        self._cal_since = None                      # set on the first sample
        self._cal_win.clear()
        self.cal_msg = cfg.FSR_CAL_PROMPT
        print("\n[fsr] calibration: {}, held still for {:.0f} s.".format(
            cfg.FSR_CAL_PROMPT, cfg.FSR_CAL_HOLD_S))

    def _cal_update(self, t, raw, cal):
        """Waits FSR_CAL_SETTLE_S for the foot to come clear, then captures the
        first steady second."""
        if self._cal_since is None:
            self._cal_since = t
        elapsed = t - self._cal_since
        if elapsed < cfg.FSR_CAL_SETTLE_S:
            self._cal_win.clear()       # the foot on the ground must not reach the average
        self._cal_win.append((t, raw[0], raw[1]))
        while self._cal_win and t - self._cal_win[0][0] > cfg.FSR_CAL_HOLD_S:
            self._cal_win.popleft()

        if elapsed < cfg.FSR_CAL_SETTLE_S or len(self._cal_win) < 4:
            self.cal_msg = "{} ({:.0f}s)".format(
                cfg.FSR_CAL_PROMPT, max(0.0, cfg.FSR_CAL_SETTLE_S - elapsed))
            return
        win = np.array([[a, b] for _, a, b in self._cal_win], dtype=float)
        half = len(win) // 2
        sd = float(np.max(win.std(axis=0)))
        drift = float(np.max(np.abs(win[half:].mean(axis=0) - win[:half].mean(axis=0))))
        steady = (t - self._cal_win[0][0] >= cfg.FSR_CAL_HOLD_S * 0.9
                  and sd <= cfg.FSR_CAL_SD and drift <= cfg.FSR_CAL_DRIFT)
        timeout = elapsed >= cfg.FSR_CAL_TIMEOUT_S
        if not (steady or timeout):
            self.cal_msg = "{} (hold still, {:.0f}/{:.0f})".format(
                cfg.FSR_CAL_PROMPT, sd, drift)
            return

        cal.fsr_lifted = win.mean(axis=0)
        cal.fsr_noise = win.std(axis=0)
        print("[fsr] lifted  toe {:6.0f}   heel {:6.0f}   noise {:.0f}/{:.0f}{}".format(
            cal.fsr_lifted[0], cal.fsr_lifted[1], cal.fsr_noise[0], cal.fsr_noise[1],
            "   (not steady, took it anyway)" if timeout and not steady else ""))
        self.calibrating = False
        self._cal_since = None
        self._cal_win.clear()
        self.cal_msg = ""
        self.derive(cal)
        cal.save()

    def _classify(self, t, raw):
        """Sets the stance state; the drawing thread reads the same attributes."""
        if not self.cal_ok:
            self.zero = np.zeros(2)
            self.stance = "unknown"
            return
        self.zero = np.asarray(raw, dtype=float) - self._lifted
        margin = self.on - self._lifted
        for i in range(2):
            # Released lower than it tripped, so a sensor on its threshold
            # does not toggle at the sample rate.
            level = margin[i] * (cfg.FSR_RELEASE if self.contact[i] else 1.0)
            self.contact[i] = bool(self.zero[i] >= level)

        toe_on, heel_on = self.contact
        if not toe_on and not heel_on:
            cand = "swing"
        elif toe_on and heel_on:
            cand = "flat"
        else:
            cand = "toe" if self.zero[0] >= self.zero[1] else "heel"

        if cand != self._cand:
            self._cand, self._cand_since = cand, t
        if cand != self.stance and t - self._cand_since >= cfg.FSR_DEBOUNCE_S:
            self.stance, self.since = cand, t
            # Stamped at onset, not confirmation: the IMU looks the stance up by
            # sample time, and the contact really began when the candidate did.
            self.hist.append((self._cand_since, cand))

    def process(self, t, f1, f2, cal):
        self.raw = np.array([f1, f2], dtype=float)
        if self.calibrating:
            self._cal_update(t, (f1, f2), cal)
        else:
            self._classify(t, (f1, f2))

    def at(self, t):
        """The stance in force at sample time t, from the onset-stamped history."""
        for t_on, stance in reversed(self.hist):
            if t_on <= t:
                return stance
        return self.hist[0][1] if self.hist else self.stance
