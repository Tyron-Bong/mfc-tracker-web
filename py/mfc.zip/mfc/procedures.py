"""The interactive calibration procedures, one class each.

  InitCal   R  2 s initialisation, shoe flat on the floor
  PoseCal   C  multi-orientation accel and mag fit
  DriftCal  T  10 s still capture for the accel drift bias
  FootCal   I  segment lengths from the 50 / 100 mm gauges

Each owns only its own working state and drives the Processor `p` (state,
attitude, calibration, foot model). Ref: "Calibration procedures".
"""

import math
from collections import deque

import numpy as np

from . import config as cfg
from .foot import Z_UP
from .mathutil import (angle_deg, fit_field, fit_sine_bar, fmt_vec,
                       q_from_euler, q_matrix)


# ===========================================================================
# R: initialisation. Phase 1 measures the gyro bias and locks the pose to
# gravity and the field; phase 2 trims what is left and measures the noise
# floor. Then the foot frame and floor height are built from gravity.
# ===========================================================================
class InitCal:
    def __init__(self):
        self._zero()

    def _zero(self):
        self.waiting = False                        # the foot moved during this R: printed once
        self.acc_sum = np.zeros(3)
        self.gyr_sum = np.zeros(3)
        self.mag_sum = np.zeros(3)
        self.lin_sum = np.zeros(3)
        self.lin_sq_sum = np.zeros(3)
        self.n = 0

    def begin(self, p):
        # Everything R derives starts from zero, so a second R gives an
        # independent answer. Persisted C and T terms are device properties.
        p.att.reset()
        self._zero()
        p.state = "cal1"
        p.state_since = None                        # set on the first sample
        p.state_msg = "calibrating, hold still"
        p.vel = np.zeros(3)
        p.pos = np.zeros(3)
        p.last_t = None
        p.out.clear()
        p.foot.reset()
        print("[cal] initialisation started, keep the tracker still for 2 s")

    def _moved(self, p):
        """A sample that is not still: start again from phase 1 with the next one, so R takes
        its 2 s only once the foot has stayed still that long (CAL_STILL_*)."""
        if not self.waiting:
            print("[cal] the tracker moved during R: waiting for it to be still, then R starts again")
        p.att.reset()
        self.acc_sum = np.zeros(3)
        self.gyr_sum = np.zeros(3)
        self.mag_sum = np.zeros(3)
        self.lin_sum = np.zeros(3)
        self.lin_sq_sum = np.zeros(3)
        self.n = 0
        self.waiting = True
        p.state = "cal1"
        p.state_since = None
        p.last_t = None
        p.state_msg = "waiting for the foot to be still"

    def phase1_sample(self, p, t, acc, gyr_raw):
        g_ref = float(p.cal.g_local) if p.cal.g_local else 9.80665
        if (float(np.linalg.norm(gyr_raw)) > cfg.CAL_STILL_DPS
                or abs(float(np.linalg.norm(acc)) - g_ref) > cfg.CAL_STILL_ACC):
            self._moved(p)
            return
        if self.waiting:
            p.state_msg = "calibrating, hold still"
        self.acc_sum += acc
        self.gyr_sum += gyr_raw
        if p.last_mag is not None:
            self.mag_sum += p.last_mag
        self.n += 1
        p.last_t = t
        if t - p.state_since >= cfg.CAL_PHASE_S:
            self._finish1(p)

    def phase2_sample(self, p, t, gyr, lin):
        if float(np.linalg.norm(gyr)) > cfg.CAL_STILL_DPS or float(np.linalg.norm(lin)) > cfg.CAL_STILL_ACC:
            self._moved(p)
            return
        self.gyr_sum += gyr
        self.lin_sum += lin
        self.lin_sq_sum += lin * lin
        self.n += 1
        if t - p.state_since >= cfg.CAL_PHASE_S:
            self._finish2(p)

    def _finish1(self, p):
        """Gyro bias, gravity magnitude, and the initial pose locked to the world."""
        att, cal = p.att, p.cal
        n = max(1, self.n)
        acc = self.acc_sum / n
        mag = self.mag_sum / n

        att.gyro_bias = self.gyr_sum / n
        # g from C when there is one: a fitted radius is not polluted by accel
        # bias the way a single-pose magnitude is.
        if cal.g_local:
            att.g_mag = float(cal.g_local)
        else:
            att.g_mag = float(np.linalg.norm(acc))
            if att.g_mag < 1.0:
                att.g_mag = 9.80665
                print("[cal] gravity magnitude implausible, using 9.80665")

        # Roll and pitch off gravity. Yaw starts at 0 (world X is where the
        # device points now); the field's present bearing becomes the reference
        # the heading loop holds yaw against.
        roll = math.atan2(acc[1], acc[2])
        pitch = math.atan2(-acc[0], math.hypot(acc[1], acc[2]))
        q = q_from_euler(roll, pitch, 0.0)
        mag_cal = (mag - cal.mag_bias) / cal.mag_scale
        if np.linalg.norm(mag_cal) > 1e-6:
            m_world = q_matrix(q) @ mag_cal
            att.mag_ref_angle = math.atan2(m_world[1], m_world[0])
            # The C fit is the better |m| reference: an average over orientations.
            att.mag_norm_ref = (cal.mag_norm_fit if cal.mag_norm_fit
                                else float(np.linalg.norm(mag_cal)))
        else:
            att.mag_ref_angle = None
            print("[cal] no magnetometer samples, heading will run on the gyro alone")
        att.q = q

        self.acc_sum = np.zeros(3)
        self.gyr_sum = np.zeros(3)
        self.lin_sum = np.zeros(3)
        self.lin_sq_sum = np.zeros(3)
        self.n = 0
        p.state = "cal2"
        p.state_since = None
        p.state_msg = "verifying, hold still"
        print(f"[cal] phase 1: gyro bias {fmt_vec(att.gyro_bias)} deg/s, "
              f"g = {att.g_mag:.4f} m/s^2")

    def _finish2(self, p):
        """Second second: whatever is still not zero gets trimmed out."""
        att, foot = p.att, p.foot
        n = max(1, self.n)
        gyr_res = self.gyr_sum / n                  # residual after phase 1
        lin_res = self.lin_sum / n                  # world frame, should be 0
        if float(np.linalg.norm(gyr_res)) > cfg.CAL_TRIM_MAX_DPS:
            # a slow turn under the per-sample limits still shows here: the two phases disagree
            self._moved(p)
            return

        att.gyro_bias = att.gyro_bias + gyr_res
        # Back to the body frame, where the cause rides. Expect about zero: the
        # attitude filter already tilted the pose to read gravity, so a real
        # accel bias only shows under C.
        att.accel_bias_trim = att.accel_bias_trim + q_matrix(att.q).T @ lin_res
        variance = np.maximum(self.lin_sq_sum / n - lin_res * lin_res, 0.0)
        att.accel_noise = np.sqrt(variance)

        p.vel = np.zeros(3)
        p.pos = np.zeros(3)
        trim = q_matrix(att.q).T @ lin_res
        print(f"[cal] phase 2: gyro trim {fmt_vec(gyr_res)} deg/s, "
              f"accel trim {fmt_vec(trim)} m/s^2")
        print("[cal] accel noise {} m/s^2 rms (world), integrated as measured".format(
            fmt_vec(att.accel_noise)))
        if float(np.linalg.norm(trim)) > 0.10:
            print("[cal] that trim is large for a device at rest: the tracker most "
                  "likely moved during the 2 s. Press R and hold it still.")
        p.reload_calibration()                      # C or T may have run
        # Shoe flat for R: gravity says which way the sole faces, the heel
        # point says where the floor is.
        rot = q_matrix(att.q)
        foot.build(rot.T @ Z_UP)
        foot.ground_z = float((rot @ foot.r["heel"])[2])
        if float(foot.C[:, 2] @ foot.up_b) < 0.0:
            print("[foot] FOOT_MODEL_FLIP_DEG {} turns the sole to face up against "
                  "gravity at this R, so the foot sits {:.0f} mm above the sensor "
                  "and the floor is taken to be there. Right if the device was the "
                  "other way up for R than it sits in the shoe.".format(
                      tuple(cfg.FOOT_MODEL_FLIP_DEG), 1000.0 * foot.ground_z))
        foot.reset()
        att.quiet_since = None                      # restart the bias-hold clock
        p.state = "run"
        p.state_msg = "running"
        print("[cal] initialisation complete")


# ===========================================================================
# C: accelerometer bias/scale/g and magnetometer hard/soft iron, from the same
# poses. A single static pose cannot separate bias from gravity.
# ===========================================================================
class PoseCal:
    def __init__(self):
        self.poses = []                  # mean accel vector per orientation (raw units)
        self.mags = []                   # mean field in the same orientations
        self.sub = "settle"              # settle -> hold -> move
        self.msg = ""
        self._reset_hold()

    def _reset_hold(self):
        self.hold_since = None
        self.acc_sum = np.zeros(3)
        self.mag_sum = np.zeros(3)
        self.mag_n = 0
        self.n = 0

    def begin(self, p):
        p.state = "poses"
        p.state_msg = "sensor calibration"
        self.poses = []
        self.mags = []
        self.sub = "settle"
        self._reset_hold()
        self.msg = "hold still in pose 1"
        print(f"[cal] accelerometer and magnetometer calibration: "
              f"{cfg.POSE_TARGET} orientations.")
        print("      Rest it on each face, then on several corners, holding each")
        print(f"      still for {cfg.POSE_HOLD_S:.0f} s. Turn it at least "
              f"{cfg.POSE_MIN_SEPARATION_DEG:.0f}° between poses, and face it a")
        print("      different way each time: gravity does not care which way it")
        print("      points, but the field calibration does. C again to finish early.")

    def update(self, p, t, acc, gyr):
        """Capture state machine: settle, hold, then wait for a real move. acc is
        RAW: the ellipsoid is fitted in sensor units, so correcting it first
        would fold the old calibration in twice."""
        gyro_mag = float(np.linalg.norm(gyr))
        still = gyro_mag < cfg.POSE_STILL_DPS

        if self.sub == "move":
            if gyro_mag > cfg.POSE_MOVE_DPS:
                self.sub = "settle"
                self.msg = f"hold still in pose {len(self.poses) + 1}"
            return

        if not still:
            self.sub = "settle"
            self._reset_hold()
            return

        if self.hold_since is None:
            self.hold_since = t
            self.acc_sum = np.zeros(3)
            self.mag_sum = np.zeros(3)
            self.mag_n = 0
            self.n = 0
        # Reject the hold if the vector wanders: a slow topple reads as still on
        # the gyro but smears the mean over two orientations.
        if self.n > 0:
            mean = self.acc_sum / self.n
            if float(np.linalg.norm(acc - mean)) > cfg.POSE_STILL_MPS2:
                self._reset_hold()
                return
        self.acc_sum = self.acc_sum + acc
        self.n += 1
        if p.last_mag is not None:                  # raw field, same as the accel
            self.mag_sum = self.mag_sum + p.last_mag
            self.mag_n += 1
        self.sub = "hold"
        self.msg = "holding {:.1f}/{:.1f}s, pose {}".format(
            t - self.hold_since, cfg.POSE_HOLD_S, len(self.poses) + 1)

        if t - self.hold_since < cfg.POSE_HOLD_S:
            return

        mean = self.acc_sum / self.n
        direction = mean / max(float(np.linalg.norm(mean)), 1e-9)
        for prior in self.poses:
            prior_dir = prior / max(float(np.linalg.norm(prior)), 1e-9)
            angle = math.degrees(math.acos(
                max(-1.0, min(1.0, float(direction @ prior_dir)))))
            if angle < cfg.POSE_MIN_SEPARATION_DEG:
                self.sub = "move"
                self.msg = "too close to pose already taken, turn further"
                print(f"[cal] {angle:.0f}° from an existing pose, skipped")
                return

        self.poses.append(mean)
        self.mags.append(self.mag_sum / self.mag_n if self.mag_n else None)
        self.sub = "move"
        self.msg = f"pose {len(self.poses)}/{cfg.POSE_TARGET} captured, turn it"
        print(f"[cal] pose {len(self.poses)}/{cfg.POSE_TARGET} captured  {fmt_vec(mean)}")
        if len(self.poses) >= cfg.POSE_TARGET:
            self.finish(p)

    def _fit_mag(self, p, samples):
        """Hard and soft iron. The board carries the field sensor next to a LiPo
        and an nRF52840, so an offset here skews heading by an amount that
        changes with orientation, which is what the heading loop would chase."""
        cal = p.cal
        if len(samples) < 4:
            print("[cal] too few magnetometer samples, field left uncalibrated")
            return
        fit = fit_field(np.asarray(samples, dtype=float), cfg.MAG_RADIUS_RANGE)
        if fit is None:
            print("[cal] magnetometer fit failed, field left uncalibrated. A poor "
                  "spread or a disturbed field will both do this.")
            return
        cal.mag_bias = fit["bias"]
        cal.mag_scale = fit["scale"]
        cal.mag_norm_fit = fit["g"]
        print(f"[cal] mag {fit['method']} fit, residual {fit['residual']:.2f} uT, "
              f"field {cal.mag_norm_fit:.1f} uT, coverage {fit['coverage']:.3f}")
        if fit["coverage"] < cfg.POSE_MIN_COVERAGE:
            print("[cal] the field directions were poorly spread even though the "
                  "gravity ones were. Turn the tracker to face a different way "
                  "between poses, not just onto a different face.")
        print(f"[cal] hard iron {fmt_vec(cal.mag_bias)} uT  "
              f"soft iron {fmt_vec(cal.mag_scale)}")
        if float(np.linalg.norm(cal.mag_bias)) > 0.6 * cal.mag_norm_fit:
            print("[cal] that hard iron offset is comparable to the field itself. "
                  "Redo the calibration away from steel, laptops and speakers.")

    def finish(self, p, abort=False):
        cal, att = p.cal, p.att
        if abort or len(self.poses) < 4:
            print(f"[cal] calibration abandoned at {len(self.poses)} pose(s)")
            p.state = "run" if att.g_mag else "wait"
            p.state_msg = "running"
            return

        fit = fit_field(np.asarray(self.poses, dtype=float), cfg.ACCEL_RADIUS_RANGE)
        if fit is None:
            print("[cal] no usable fit from these poses, nothing written")
            p.state = "run"
            p.state_msg = "running"
            return

        self._fit_mag(p, [m for m in self.mags if m is not None])

        cal.accel_bias = fit["bias"]
        cal.accel_scale = fit["scale"]
        cal.g_local = fit["g"]
        att.g_mag = fit["g"]
        cal.report = "accel cal: {} poses, {}, resid {:.1f} mm/s²".format(
            fit["poses"], fit["method"], 1000.0 * fit["residual"])
        print(f"[cal] {fit['method']} fit over {fit['poses']} poses, "
              f"coverage {fit['coverage']:.3f}, residual "
              f"{1000.0 * fit['residual']:.1f} mm/s²")
        print(f"[cal] bias  {fmt_vec(cal.accel_bias)} m/s^2 "
              f"({fmt_vec(cal.accel_bias / 9.80665 * 1000.0)} mg)")
        print(f"[cal] scale {fmt_vec(cal.accel_scale)}   g {cal.g_local:.4f} m/s^2")
        if fit["coverage"] < cfg.POSE_MIN_COVERAGE:
            print(f"[cal] warning: coverage {fit['coverage']:.3f} is low, so one axis "
                  "was barely turned. Redo with more corner orientations.")
        if fit["method"] == "sphere":
            print("[cal] scale factors were not identifiable, bias only. More poses, "
                  "spread wider, would give both.")
        cal.save(fit)
        p.state = "run"
        p.state_msg = "running"
        p.request_recal = True                      # the pose is now stale


# ===========================================================================
# T: stationary drift capture. A constant accel error shows as
# p(t) = a t^2 / 2 + v0 t, and a least squares fit recovers a directly,
# averaging noise out where a literal double derivative would amplify it.
# ===========================================================================
class DriftCal:
    def __init__(self):
        self.rows = []
        self.q0 = None
        self.gyro_peak = 0.0
        self.report = "no drift capture this session"

    def begin(self, p):
        if p.state not in ("run", "drift"):
            print("[drift] finish the initialisation first")
            return
        p.state = "drift"
        p.state_since = None
        p.state_msg = "drift capture, do not move"
        self.rows = []
        self.q0 = p.att.q.copy()
        self.gyro_peak = 0.0
        p.vel = np.zeros(3)
        p.pos = np.zeros(3)
        print(f"[drift] capturing for {cfg.DRIFT_CAPTURE_S:.0f} s, keep the tracker still")

    def sample(self, p, t, gyr):
        self.gyro_peak = max(self.gyro_peak, float(np.max(np.abs(gyr))))
        self.rows.append((t - p.state_since, p.pos[0], p.pos[1], p.pos[2]))
        if t - p.state_since >= cfg.DRIFT_CAPTURE_S:
            self.finish(p)

    def finish(self, p):
        cal = p.cal
        rows = np.asarray(self.rows, dtype=float)
        if rows.shape[0] < 50:
            print("[drift] not enough samples, capture abandoned")
            p.state = "run"
            p.state_msg = "running"
            return

        t = rows[:, 0]
        design = np.column_stack((0.5 * t * t, t))
        accel_world = np.empty(3)
        vel_world = np.empty(3)
        for axis in range(3):
            fit = np.linalg.lstsq(design, rows[:, 1 + axis], rcond=None)[0]
            accel_world[axis], vel_world[axis] = fit[0], fit[1]

        correction = q_matrix(self.q0).T @ accel_world
        cal.accel_drift_bias = cal.accel_drift_bias + correction

        final_pos = rows[-1, 1:4]
        cal.drift_count += 1
        cal.save()
        self.report = ("last capture: drift {:.3f} m over {:.0f} s, "
                       "correction {} m/s^2".format(
                           float(np.linalg.norm(final_pos)), t[-1], fmt_vec(correction)))
        print(f"[drift] {self.report}")
        print(f"[drift] total drift bias now {fmt_vec(cal.accel_drift_bias)} m/s^2")
        # A mostly-velocity residual is a standing offset in the integrator, not
        # an accel bias; that is what R is for.
        if float(np.linalg.norm(vel_world)) > 0.5 * float(np.linalg.norm(accel_world)) * t[-1]:
            print(f"[drift] note: the fit is mostly a velocity offset "
                  f"({fmt_vec(vel_world)} m/s), not an acceleration. Press R first, "
                  "then T, so the capture starts from a settled integrator.")
        if self.gyro_peak > 8.0:
            print(f"[drift] warning: gyro peaked at {self.gyro_peak:.1f} deg/s "
                  "during the capture, so the tracker was not stationary and this "
                  "correction is contaminated. Press T again.")

        p.vel = np.zeros(3)
        p.pos = np.zeros(3)
        p.state = "run"
        p.state_msg = "running"


# ===========================================================================
# I: foot segment lengths, the gauge-block method. The foot is a sine bar run
# backwards: sin(theta) = h / L2 (heel on a block), h / (L1 + L2) (toe tip on a
# block). theta is the angle between the flat and on-block gravity vectors.
# ===========================================================================
class FootCal:
    def __init__(self):
        self.steps = []                  # (kind, gauge mm or None, prompt)
        self.step = 0
        self.since = None
        self.win = deque()               # (t, ax, ay, az, |gyro|) during a hold
        self.caps = []                   # one dict per capture
        self.msg = ""
        self.angle = None                # live tilt from the flat capture, deg
        self.placed = False              # past the settle time

    def begin(self, p):
        if p.state not in ("run",):
            print("[foot] finish the initialisation first (R), then press I")
            return
        self.steps = [("flat", None, "stand the shoe flat on the floor")]
        for h in cfg.FOOTCAL_GAUGES_MM:
            self.steps.append(("heel", h, "heel on the {:.0f} mm gauge, forefoot flat "
                                          "on the floor".format(h)))
        for h in cfg.FOOTCAL_GAUGES_MM:
            self.steps.append(("toe", h, "toe tip on the {:.0f} mm gauge, heel on the "
                                         "floor".format(h)))
        self.steps.append(("flat", None, "shoe flat on the floor again"))
        self.step = 0
        self.since = None
        self.win.clear()
        self.caps = []
        self.angle = None
        self.msg = self.steps[0][2]
        p.state = "footcal"
        p.state_since = None
        p.state_msg = "foot length calibration"
        print("\n[foot] segment length calibration, {} steps. Place the shoe, let go, "
              "and hold still: each step captures by itself after {:.0f} s. I again "
              "cancels.".format(len(self.steps), cfg.FOOTCAL_SETTLE_S))
        print("[foot] 1/{} {}".format(len(self.steps), self.msg))

    def update(self, p, t, acc, gyr):
        """Wait for the shoe to be placed, then capture the first still second as
        a unit gravity vector. acc is the CALIBRATED accel: angles between
        gravity readings are only right once bias and scale are out."""
        kind, gauge, prompt = self.steps[self.step]
        n = float(np.linalg.norm(acc))
        if n < 1e-6:
            return
        flat = self.caps[0]["g"] if self.caps else None
        self.angle = angle_deg(flat, acc / n) if flat is not None else None

        if self.since is None:
            self.since = t
        elapsed = t - self.since
        self.placed = elapsed >= cfg.FOOTCAL_SETTLE_S
        if not self.placed:
            self.win.clear()
            self.msg = "{} ({:.0f}s)".format(prompt, max(0.0, cfg.FOOTCAL_SETTLE_S - elapsed))
            return
        self.win.append((t, acc[0], acc[1], acc[2], float(np.linalg.norm(gyr))))
        while self.win and t - self.win[0][0] > cfg.FOOTCAL_HOLD_S:
            self.win.popleft()
        if t - self.win[0][0] < cfg.FOOTCAL_HOLD_S * 0.9:
            self.msg = prompt + " (hold still)"
            return
        w = np.asarray(self.win, dtype=float)
        if (float(w[:, 4].max()) > cfg.FOOTCAL_STILL_DPS
                or float(np.max(w[:, 1:4].std(axis=0))) > cfg.FOOTCAL_ACC_SD):
            self.msg = prompt + " (hold still)"
            return
        mean = w[:, 1:4].mean(axis=0)
        g = mean / float(np.linalg.norm(mean))

        # Each step must look different from the last, or the shoe has not yet
        # been moved onto the next gauge.
        if self.caps and angle_deg(self.caps[-1]["g"], g) < cfg.FOOTCAL_MIN_MOVE_DEG:
            self.msg = prompt + " (waiting for the shoe to move)"
            return

        cap = {"kind": kind, "gauge_mm": gauge, "g": g}
        line = "[foot] {}/{} {:<4} {:>5}".format(
            self.step + 1, len(self.steps), kind,
            "" if gauge is None else "{:.0f}mm".format(gauge))
        if flat is not None:
            theta = angle_deg(flat, g)
            axis = np.cross(flat, g)
            cap["theta_deg"] = theta
            cap["cross"] = axis
            cap["axis"] = axis / max(float(np.linalg.norm(axis)), 1e-12)
            line += "  {:6.2f} deg from flat".format(theta)
            if gauge is not None and theta > 0.5:
                length = gauge / 1000.0 / math.sin(math.radians(theta))
                line += "  -> {} {:.1f} mm".format(
                    "ball to heel" if kind == "heel" else "heel to toe", length * 1000.0)
        self.caps.append(cap)
        print(line)

        self.step += 1
        self.since = None
        self.win.clear()
        if self.step >= len(self.steps):
            self.finish(p)
        else:
            self.msg = self.steps[self.step][2]
            print("[foot] {}/{} {}".format(self.step + 1, len(self.steps), self.msg))

    def finish(self, p, abort=False):
        cal, foot = p.cal, p.foot
        p.state = "run"
        p.state_msg = "running"
        if abort:
            print("[foot] length calibration cancelled, lengths unchanged. Stand the "
                  "shoe flat and press R before walking: the pose was not tracked "
                  "while calibrating.")
            return

        heel = [c for c in self.caps if c["kind"] == "heel"]
        toe = [c for c in self.caps if c["kind"] == "toe"]
        flat0, flat1 = self.caps[0]["g"], self.caps[-1]["g"]
        repeat = angle_deg(flat0, flat1)

        # Heel raised and toe raised tilt the shoe opposite ways about its
        # left-right axis. If they do not, a gauge went under the wrong end or
        # the shoe rolled sideways, and the angles mean nothing.
        mh = np.sum([c["axis"] for c in heel], axis=0)
        mt = np.sum([c["axis"] for c in toe], axis=0)
        mh = mh / max(float(np.linalg.norm(mh)), 1e-12)
        mt = mt / max(float(np.linalg.norm(mt)), 1e-12)
        opposed = float(mh @ mt)

        # Roll removed: the tilt that matters is sin(theta) = forward . gravity;
        # a sideways roll turns the shoe about that axis without raising it
        # (5 deg of roll on the 50 mm heel capture reads 6% short). Raw cross
        # products are summed, not unit axes, so a same-side roll cancels in
        # the toe-minus-heel difference (unit axes left 6.5 mm for a 5 deg lean).
        left = (np.sum([c_["cross"] for c_ in toe], axis=0)
                - np.sum([c_["cross"] for c_ in heel], axis=0))
        max_roll = 0.0
        if float(np.linalg.norm(left)) > 1e-6:
            left = left / float(np.linalg.norm(left))
            fwd = np.cross(left, flat0)
            fwd = fwd / max(float(np.linalg.norm(fwd)), 1e-12)
            for c_ in heel + toe:
                pitch = math.degrees(math.asin(min(1.0, abs(float(fwd @ c_["g"])))))
                c_["pitch_deg"] = pitch
                ratio = math.cos(math.radians(c_["theta_deg"])) / max(
                    math.cos(math.radians(pitch)), 1e-9)
                c_["roll_deg"] = math.degrees(math.acos(max(-1.0, min(1.0, ratio))))
                max_roll = max(max_roll, c_["roll_deg"])
        L2, L2_each, sp2 = fit_sine_bar(heel)
        Lt, Lt_each, spt = fit_sine_bar(toe)
        L1 = Lt - L2

        print("[foot] ball to heel  {:.1f} mm  (gauges: {})".format(
            L2 * 1000.0, ", ".join("{:.1f}".format(v * 1000.0) for v in L2_each)))
        print("[foot] heel to toe   {:.1f} mm  (gauges: {})".format(
            Lt * 1000.0, ", ".join("{:.1f}".format(v * 1000.0) for v in Lt_each)))
        print("[foot] toe to ball   {:.1f} mm  (the difference)".format(L1 * 1000.0))

        if max_roll > 1.0:
            print("[foot] sideways roll on the gauges up to {:.1f} deg, removed ({})"
                  .format(max_roll, ", ".join("{} {:.0f}mm {:.1f}".format(
                      c_["kind"], c_["gauge_mm"], c_["roll_deg"]) for c_ in heel + toe)))
        problems = []
        if opposed > -0.8:
            problems.append("the heel and toe captures did not tilt the shoe opposite "
                            "ways about one axis ({:+.2f}, expected near -1): check the "
                            "heel went on the gauge for the heel steps and the toe tip "
                            "for the toe steps, with the shoe square to the gauge"
                            .format(opposed))
        if not cfg.FOOTCAL_L2_RANGE_M[0] <= L2 <= cfg.FOOTCAL_L2_RANGE_M[1]:
            problems.append("ball to heel {:.0f} mm is outside {:.0f} to {:.0f} mm".format(
                L2 * 1000.0, *(v * 1000.0 for v in cfg.FOOTCAL_L2_RANGE_M)))
        if not cfg.FOOTCAL_TOTAL_RANGE_M[0] <= Lt <= cfg.FOOTCAL_TOTAL_RANGE_M[1]:
            problems.append("heel to toe {:.0f} mm is outside {:.0f} to {:.0f} mm".format(
                Lt * 1000.0, *(v * 1000.0 for v in cfg.FOOTCAL_TOTAL_RANGE_M)))
        if not cfg.FOOTCAL_L1_RANGE_M[0] <= L1 <= cfg.FOOTCAL_L1_RANGE_M[1]:
            problems.append("toe to ball {:.0f} mm is outside {:.0f} to {:.0f} mm".format(
                L1 * 1000.0, *(v * 1000.0 for v in cfg.FOOTCAL_L1_RANGE_M)))
            if Lt < L2:
                problems.append("heel to toe came out shorter than ball to heel, which "
                                "is what the gauges under the wrong ends look like: "
                                "heel steps go under the heel, toe steps under the "
                                "toe tip")
        if problems:
            for msg in problems:
                print("[foot] refused: " + msg)
            print("[foot] lengths unchanged ({:.0f} / {:.0f} mm). Press I to redo.".format(
                cal.foot_L2 * 1000.0, cal.foot_L1 * 1000.0))
            p.request_recal = True
            return

        if sp2 > cfg.FOOTCAL_AGREE or spt > cfg.FOOTCAL_AGREE:
            print("[foot] warning: the gauges disagree by {:.1f}% (heel) and {:.1f}% "
                  "(toe). Usually the shoe was not fully down on the floor end, or the "
                  "gauge was under the arch rather than the heel or toe tip. Kept, but "
                  "worth redoing.".format(sp2 * 100.0, spt * 100.0))
        if repeat > cfg.FOOTCAL_REPEAT_DEG:
            print("[foot] warning: flat at the end differs from flat at the start by "
                  "{:.1f} deg, so the floor spot or the shoe's seating changed. The "
                  "angles are all measured from the first flat.".format(repeat))

        cal.foot_L1, cal.foot_L2 = L1, L2
        cal.foot_len_source = "gauge calibration"
        cal.foot_len_meta = {
            "gauges_mm": [float(v) for v in cfg.FOOTCAL_GAUGES_MM],
            "heel_deg": [float(c.get("pitch_deg", c["theta_deg"])) for c in heel],
            "toe_deg": [float(c.get("pitch_deg", c["theta_deg"])) for c in toe],
            "max_roll_deg": float(max_roll),
            "ball_to_heel_each_mm": [float(v * 1000.0) for v in L2_each],
            "heel_to_toe_each_mm": [float(v * 1000.0) for v in Lt_each],
            "heel_to_toe_mm": float(Lt * 1000.0),
            "flat_repeat_deg": float(repeat),
            "axes_opposed": float(opposed),
        }
        foot.build()
        cal.save()
        print("[foot] using ball to heel {:.1f} mm, toe to ball {:.1f} mm".format(
            cal.foot_L2 * 1000.0, cal.foot_L1 * 1000.0))

        # The same captures say which sensor axis runs heel to toe. Toe raised is
        # positive rotation about the left axis, heel raised negative, so the
        # difference of the two mean axes is +left; up is gravity with the shoe flat.
        fwd_seen, agree, suggest = foot.forward_from_lateral(
            (mt - mh) / max(float(np.linalg.norm(mt - mh)), 1e-12), flat0)
        if agree > 0.9:
            print("[foot] the gauges agree with the model's forward axis ({:.2f})".format(agree))
        else:
            print("[foot] the gauges say the foot points along ({:+.2f}, {:+.2f}, "
                  "{:+.2f}) in sensor axes, against the model's ({:+.2f}, {:+.2f}, "
                  "{:+.2f}). With FOOT_MODEL_FLIP_DEG {} that is FOOT_FORWARD_BODY = "
                  "{}.".format(*fwd_seen, *foot.C[:, 0], tuple(cfg.FOOT_MODEL_FLIP_DEG),
                               suggest))
        # The pose was not tracked during the calibration, and the last step left
        # the shoe flat, which is exactly what R needs.
        p.request_recal = True
