"""The conversation with a tracker that records on its own (firmware/mfc_offline.py).

Commands go out as text lines on the UART service; replies and events come back on its
TX characteristic; a run's bytes come as notifications on the file characteristic,
each "<IH" (offset, length) then that many bytes. TrackerLink holds the protocol and
knows nothing about Bluetooth: it is given an `io` with `async send(line)` and is fed
what arrives (feed_text, feed_file), so the same code runs over bleak (receiver_offline.py)
and against the firmware module itself in tools/check_tracker_offline.py.

  HELLO pc-offline    INFO    LIST    GET name off len    CRC name    DEL name
  DELALL    REN old new    REC START [name|-] [steps]    REC STOP    MARK name [back_ms]    EDIT

Replies: OK:... or ERR:reason (the last line of an answer), RUN:name,size,steps,secs
(one per run), INFO:key=value ..., EVT:... (unsolicited). Ref: "Offline mode" in
docs/firmware_reference.md.
"""

import asyncio
import struct
import zlib
from dataclasses import dataclass

FILE_CHUNK_HEAD = struct.Struct("<IH")
MAX_GET = 16384                  # bytes asked for in one GET
RETRIES = 6


class TrackerError(Exception):
    """The tracker refused a command, or did not answer."""


@dataclass
class RunInfo:
    name: str
    size: int
    steps: int
    secs: int                    # 0 when the file has no end record (cut short)


class TrackerLink:
    def __init__(self, io, timeout=5.0):
        self.io = io
        self.timeout = timeout
        self._buf = bytearray()
        self._lines = asyncio.Queue()
        self.events = []                     # EVT: lines seen, newest last
        self.status = []                     # other unsolicited lines (the boot status block)
        self._chunks = {}                    # offset -> bytes of the download in progress
        self.bytes_in = 0

    # -- what arrives ------------------------------------------------------------------
    def feed_text(self, data):
        self._buf += data
        while b"\n" in self._buf:
            raw, _, rest = bytes(self._buf).partition(b"\n")
            self._buf = bytearray(rest)
            line = raw.decode("utf-8", "replace").strip()
            if not line:
                continue
            if line.startswith("EVT:"):
                self.events.append(line[4:])
            elif line.startswith(("OK:", "ERR:", "RUN:", "INFO:")):
                self._lines.put_nowait(line)
            else:
                self.status.append(line)

    def feed_file(self, data):
        if len(data) < FILE_CHUNK_HEAD.size:
            return
        off, n = FILE_CHUNK_HEAD.unpack_from(data, 0)
        body = bytes(data[FILE_CHUNK_HEAD.size:FILE_CHUNK_HEAD.size + n])
        if len(body) == n:
            self._chunks[off] = body
            self.bytes_in += n

    # -- one command ---------------------------------------------------------------------
    async def request(self, line, done, timeout=None):
        """Send `line`, return the RUN:/INFO: lines up to the reply that starts with
        `done` (also returned, last). ERR: replies raise TrackerError."""
        while not self._lines.empty():
            self._lines.get_nowait()                    # stale
        await self.io.send(line)
        got = []
        while True:
            try:
                reply = await asyncio.wait_for(self._lines.get(), timeout or self.timeout)
            except asyncio.TimeoutError:
                raise TrackerError("no answer to '{}'".format(line))
            if reply.startswith("ERR:"):
                raise TrackerError(reply[4:])
            got.append(reply)
            if reply.startswith(done):
                return got

    # -- commands ------------------------------------------------------------------------
    async def hello(self, role="pc-offline"):
        await self.request("HELLO " + role, "OK:HELLO")

    async def info(self):
        (line,) = (await self.request("INFO", "INFO:"))[-1:]
        out = {}
        for part in line[5:].split():
            k, _, v = part.partition("=")
            out[k] = v
        return out

    async def list(self):
        runs = []
        for line in await self.request("LIST", "OK:LIST"):
            if line.startswith("RUN:"):
                name, size, steps, secs = line[4:].split(",")
                runs.append(RunInfo(name, int(size), int(steps), int(secs)))
        return runs

    async def delete(self, name):
        await self.request("DEL " + name, "OK:DEL")

    async def delete_all(self):
        await self.request("DELALL", "OK:DELALL")

    async def rename(self, old, new):
        await self.request("REN {} {}".format(old, new), "OK:REN")

    async def edit_mode(self):
        await self.request("EDIT", "OK:EDIT")

    def _gaps(self, size):
        """(offset, length) ranges of [0, size) that no chunk has covered."""
        gaps, pos = [], 0
        for off in sorted(self._chunks):
            if off > pos:
                gaps.append((pos, off - pos))
            pos = max(pos, off + len(self._chunks[off]))
        if pos < size:
            gaps.append((pos, size - pos))
        return gaps

    async def crc(self, name):
        """(crc32, size) of a run's file on the tracker."""
        reply = (await self.request("CRC " + name, "OK:CRC"))[-1].split()
        return int(reply[2], 16), int(reply[3])

    async def download(self, run, progress=None):
        """The bytes of a run, size and CRC32 checked against the tracker's own."""
        self._chunks = {}
        for _ in range(RETRIES):
            gaps = self._gaps(run.size)
            if not gaps:
                break
            for off, n in gaps:
                while n > 0:
                    take = min(n, MAX_GET)
                    await self.request("GET {} {} {}".format(run.name, off, take), "OK:GET",
                                       timeout=self.timeout + take / 2000.0)
                    await asyncio.sleep(0.05)               # stragglers on the other characteristic
                    off, n = off + take, n - take
                    if progress:
                        progress(self.bytes_in, run.size)
        else:
            if self._gaps(run.size):
                raise TrackerError("{}: chunks still missing after {} tries".format(
                    run.name, RETRIES))
        data = bytearray(run.size)
        for off, body in self._chunks.items():
            data[off:off + len(body)] = body[:max(0, run.size - off)]
        reply = (await self.request("CRC " + run.name, "OK:CRC"))[-1].split()
        want_crc, want_size = int(reply[2], 16), int(reply[3])
        if want_size != run.size or zlib.crc32(bytes(data)) != want_crc:
            raise TrackerError("{}: the download does not match the tracker's copy "
                               "(size {} of {}, crc {:08x} against {:08x})".format(
                                   run.name, len(data), want_size, zlib.crc32(bytes(data)), want_crc))
        return bytes(data)
