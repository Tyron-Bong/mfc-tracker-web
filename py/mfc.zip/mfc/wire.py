"""Wire format shared with firmware/code.py, and the decoders for it.

The formats, flags, UUIDs and LSB scales below must match the firmware exactly.
tools/check_wire_format.py compares them with code.py. Change both or neither.

Frame: header "<IBBHB" = base_timestamp_us, seq (per sensor type), count,
interval_us (informational), flags. Then `count` samples, each starting with a
uint16 dt_us offset from base_timestamp_us.
"""

import struct
import time

import numpy as np

UART_TX_CHAR_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"   # status text
MOTION_SERVICE_UUID = "b2e91400-2eae-4f5b-9f3c-1a2b3c4d5e6f"
MOTION_CHAR_UUID = "b2e91401-2eae-4f5b-9f3c-1a2b3c4d5e6f"    # binary stream
LIVE_CHAR_UUID = "b2e91402-2eae-4f5b-9f3c-1a2b3c4d5e6f"      # offline mode: 25 Hz FSR / gyro / flags (<IHHHB)
FILE_CHAR_UUID = "b2e91403-2eae-4f5b-9f3c-1a2b3c4d5e6f"      # offline mode: recorded-run chunks (<IH offset, length + data)
UART_RX_CHAR_UUID = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"   # offline mode: commands to the unit

WIRE_FORMAT_VERSION = 1   # bump with any change to the frame layout below (sessions record it)
HEADER_FMT = "<IBBHB"
HEADER_SIZE = struct.calcsize(HEADER_FMT)

FLAG_IMU = 0x01
FLAG_MAG = 0x02
FLAG_FSR = 0x04
FLAG_BATT = 0x08

IMU_SAMPLE_FMT = "<H6h"    # dt_us, ax, ay, az, gx, gy, gz   raw LSB
MAG_SAMPLE_FMT = "<H3h"    # dt_us, mx, my, mz               raw LSB
FSR_SAMPLE_FMT = "<H2H"    # dt_us, toe, heel                raw ADC counts
BATT_SAMPLE_FMT = "<HBHB"  # dt_us, percent, millivolts, source flags
SAMPLE_SIZE = {
    FLAG_IMU: struct.calcsize(IMU_SAMPLE_FMT),
    FLAG_MAG: struct.calcsize(MAG_SAMPLE_FMT),
    FLAG_FSR: struct.calcsize(FSR_SAMPLE_FMT),
    FLAG_BATT: struct.calcsize(BATT_SAMPLE_FMT),
}

BATT_SRC_USB = 0x01
BATT_SRC_NO_CELL = 0x02

# Raw LSB to physical units, from the firmware's full-scale ranges.
ACCEL_LSB_TO_MPS2 = 0.488e-3 * 9.80665   # +/-16 g
GYRO_LSB_TO_DPS = 0.035                  # +/-1000 dps
MAG_LSB_TO_UT = 100.0 / 4000.0           # 8 G range, 4000 LSB/G, 1 G = 100 uT

TS_WRAP_US = 1 << 32      # device timestamp is uint32 microseconds, 71.6 min


class FrameDecoder:
    """Reassembles frames from BLE notifications and hands decoded rows to a
    sink with on_imu(rows), on_mag(rows), on_fsr(rows). Rows are
    (t_s, acc, gyr) with numpy vectors in m/s^2 and deg/s, (t_s, field_uT),
    and (t_s, toe, heel). Also keeps the link statistics and the battery."""

    def __init__(self, sink):
        self.sink = sink
        self.buffer = bytearray()
        self.epoch_us = 0
        self.last_base_us = None
        self.t0_us = None
        self.last_seq = {}                   # per sensor type
        self.dropped = 0
        self.counts = {FLAG_IMU: 0, FLAG_MAG: 0, FLAG_FSR: 0, FLAG_BATT: 0}
        self.rates = {FLAG_IMU: 0.0, FLAG_MAG: 0.0, FLAG_FSR: 0.0, FLAG_BATT: 0.0}
        self.last_stats_t = time.monotonic()
        # percent is None until the first battery frame (drawn as "waiting")
        self.batt = {"percent": None, "volts": 0.0, "usb": False, "cell": True,
                     "t": None}
        self.bytes_in = 0
        self.frames_ok = 0
        self._warned_mismatch = False

    def _unwrap(self, base_us):
        """Absolute microseconds from the device's uint32 clock, wrap included."""
        if self.last_base_us is not None and base_us + (TS_WRAP_US >> 1) < self.last_base_us:
            self.epoch_us += TS_WRAP_US
        if self.last_base_us is None or base_us > self.last_base_us:
            self.last_base_us = base_us
        return base_us + self.epoch_us

    def feed(self, data):
        """One notification may carry one frame, part of one, or several."""
        self.bytes_in += len(data)
        self.buffer += data
        while len(self.buffer) >= HEADER_SIZE:
            _, _, count, _, flags = struct.unpack_from(HEADER_FMT, self.buffer, 0)
            # count == 0 is never sent, so such a header is stray bytes
            stride = SAMPLE_SIZE.get(flags)
            if stride is None or count == 0:
                del self.buffer[:1]
                continue
            frame_len = HEADER_SIZE + count * stride
            if len(self.buffer) < frame_len:
                break
            frame = bytes(self.buffer[:frame_len])
            del self.buffer[:frame_len]
            self._parse(frame)
            self.frames_ok += 1
            if self.frames_ok == 1:
                print(f"stream up: first frame decoded ({frame_len} B, flags 0x{flags:02X})")

        if self.frames_ok == 0 and self.bytes_in > 200 and not self._warned_mismatch:
            self._warned_mismatch = True
            head = " ".join(f"{b:02X}" for b in bytes(data[:24]))
            print("\n[!] receiving data but decoding no frames: the device and this")
            print("    receiver disagree about the frame format (one file is a")
            print("    different version than the other). Expected a 9-byte header")
            print("    (base_timestamp_us u32, seq, count, interval_us, flags) with a")
            print("    uint16 dt_us on every sample.")
            print(f"    first bytes seen: {head}")
            if len(data) > 1 and data[0] == 0xA5:
                print("    those start with 0xA5, the older sync-byte format: this")
                print("    receiver is newer than the firmware on the device.")
            print()

        now = time.monotonic()
        elapsed = now - self.last_stats_t
        if elapsed >= 1.0:
            for flag in self.rates:
                self.rates[flag] = self.counts[flag] / elapsed
                self.counts[flag] = 0
            print(f"imu {self.rates[FLAG_IMU]:.0f} Hz   mag {self.rates[FLAG_MAG]:.0f} Hz   "
                  f"fsr {self.rates[FLAG_FSR]:.0f} Hz   dropped batches {self.dropped}"
                  + ("" if self.batt["percent"] is None
                     else f"   batt {self.batt['percent']}%"))
            self.last_stats_t = now

    def _parse(self, frame):
        base_us, seq, count, _interval, flags = struct.unpack_from(HEADER_FMT, frame, 0)

        prev = self.last_seq.get(flags)
        if prev is not None:
            gap = (seq - prev) % 256
            if gap > 1:
                self.dropped += gap - 1
                print(f"[!] dropped {gap - 1} batch(es) on flag 0x{flags:02X} ({prev} -> {seq})")
            elif gap == 0:
                print(f"[!] repeated seq {seq} on flag 0x{flags:02X}")
        self.last_seq[flags] = seq

        abs_base = self._unwrap(base_us)
        if self.t0_us is None:
            self.t0_us = abs_base
        t_base = (abs_base - self.t0_us) / 1e6

        off = HEADER_SIZE
        size = SAMPLE_SIZE[flags]
        rows = []
        if flags == FLAG_IMU:
            for _ in range(count):
                dt, ax, ay, az, gx, gy, gz = struct.unpack_from(IMU_SAMPLE_FMT, frame, off)
                off += size
                rows.append((t_base + dt / 1e6,
                             np.array([ax, ay, az], dtype=float) * ACCEL_LSB_TO_MPS2,
                             np.array([gx, gy, gz], dtype=float) * GYRO_LSB_TO_DPS))
            self.sink.on_imu(rows)
        elif flags == FLAG_MAG:
            for _ in range(count):
                dt, mx, my, mz = struct.unpack_from(MAG_SAMPLE_FMT, frame, off)
                off += size
                rows.append((t_base + dt / 1e6,
                             np.array([mx, my, mz], dtype=float) * MAG_LSB_TO_UT))
            self.sink.on_mag(rows)
        elif flags == FLAG_FSR:
            for _ in range(count):
                dt, f1, f2 = struct.unpack_from(FSR_SAMPLE_FMT, frame, off)
                off += size
                rows.append((t_base + dt / 1e6, f1, f2))
            self.sink.on_fsr(rows)
        elif flags == FLAG_BATT:
            for _ in range(count):
                dt, pct, mv, src = struct.unpack_from(BATT_SAMPLE_FMT, frame, off)
                off += size
                self.batt.update(percent=int(pct), volts=mv / 1000.0,
                                 usb=bool(src & BATT_SRC_USB),
                                 cell=not (src & BATT_SRC_NO_CELL),
                                 t=t_base + dt / 1e6)
        self.counts[flags] += count


class StatusText:
    """Newline-delimited status text from the UART service, shown on the plot
    rather than printed. The firmware sends it after every connection:

      MFC Tracker streaming. IMU ok=.. MAG ok=..   sensors that came up
      IMU FIFO ... / MAG FIFO ...                  how each stream is read
      FILT:accel=..:gyro=..:mag=..                 on-die filter corners applied
      FIFO:pairs=..:mag=..:nack=..:ovr=..:drop=..:pin=x/y:odr=..   health, every 20 s

    Lines of any other kind are still printed."""

    def __init__(self):
        self.buffer = bytearray()
        self.filters = {"accel": "0.6", "gyro": "14.2", "mag": "11.1"}
        self.dirty = True                    # the plot retitles when this is set
        self.sensors = None                  # (imu_ok, mag_ok) once reported
        self.imu_fifo = None                 # status text after "IMU FIFO "
        self.mag_fifo = None
        self.fifo_health = None              # dict of the last FIFO: report
        self.fsr_ring = None                 # "on, 240.0 Hz" or "off: why": how the unit reads the FSRs
        self.fsr_latency_us = None           # the unit's stored FSR-to-IMU latency (stomp calibration), or None
        self.sync_n = 0
        self.sync_sd_us = 0
        self.writes = []                     # a tracker recording's flash writes: (ms, bytes, write ms, flush ms, why)
        self._accel_warned = False

    def feed(self, data):
        self.buffer += data
        while b"\n" in self.buffer:
            line, _, rest = bytes(self.buffer).partition(b"\n")
            self.buffer = bytearray(rest)
            text = line.decode("utf-8", "replace").strip()
            if not self._parse(text):
                print("[status]", text)

    def _parse(self, text):
        """Store a recognised line. Returns False if it is not one."""
        if text.startswith("FILT:"):
            for field in text[5:].split(":"):
                key, _, value = field.partition("=")
                if key in self.filters and value:
                    self.filters[key] = value
            self.dirty = True
            self._check_accel_filter()
        elif text.startswith("IMU FIFO "):
            self.imu_fifo = text[9:]
        elif text.startswith("MAG FIFO "):
            self.mag_fifo = text[9:]
        elif text.startswith("FIFO:"):
            self.fifo_health = dict(f.partition("=")[::2] for f in text[5:].split(":"))
        elif text.startswith("MFC Tracker streaming."):
            self.sensors = ("IMU ok=True" in text, "MAG ok=True" in text)
        elif text.startswith("FSR ring "):
            self.fsr_ring = text[9:]
        elif text.startswith("SYNC:"):
            try:
                f = dict(p.partition("=")[::2] for p in text[5:].split(":"))
                self.fsr_latency_us, self.sync_n, self.sync_sd_us = int(f["lat_us"]), int(f["n"]), int(f["sd_us"])
            except (KeyError, ValueError):
                return False
        elif text.startswith("WR:"):
            try:
                a = text[3:].split()
                self.writes.append((int(a[0]), int(a[1]), int(a[2]), int(a[3]), a[4]))
            except (IndexError, ValueError):
                return False
        else:
            return False
        return True

    @staticmethod
    def brief(text):
        """One short line for the plot. A healthy stream is reduced to its state;
        a failure keeps its full reason, which is what needs reading."""
        if text is None:
            return "no report yet"
        if text.startswith("on"):
            if "NOT seen" in text:
                return "on, INT not seen (timer)"
            rate = [p.strip() for p in text.split(",")[1:] if p.strip().endswith("Hz")]
            return "on, " + rate[0] if rate else "on"
        return text

    def _check_accel_filter(self):
        """Row 2 double integrates the accelerometer. A corner under 10 Hz
        removes the motion being integrated, so say so once."""
        if self._accel_warned:
            return
        try:
            corner = float(self.filters["accel"])
        except (TypeError, ValueError):
            return
        if corner < 10.0:
            self._accel_warned = True
            print(f"\n[!] the device reports its accelerometer LPF2 at {corner} Hz.")
            print("    Row 1 is fine, but row 2 and the position panel integrate that")
            print("    signal, and below about 10 Hz the real motion is attenuated away")
            print("    (swing strides come out short). Set ACCEL_LPF2_ENABLE = False in")
            print("    the firmware, or ACCEL_LPF2_SEL = 1 for a 24 Hz corner.\n")
