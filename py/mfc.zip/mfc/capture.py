"""Run captures: the data of one G run, saved for tuning the post-processing.

When a run is published (STEP_COUNT steps, or fewer if stopped), the Processor
writes step_runs/<time>_run<N>.npz and a .json sidecar. The .npz holds the exact
rows process_step consumes (so reprocessing is a fast, hardware-free loop), the
raw streamed samples around the run (IMU, FSR, magnetometer, in the units the
receiver decoded them to, never rewritten) and the stance history. The sidecar
holds everything else needed to read them: the calibration file, the whole
config, the mount constants, versions, the live result summary and a note.

  load_run(path)  ->  Run     reprocess(run) -> (steps, walk, failures)

Run format 2 (the default while a session is being recorded) writes only the sidecar:
the raw stream is already in the session file, and replaying it rebuilds the rows and
the raw windows bit for bit, so storing them again was 90% of the size. The sidecar
then names the session and the run in it; load_run replays the session with the
settings saved here and keeps the result in step_runs/.cache/ (disposable). Format 1
(the .npz as above) is still read, and still written when no session is recorded.

tools/replay_run.py is the command line over this. Ref: "Run captures and
sessions" in docs/mfc_processing_reference.md.
"""

import ast
import contextlib
import glob
import io
import hashlib
import json
import os
import time

import numpy as np

from . import __version__
from . import config as cfg
from . import session as sess
from .gait import _jsonable, build_walk, merge_rows, process_step, walk_to_dict
from .wire import WIRE_FORMAT_VERSION

RUN_FORMAT_VERSION = 2
READABLE_RUN_FORMATS = (1, 2)
CACHE_DIR = ".cache"                           # inside the captures folder
# What the rows of a run depend on besides the session and the saved settings. gait.py
# and config.py are left out on purpose: they change whenever the step processing is
# tuned, and the rows do not (delete step_runs/.cache after editing StepRecorder).
FINGERPRINT_FILES = ("attitude.py", "foot.py", "stance.py", "pipeline.py", "procedures.py",
                     "calfile.py", "mathutil.py", "wire.py", "pack.py", "session.py")
# Settings that change the rows of an old run but are not in its saved config (they came later), so
# their current values go into the key: retuning one rebuilds the cache.
FINGERPRINT_SETTINGS = ("FSR_LATENCY_APPLY", "FSR_OFFLINE_SPLIT", "FSR_OFFLINE_STILL_DPS", "FSR_OFFLINE_MIN_SAMPLES",
                        "STEP_TOE_REPAIR", "STEP_TOE_REPAIR_PAD_S")
STATES = ("flat", "heel", "toe", "swing")      # state code = index; 255 = none
_NO_STATE = 255
MARGIN_S = 0.5                                 # raw samples kept either side of the run


# -- rows <-> arrays ------------------------------------------------------------
def pack_rows(rows):
    """Recorder rows as numpy arrays (float64 kept exactly)."""
    nan3 = np.full(3, np.nan)

    def opt3(v):
        return nan3 if v is None else np.asarray(v, dtype=float)

    return {
        "t": np.array([r[0] for r in rows], dtype=float),
        "dt": np.array([r[1] for r in rows], dtype=float),
        "state": np.array([STATES.index(r[2]) if r[2] in STATES else _NO_STATE
                           for r in rows], dtype=np.uint8),
        "lin": np.array([r[3] for r in rows], dtype=float),
        "pos": np.array([r[4] for r in rows], dtype=float),
        "vel": np.array([r[5] for r in rows], dtype=float),
        "pts": np.array([np.asarray(r[6], dtype=float) for r in rows]),
        "rot": np.array([r[7] for r in rows], dtype=float),
        "omega_b": np.array([r[8] for r in rows], dtype=float),
        "acc_b": np.array([opt3(r[9]) for r in rows]),
        "anchor": np.array([opt3(r[10]) for r in rows]),
        "mtp0": np.array([r[11] for r in rows], dtype=float),
        "lift_t": np.array([np.nan if r[12] is None else r[12] for r in rows], dtype=float),
        "toe_dir": np.array([opt3(r[13]) for r in rows]),
    }


def unpack_rows(a):
    """Inverse of pack_rows: the list of row tuples process_step takes."""
    rows = []
    for i in range(len(a["t"])):
        code = int(a["state"][i])
        acc = None if np.isnan(a["acc_b"][i][0]) else a["acc_b"][i]
        anchor = None if np.isnan(a["anchor"][i][0]) else a["anchor"][i]
        lift = None if np.isnan(a["lift_t"][i]) else float(a["lift_t"][i])
        p = a["pts"][i]
        rows.append((float(a["t"][i]), float(a["dt"][i]),
                     STATES[code] if code < len(STATES) else None,
                     a["lin"][i], a["pos"][i], a["vel"][i], (p[0], p[1], p[2]),
                     a["rot"][i], a["omega_b"][i], acc, anchor, float(a["mtp0"][i]), lift,
                     a["toe_dir"][i]))
    return rows


# -- config ---------------------------------------------------------------------
def config_snapshot():
    """Every ALL_CAPS setting that is plain data, as JSON-ready values."""
    out = {}
    for k in dir(cfg):
        if not k.isupper():
            continue
        v = _jsonable(getattr(cfg, k))
        try:
            json.dumps(v)
        except TypeError:
            continue
        out[k] = v
    return out


def apply_config(saved, keep_current=("STEP_", "GAIT_", "SAVE_", "RECORD_", "SESSIONS_")):
    """Put a saved config back, except the processing settings (default: those
    starting with STEP_ or GAIT_), which stay as they are now so reprocessing
    tests the current code and settings on the old data. Physical setup (IMU
    position, foot model, filters) is restored."""
    for k, v in saved.items():
        if k.startswith(keep_current) or not hasattr(cfg, k):
            continue
        cur = getattr(cfg, k)
        if isinstance(cur, tuple) and isinstance(v, list):
            v = tuple(tuple(x) if isinstance(x, list) else x for x in v)
        setattr(cfg, k, v)


def apply_overrides(items):
    """["NAME=VALUE", ...] onto cfg. VALUE is a Python literal, or a bare word."""
    for item in items:
        name, eq, text = item.partition("=")
        if not eq or not name.isupper() or not hasattr(cfg, name):
            raise ValueError("unknown setting in '{}' (use NAME=VALUE with a name from "
                             "receiver/mfc/config.py)".format(item))
        try:
            value = ast.literal_eval(text)
        except (ValueError, SyntaxError):
            value = text
        setattr(cfg, name, value)


# -- saving ---------------------------------------------------------------------
def _window(buf, t_lo, t_hi, width):
    rows = [r for r in list(buf) if t_lo <= r[0] <= t_hi]
    return np.array(rows, dtype=float).reshape(-1, width), bool(buf) and buf[0][0] > t_lo


def _collect(proc, walk, step_log, note=""):
    """(arrays, meta) of a published run: the rows process_step consumes, the raw
    samples around them, the stance history and everything needed to read them."""
    rows, spans = merge_rows(step_log)
    t_lo, t_hi = rows[0][0] - MARGIN_S, rows[-1][0] + MARGIN_S
    arrays = {"span_%s" % k: v for k, v in pack_rows(rows).items()}
    arrays["spans"] = np.array(spans, dtype=int)
    arrays["imu_raw"], imu_short = _window(proc.imu, t_lo, t_hi, 7)
    arrays["fsr_raw"], fsr_short = _window(proc.fsr, t_lo, t_hi, 3)
    arrays["mag_raw"], mag_short = _window(proc.mag, t_lo, t_hi, 4)
    hist = list(proc.stance.hist)
    before = [h for h in hist if h[0] < t_lo][-1:]                 # the stance in force at the start
    inside = [h for h in hist if t_lo <= h[0] <= t_hi]
    arrays["stance_t"] = np.array([h[0] for h in before + inside], dtype=float)
    arrays["stance_code"] = np.array([STATES.index(h[1]) if h[1] in STATES else _NO_STATE
                                      for h in before + inside], dtype=np.uint8)
    mounts = [m for _, m in step_log]
    arrays["mount_C"] = np.array([m["C"] for m in mounts])
    arrays["mount_r"] = np.array([[m["r"]["heel"], m["r"]["ball"], m["r"]["toe"]]
                                  for m in mounts])

    cal_text = None
    try:
        with open(proc.cal.path, "r") as fh:
            cal_text = json.load(fh)
    except (OSError, ValueError):
        pass
    text = getattr(proc, "status_text", None)
    meta = {
        "run_format": 1, "wire_format": WIRE_FORMAT_VERSION,
        "receiver_version": __version__, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "states": list(STATES), "ground_z": proc.foot.ground_z,
        "mounts": [{k: m[k] for k in ("L1", "L2", "y", "g_mag")} for m in mounts],
        "steps": len(spans), "samples": len(rows), "run_id": proc.step.run_id,
        "raw_short": {"imu": imu_short, "fsr": fsr_short, "mag": mag_short},
        "calibration": cal_text, "config": config_snapshot(),
        "filters": None if text is None else dict(text.filters),
        "live": walk_to_dict(walk, paths=False), "note": note,
    }
    return arrays, meta


def _free_base(directory, stem):
    root = os.path.join(directory, stem)
    base, n = root, 1
    while os.path.exists(base + ".json") or os.path.exists(base + ".npz"):
        n += 1
        base = "{}_{}".format(root, n)
    return base


def _rel_project(path):
    """The folder of a session file, relative to the project (so the capture still
    finds it when the project is moved)."""
    folder = os.path.dirname(os.path.abspath(path))
    try:
        return os.path.relpath(folder, cfg._PROJECT).replace(os.sep, "/")
    except ValueError:                           # another drive: keep it absolute
        return folder


def save_run(proc, walk, step_log, directory, note="", session=None, name=None,
             session_extra=None):
    """Write the capture of a published run. Returns the capture's .npz path (which
    exists only for format 1: format 2 is the sidecar alone, see the module note)."""
    arrays, meta = _collect(proc, walk, step_log, note)
    os.makedirs(directory, exist_ok=True)
    base = _free_base(directory, name or "{}_run{}".format(time.strftime("%Y-%m-%d_%H%M%S"),
                                                           proc.step.run_id))
    if session is not None and getattr(cfg, "SAVE_RUN_POINTERS", True):
        meta["run_format"] = 2
        meta["session"] = {"name": session.name, "dir": _rel_project(session.path),
                           "run_id": proc.step.run_id, "t": round(session.clock(), 3)}
        meta["session"].update(session_extra or {})
        with open(base + ".json", "w") as fh:
            json.dump(meta, fh, indent=1)
        return base + ".npz"
    np.savez_compressed(base + ".npz", **arrays)
    with open(base + ".json", "w") as fh:
        json.dump(meta, fh, indent=1)
    return base + ".npz"


# -- loading and reprocessing -----------------------------------------------------
class Run:
    """A loaded capture. rows are the recorder rows of the whole run, spans each
    step's (start, stop) in them, mounts one dict per step."""

    def __init__(self, path, rows, spans, mounts, meta, raw, stance):
        self.path, self.rows, self.spans, self.mounts = path, rows, spans, mounts
        self.meta, self.raw, self.stance = meta, raw, stance

    @property
    def ground_z(self):
        return self.meta["ground_z"]


def _base_of(path):
    for ext in (".npz", ".json"):
        if path.endswith(ext):
            return path[:-len(ext)]
    return path


def list_runs(directory=None):
    """Captures in a folder, newest first, as .npz-style paths (formats 1 and 2)."""
    directory = directory or cfg.STEP_RUNS_DIR
    found = [j for j in glob.glob(os.path.join(directory, "*.json"))
             if not os.path.basename(j).startswith(".")]
    found.sort(key=os.path.getmtime, reverse=True)
    return [j[:-5] + ".npz" for j in found]


def _fingerprint(meta, session_path):
    here = os.path.dirname(os.path.abspath(__file__))
    h = hashlib.sha1()
    for name in FINGERPRINT_FILES:
        with open(os.path.join(here, name), "rb") as fh:
            h.update(fh.read().replace(b"\r\n", b"\n"))
    h.update(json.dumps(meta["config"], sort_keys=True, default=str).encode())
    for name in FINGERPRINT_SETTINGS:
        if name not in meta["config"]:
            h.update(repr(getattr(cfg, name, None)).encode())
    h.update(str(os.path.getsize(session_path)).encode())
    h.update(str(RUN_FORMAT_VERSION).encode())
    return h.hexdigest()


def _session_path(meta):
    ref = meta["session"]
    directory = os.path.join(cfg._PROJECT, ref.get("dir", "sessions"))
    path = sess.find_session(ref["name"], directory)
    if path is None:
        raise ValueError("the session {} this capture was cut from is missing from {}".format(
            ref["name"], directory))
    return path


def _replay_arrays(meta, path):
    """Rebuild the arrays of a format 2 run by replaying its session with the
    settings saved in the sidecar (all of them: the rows are what the receiver
    produced then). The current settings are put back afterwards."""
    ref = meta["session"]
    found = {}

    def hook(proc, walk, step_log):
        if proc.step.run_id == ref["run_id"] and step_log:
            found["arrays"], _ = _collect(proc, walk, step_log)
            raise sess.StopReplay()

    keep = {k: getattr(cfg, k) for k in meta["config"] if hasattr(cfg, k)}
    apply_config(meta["config"], keep_current=())
    try:
        with contextlib.redirect_stdout(io.StringIO()):          # the replay narrates every step
            sess.replay(path, until=ref["t"] + 1.0, run_hook=hook,
                        arm_once=bool(ref.get("device")), step_count=ref.get("step_count"))
    finally:
        for k, v in keep.items():
            setattr(cfg, k, v)
    if "arrays" not in found:
        raise ValueError("replaying {} did not reproduce run {} (the receiver code changed "
                         "since it was recorded?)".format(os.path.basename(path), ref["run_id"]))
    return found["arrays"]


def _arrays_of(base, meta):
    """The npz-style arrays of a capture: its own file (format 1), or the cached or
    freshly replayed rows of its session (format 2)."""
    if meta.get("run_format") == 1:
        return np.load(base + ".npz")
    path = _session_path(meta)
    key = _fingerprint(meta, path)
    cache = os.path.join(os.path.dirname(base), CACHE_DIR, os.path.basename(base) + ".npz")
    if os.path.exists(cache):
        z = np.load(cache)
        if "cache_key" in z.files and str(z["cache_key"]) == key:
            return z
    print("[capture] rebuilding {} from its session (once)...".format(os.path.basename(base)))
    arrays = _replay_arrays(meta, path)
    os.makedirs(os.path.dirname(cache), exist_ok=True)
    np.savez_compressed(cache, cache_key=np.array(key), **arrays)
    return np.load(cache)


def load_run(path):
    base = _base_of(path)
    with open(base + ".json", "r") as fh:
        meta = json.load(fh)
    if meta.get("run_format") not in READABLE_RUN_FORMATS:
        raise ValueError("{} was written with run format {}; this receiver reads formats {}"
                         .format(os.path.basename(base), meta.get("run_format"),
                                 "/".join(str(f) for f in READABLE_RUN_FORMATS)))
    if meta.get("wire_format") != WIRE_FORMAT_VERSION:
        raise ValueError("{} was recorded with wire format {}; this receiver decodes format {}"
                         .format(os.path.basename(base), meta.get("wire_format"),
                                 WIRE_FORMAT_VERSION))
    z = _arrays_of(base, meta)
    rows = unpack_rows({k[5:]: z[k] for k in z.files if k.startswith("span_")})
    mounts = []
    for i, m in enumerate(meta["mounts"]):
        r = z["mount_r"][i]
        mounts.append(dict(m, C=z["mount_C"][i], r={"heel": r[0], "ball": r[1], "toe": r[2]}))
    spans = [tuple(int(x) for x in s) for s in z["spans"]]
    raw = {"imu": z["imu_raw"], "fsr": z["fsr_raw"], "mag": z["mag_raw"]}
    stance = [(float(t), STATES[c] if c < len(STATES) else None)
              for t, c in zip(z["stance_t"], z["stance_code"])]
    return Run(base + ".npz", rows, spans, mounts, meta, raw, stance)


def reprocess(run):
    """Run process_step on every step of a capture with the current code and
    config, then chain them. Returns (steps, walk or None, failures), failures a
    list of (step number, reason)."""
    steps, failures = [], []
    for i, ((a, b), mount) in enumerate(zip(run.spans, run.mounts)):
        try:
            steps.append(process_step(run.rows[a:b], run.ground_z, mount))
        except ValueError as exc:
            failures.append((i + 1, str(exc)))
    return steps, (build_walk(steps) if steps else None), failures


# -- outputs shared by tools/replay_run.py and tools/replay.py ------------------------
def write_outputs(walk, directory, base, csv=False):
    """walk as <base>.json (numbers, diagnostics, paths) and, with csv, one
    <base>_<chain>.csv per chain (t, state, step, then sensor, heel, ball and
    toe-tip x y z in the display frame). Returns the paths written."""
    os.makedirs(directory, exist_ok=True)
    written = []
    path = os.path.join(directory, base + ".json")
    with open(path, "w") as fh:
        json.dump(walk_to_dict(walk), fh)
    written.append(path)
    if csv:
        for name, chain in walk.chains().items():
            path = os.path.join(directory, "{}_{}.csv".format(base, name))
            with open(path, "w") as fh:
                fh.write("t,state,step,sx,sy,sz,hx,hy,hz,bx,by,bz,tx,ty,tz\n")
                for k in range(len(chain.t)):
                    vals = np.concatenate((chain.sensor[k], chain.heel[k], chain.ball[k],
                                           chain.toe[k]))
                    fh.write("{:.6f},{},{},{}\n".format(
                        chain.t[k], chain.state[k], chain.step_at(k) + 1,
                        ",".join("{:.6f}".format(v) for v in vals)))
            written.append(path)
    return written
