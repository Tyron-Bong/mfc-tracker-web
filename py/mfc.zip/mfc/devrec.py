"""Runs the tracker recorded on its own, brought into the receiver's world.

  import_run(mfr_bytes, name) -> info     writes recordings/<name>.mfcrec (a packed
                                           session) and step_runs/<name> (offline).json

A tracker run file (mfr.py) holds the same frames the live stream would have carried,
so it becomes an ordinary session: the frames in order, the tracker's status lines,
and the handheld's markers as the key events a person would have pressed (recal -> R,
fsr_cal -> U), placed just before the first IMU frame at or after the moment they mark.
Replaying it needs no G press: the step recorder is armed once the initialisation has
finished and publishes what it holds when the data ends (session.replay arm_once).
The calibration (C, T, I, the FSR cal on file) is the PC's current one, saved in the
sidecar, because the tracker cannot know it; R comes from the recal marker. U does not
become a U press: the PC's U waits 2 s, then for a second steadier than the FSRs ever are
on a lifted foot, and after 12 s takes whatever it has, which in a run is the walk (found
2026-10-14: lifted levels from walking, no stance, no steps). The handheld only marks
fsr_cal once the foot has been clear for FSR_MARK_WINDOW_S, so the lifted levels are the
mean of that window, put into the run's starting calibration (sidecar "fsr_from_marker").

The capture written is a pointer (capture.py, run format 2) that carries
"device": true and the step target, so load_run replays it the same way.
"""

import bisect
import json
import os
import struct
import time
import zlib

from . import __version__
from . import capture
from . import config as cfg
from . import mfr
from . import session as sess
from .pack import pack_records
from .wire import FLAG_FSR, FLAG_IMU, FSR_SAMPLE_FMT, HEADER_FMT, TS_WRAP_US, WIRE_FORMAT_VERSION

MARKER_EVENTS = {"recal": "recal", "fsr_cal": "fsr_cal", "step": "step",
                 "poses": "poses", "drift": "drift", "footcal": "footcal"}
ARM_MARKERS = ("recal",)          # the run is armed after the initialisation these start
FSR_MARK_WINDOW_S = 3.5           # the handheld's LIFT_S: fsr_cal starts a window this long in
                                  # which the foot was clear (hh_mfc.py, back-dated by this much)
FSR_MARK_TRIM_S = 0.25            # left off each end of that window
FSR_MARK_MIN_SAMPLES = 20


def _unwrap(base, prev):
    """base (uint32 us) on top of the previous absolute value `prev`."""
    epoch = (prev >> 32) << 32
    cand = base + epoch
    if cand + (TS_WRAP_US >> 1) < prev:
        cand += TS_WRAP_US
    return cand


def session_records(header, records):
    """The session records [(kind, t, payload)] of a parsed run file, and the number
    of frames that were not decodable as frames (kept as they are)."""
    frames, texts, marks = [], [], []
    prev, first = 0, None
    for kind, payload in records:
        if kind == mfr.T_FRAME and len(payload) >= struct.calcsize(HEADER_FMT):
            base, _seq, _count, _iv, flags = struct.unpack_from(HEADER_FMT, payload, 0)
            prev = _unwrap(base, prev)
            if first is None:
                first = prev
            frames.append((prev, flags, payload))
        elif kind == mfr.T_TEXT:
            texts.append((len(frames), payload))
        elif kind == mfr.T_MARK and len(payload) > 4:
            marks.append(mfr.marker(payload))
    if first is None:
        raise ValueError("the run file holds no data frames")

    out, t_last = [], 0.0
    # place each marker before the first IMU frame at or after its moment
    imu_idx = [i for i, f in enumerate(frames) if f[1] == FLAG_IMU]
    imu_t = [frames[i][0] for i in imu_idx]
    at = {}
    ref = first
    for us, name in sorted(marks, key=lambda m: _unwrap(m[0], ref)):
        t_abs = _unwrap(us, ref)
        ref = t_abs
        k = bisect.bisect_left(imu_t, t_abs)
        slot = imu_idx[k] if k < len(imu_idx) else len(frames)
        at.setdefault(slot, []).append(name)
    text_at = {}
    for pos, payload in texts:
        text_at.setdefault(pos, []).append(payload)

    def flush_text(pos):
        for payload in text_at.get(pos, ()):
            out.append((sess.T_TEXT, t_last, payload + b"\n"))

    for i, (t_abs, _flags, payload) in enumerate(frames):
        flush_text(i)
        t_last = max(t_last, (t_abs - first) / 1e6)
        for name in at.get(i, ()):
            if name in MARKER_EVENTS:
                out.append((sess.T_EVENT, t_last, MARKER_EVENTS[name].encode("utf-8")))
        out.append((sess.T_MOTION, t_last, payload))
    flush_text(len(frames))
    for name in at.get(len(frames), ()):
        if name in MARKER_EVENTS:
            out.append((sess.T_EVENT, t_last, MARKER_EVENTS[name].encode("utf-8")))
    return out, t_last


def marked_fsr_levels(records):
    """(lifted [toe, heel], noise [toe, heel], samples) from the FSR samples in the window
    of the last fsr_cal marker, or None (no marker, or too few samples in it)."""
    hsize = struct.calcsize(HEADER_FMT)
    ssize = struct.calcsize(FSR_SAMPLE_FMT)
    fsr, marks, prev = [], [], 0
    for kind, payload in records:
        if kind == mfr.T_FRAME and len(payload) >= hsize:
            base, _seq, count, _iv, flags = struct.unpack_from(HEADER_FMT, payload, 0)
            prev = _unwrap(base, prev)
            if flags == FLAG_FSR:
                for i in range(count):
                    off = hsize + i * ssize
                    if off + ssize > len(payload):
                        break
                    dt, toe, heel = struct.unpack_from(FSR_SAMPLE_FMT, payload, off)
                    fsr.append((prev + dt, toe, heel))
        elif kind == mfr.T_MARK and len(payload) > 4:
            us, name = mfr.marker(payload)
            if name == "fsr_cal":
                marks.append(_unwrap(us, prev))
    if not marks or not fsr:
        return None
    t0 = marks[-1] + FSR_MARK_TRIM_S * 1e6
    t1 = marks[-1] + (FSR_MARK_WINDOW_S - FSR_MARK_TRIM_S) * 1e6
    win = [(a, b) for t, a, b in fsr if t0 <= t <= t1]
    if len(win) < FSR_MARK_MIN_SAMPLES:
        return None
    n = len(win)
    mean = [sum(w[i] for w in win) / n for i in range(2)]
    sd = [(sum((w[i] - mean[i]) ** 2 for w in win) / n) ** 0.5 for i in range(2)]
    return mean, sd, n


def _file_crc(path):
    try:
        with open(path, "rb") as fh:
            return zlib.crc32(fh.read())
    except OSError:
        return None


def local_name(name, crc, directory=None):
    """(local name, already here) for a tracker run. The tracker reuses a name once its
    run is deleted (run01 again after DELALL), so a run is the same one only if its CRC32
    matches: the sidecar's device.crc, or the kept .mfr. A different run of the same name
    gets the first free of name-2, name-3, ... and never overwrites (2026-10-14: a second
    run01 overwrote the first)."""
    directory = directory or cfg.SESSIONS_OFFLINE_DIR
    base = _clean(name)
    free = None
    for k in range(1, 1000):
        cand = base if k == 1 else "{}-{}".format(base, k)
        path = os.path.join(directory, cand + ".mfcrec")
        if not os.path.exists(path):
            if free is None:
                free = cand
            if k > 1:
                break
            continue
        have = None
        try:
            have = int(sess.read_sidecar(path)["device"]["crc"], 16)
        except (KeyError, TypeError, ValueError, OSError):
            have = _file_crc(os.path.join(directory, cand + ".mfr"))
        if have == crc:
            return cand, True
    return free, False


def _clean(name):
    bad = '<>:"/\\|?*'
    return "".join("_" if c in bad else c for c in name).strip() or "run"


def write_session(data, name, directory=None, cal_path=None, note=""):
    """Convert the bytes of a tracker run file into recordings/<name>.mfcrec (+ sidecar).
    Returns (path, header)."""
    header, records = mfr.parse(data)
    if header.get("wire") != WIRE_FORMAT_VERSION:
        raise ValueError("the run was recorded with wire format {}; this receiver decodes "
                         "format {}".format(header.get("wire"), WIRE_FORMAT_VERSION))
    recs, duration = session_records(header, records)
    cal = sess._read_cal(cal_path) if cal_path else None
    fsr = marked_fsr_levels(records)
    if fsr is not None and cal is not None:
        cal = dict(cal)
        cal["fsr_lifted"], cal["fsr_noise"] = fsr[0], fsr[1]
        recs = [r for r in recs if not (r[0] == sess.T_EVENT and r[2] == b"fsr_cal")]
    directory = directory or cfg.SESSIONS_OFFLINE_DIR
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, _clean(name) + ".mfcrec")
    with open(path, "wb") as fh:
        fh.write(pack_records(recs))
    counts = {sess.T_MOTION: 0, sess.T_TEXT: 0, sess.T_EVENT: 0}
    for kind, _, _ in recs:
        counts[kind] = counts.get(kind, 0) + 1
    meta = {
        "session_format": sess.SESSION_FORMAT_VERSION, "wire_format": WIRE_FORMAT_VERSION,
        "receiver_version": __version__, "started": header.get("started") or
        time.strftime("%Y-%m-%d %H:%M:%S"), "ended": time.strftime("%Y-%m-%d %H:%M:%S"),
        "duration_s": round(duration, 3),
        "records": {"motion": counts[sess.T_MOTION], "text": counts[sess.T_TEXT],
                    "events": counts[sess.T_EVENT]},
        "payload_bytes": sum(len(p) for _, _, p in recs),
        "note": note or "tracker recording {}".format(name),
        "calibration_start": cal, "calibration_end": None, "status": None,
        "fsr_from_marker": None if fsr is None or cal is None else {
            "lifted": [round(v, 1) for v in fsr[0]], "noise": [round(v, 1) for v in fsr[1]],
            "samples": fsr[2], "window_s": FSR_MARK_WINDOW_S},
        "device": {"name": name, "tracker_name": header.get("name"), "crc": "{:08x}".format(zlib.crc32(data)),
                   "size": len(data), "steps": header.get("steps"), "header": header,
                   "markers": [list(mfr.marker(p)) for k, p in records if k == mfr.T_MARK
                               and len(p) > 4]},
    }
    with open(path + ".json", "w") as fh:
        json.dump(meta, fh, indent=1)
    return path, header


def import_run(data, name, cal_path=None, runs_dir=None, directory=None, log=print):
    """Bring one tracker run into the project. Returns a dict: session, capture (the
    pointer's path or None), steps (a list of per-step summaries), message."""
    path, header = write_session(data, name, directory, cal_path)
    target = int(header.get("steps") or cfg.STEP_COUNT)
    runs_dir = runs_dir or cfg.STEP_RUNS_DIR
    made = {}
    note = "tracker recording {}".format(name)

    def hook(proc, walk, step_log):
        if made or not step_log:
            return
        shim = type("Session", (), {})()
        shim.name, shim.path = sess.session_name(path), path
        shim.clock = lambda: proc.replay_t
        made["path"] = capture.save_run(
            proc, walk, step_log, runs_dir, note=note, session=shim,
            name="{} (offline)".format(_clean(name)),
            session_extra={"device": True, "step_count": target})
        made["walk"] = walk

    import contextlib
    import io
    sink = io.StringIO()
    with contextlib.redirect_stdout(sink):
        sess.replay(path, run_hook=hook, arm_once=True, step_count=target)
    if not made:
        why = [ln for ln in sink.getvalue().splitlines() if ln.startswith("[") and "step" in ln]
        return {"session": path, "capture": None, "walk": None,
                "message": "no steps found in {} ({})".format(
                    name, why[-1] if why else "no foot-flat to swing to foot-flat seen")}
    return {"session": path, "capture": made["path"], "walk": made["walk"],
            "message": made["walk"].summary()}
