"""Whole-session recording: the raw BLE stream, saved so any session can be
replayed through the same Processor (tools/replay.py), now or after the
processing has changed.

File sessions/<time>.mfcraw: a header (magic, SESSION_FORMAT_VERSION) then
records [type u8][t f64][length u32][payload], t being seconds since the start
of the session on the PC clock:

  1  motion notification, the exact bytes the unit sent
  2  UART text bytes (status lines)
  3  key event, the name of a request the Processor acted on (step, poses,
     recal, drift, footcal, fsr_cal); the tablet also writes "steps=N" (the
     STEP_COUNT of the G that follows) and "mark" (replay ignores it)

Key events are inputs, not processed output: R, U, G and the calibrations are
started from the keyboard, so without them the same bytes could not reproduce the
same state. An event is written when the Processor consumes the request, which is
inside the feed of the notification it affected, and the notification itself is
written after that feed, so on replay "set the flag, then feed" lands exactly
where it did live. Sidecar <file>.json: calibration at start and end, the status
lines, versions and a note.

When the session ends the .mfcraw is packed into <time>.mfcrec (the same records as
integer columns under xz, a third of the size, payloads byte-identical; mfc/pack.py)
and removed once the packed file has been decoded and compared. A session whose
program was killed stays a .mfcraw (tools/pack_sessions.py packs it later). Every
reader here takes either kind. Ref: "Run captures and sessions" in
docs/mfc_processing_reference.md.
"""

import atexit
import json
import os
import struct
import time

import numpy as np

from . import __version__
from .pack import PACKED_MAGIC, pack_records, same_records, unpack_records
from .wire import WIRE_FORMAT_VERSION

SESSION_FORMAT_VERSION = 1            # the records' meaning, in both file kinds
MAGIC = b"MFCRAW\x00"                 # the streamed .mfcraw; the packed .mfcrec is in pack.py
_HEAD = struct.Struct("<H")
_REC = struct.Struct("<BdI")
T_MOTION, T_TEXT, T_EVENT = 1, 2, 3
FLUSH_S = 1.0


def _read_cal(path):
    try:
        with open(path, "r") as fh:
            return json.load(fh)
    except (OSError, ValueError, TypeError):
        return None


class SessionWriter:
    """Written from the BLE thread only (motion, text and the Processor's events
    all happen there), so it needs no locking."""

    def __init__(self, directory, cal_path=None, text=None, note="", pack=True):
        self.pack = pack
        os.makedirs(directory, exist_ok=True)
        root = os.path.join(directory, time.strftime("%Y-%m-%d_%H%M%S"))
        base, n = root, 1
        while os.path.exists(base + ".mfcraw"):
            n += 1
            base = "{}_{}".format(root, n)
        self.path = base + ".mfcraw"
        self.cal_path, self.text, self.note = cal_path, text, note
        self._t0 = time.monotonic()
        self._last_flush = self._t0
        self._counts = {T_MOTION: 0, T_TEXT: 0, T_EVENT: 0}
        self._bytes = 0
        self._started = time.strftime("%Y-%m-%d %H:%M:%S")
        self._cal_start = _read_cal(cal_path) if cal_path else None
        self._closed = False
        self._fh = open(self.path, "wb")
        self._fh.write(MAGIC + _HEAD.pack(SESSION_FORMAT_VERSION))
        self._write_sidecar()
        atexit.register(self.close)

    def _record(self, kind, payload):
        if self._closed:
            return
        now = time.monotonic()
        self._fh.write(_REC.pack(kind, now - self._t0, len(payload)))
        self._fh.write(payload)
        self._counts[kind] += 1
        self._bytes += len(payload)
        if now - self._last_flush >= FLUSH_S:
            self._fh.flush()
            self._last_flush = now

    @property
    def name(self):
        """The session's base name, whichever kind of file it ends up as."""
        return session_name(self.path)

    def clock(self):
        """Seconds since the session started: the t its records carry."""
        return time.monotonic() - self._t0

    def motion(self, data):
        self._record(T_MOTION, bytes(data))

    def text_bytes(self, data):
        self._record(T_TEXT, bytes(data))

    def event(self, name):
        self._record(T_EVENT, name.encode("utf-8"))

    def _status(self):
        t = self.text
        if t is None:
            return None
        return {"filters": dict(t.filters), "sensors": t.sensors, "imu_fifo": t.imu_fifo,
                "mag_fifo": t.mag_fifo, "fifo_health": t.fifo_health}

    def _write_sidecar(self, ended=False):
        meta = {
            "session_format": SESSION_FORMAT_VERSION, "wire_format": WIRE_FORMAT_VERSION,
            "receiver_version": __version__, "started": self._started,
            "ended": time.strftime("%Y-%m-%d %H:%M:%S") if ended else None,
            "duration_s": round(time.monotonic() - self._t0, 3),
            "records": {"motion": self._counts[T_MOTION], "text": self._counts[T_TEXT],
                        "events": self._counts[T_EVENT]},
            "payload_bytes": self._bytes, "note": self.note,
            "calibration_start": self._cal_start,
            "calibration_end": _read_cal(self.cal_path) if (ended and self.cal_path) else None,
            "status": self._status(),
        }
        with open(self.path + ".json", "w") as fh:
            json.dump(meta, fh, indent=1)

    def close(self):
        if self._closed:
            return
        self._fh.flush()
        self._fh.close()
        self._closed = True
        self._write_sidecar(ended=True)
        if self.pack:
            try:
                self.path = pack_file(self.path)
            except (OSError, ValueError, MemoryError) as exc:      # the .mfcraw stays
                print("[session] could not pack {}: {}".format(os.path.basename(self.path), exc))


def session_name(path):
    """sessions/2026-10-13_184731.mfcraw (or .mfcrec) -> 2026-10-13_184731"""
    return os.path.splitext(os.path.basename(path))[0]


def find_session(name, directory):
    """The file of a session by its base name, packed one first; None if absent."""
    for ext in (".mfcrec", ".mfcraw"):
        path = os.path.join(directory, name + ext)
        if os.path.exists(path):
            return path
    return None


def pack_file(path, delete=True):
    """Pack a .mfcraw into a .mfcrec beside it and move its sidecar across. The
    packed file is decoded and compared record by record before the original goes
    (delete=False keeps it). Returns the packed path."""
    if not path.endswith(".mfcraw"):
        raise ValueError("{} is not a .mfcraw".format(os.path.basename(path)))
    records = list(read_records(path))
    blob = pack_records(records)
    if not same_records(records, unpack_records(blob)):
        raise ValueError("the packed copy of {} does not match; kept the original".format(
            os.path.basename(path)))
    out = path[:-len(".mfcraw")] + ".mfcrec"
    with open(out, "wb") as fh:
        fh.write(blob)
    if os.path.exists(path + ".json"):
        with open(path + ".json", "r") as fh:
            meta = json.load(fh)
        meta["packed"] = {"from": os.path.basename(path), "bytes": len(blob),
                          "original_bytes": os.path.getsize(path)}
        with open(out + ".json", "w") as fh:
            json.dump(meta, fh, indent=1)
    if delete:
        os.remove(path)
        if os.path.exists(path + ".json"):
            os.remove(path + ".json")
    return out


def read_sidecar(path):
    with open(path + ".json", "r") as fh:
        return json.load(fh)


def check_versions(path, meta):
    """Raise ValueError (with a plain message) if this receiver cannot replay the file."""
    if meta.get("session_format") != SESSION_FORMAT_VERSION:
        raise ValueError("{} was written with session format {}; this receiver reads format {}"
                         .format(os.path.basename(path), meta.get("session_format"),
                                 SESSION_FORMAT_VERSION))
    if meta.get("wire_format") != WIRE_FORMAT_VERSION:
        raise ValueError("{} was recorded with wire format {}; this receiver decodes format {}"
                         .format(os.path.basename(path), meta.get("wire_format"),
                                 WIRE_FORMAT_VERSION))


def read_records(path):
    """Yield (type, t, payload). A truncated tail (the program was killed
    mid-write) ends the stream quietly."""
    with open(path, "rb") as fh:
        head = fh.read(len(MAGIC) + _HEAD.size)
        if head[:len(PACKED_MAGIC)] == PACKED_MAGIC:
            fh.seek(0)
            yield from unpack_records(fh.read())
            return
        if head[:len(MAGIC)] != MAGIC:
            raise ValueError("{} is not an .mfcraw session".format(os.path.basename(path)))
        (version,) = _HEAD.unpack(head[len(MAGIC):])
        if version != SESSION_FORMAT_VERSION:
            raise ValueError("{} was written with session format {}; this receiver reads "
                             "format {}".format(os.path.basename(path), version,
                                                SESSION_FORMAT_VERSION))
        while True:
            h = fh.read(_REC.size)
            if len(h) < _REC.size:
                return
            kind, t, n = _REC.unpack(h)
            payload = fh.read(n)
            if len(payload) < n:
                return
            yield kind, t, payload


class StopReplay(Exception):
    """Raised by a run_hook to end the replay (it has what it came for)."""


KNOWN_EVENTS = ("step", "poses", "recal", "drift", "footcal", "fsr_cal")
STEPS_EVENT = "steps="                # "steps=6": STEP_COUNT from here on (the tablet's step picker)


def _offline_contact(proc, path):
    """FSR_OFFLINE_SPLIT for a tracker recording: measure the loaded level of both FSRs in the
    recording (a first pass through the decoder) and raise the contact level to it."""
    from . import config as cfg
    from .stance import loaded_levels
    from .wire import FrameDecoder

    class Collect:
        def __init__(self):
            self.fsr, self.gyro = [], []

        def on_imu(self, rows):
            self.gyro += [(t, float(np.linalg.norm(gyr))) for t, _acc, gyr in rows]

        def on_mag(self, rows):
            pass

        def on_fsr(self, rows):
            self.fsr += [(t, a, b) for t, a, b in rows]

    sink = Collect()
    dec = FrameDecoder(sink)
    for kind, _t, payload in read_records(path):
        if kind == T_MOTION:
            dec.feed(payload)
    proc.stance.split = cfg.FSR_OFFLINE_SPLIT
    proc.stance.loaded = loaded_levels(sink.fsr, sink.gyro, proc.stance.on, cfg.FSR_OFFLINE_STILL_DPS,
                                       cfg.FSR_OFFLINE_MIN_SAMPLES)
    if proc.stance.loaded is not None and proc.cal.fsr_present:
        proc.stance.derive(proc.cal)


class Replayer:
    """A session fed through a fresh Processor one record at a time, deterministically: the
    body of replay(), and what the tablet web app runs live in the browser on the records it
    is writing (web/py/mfc_web.py), so its results are those of a replay of its session.

    meta: the session's sidecar (calibration_start, device header). cal_path: the calibration
    file the Processor reads and its calibrations rewrite; it is created from
    calibration_start (default: a temp copy, never the real one). The other arguments are
    replay()'s."""

    def __init__(self, meta, path=None, cal_path=None, arm_all=False, run_hook=None, arm_once=False):
        from . import config as cfg
        from .pipeline import Processor
        from .wire import FrameDecoder, StatusText

        if cal_path is None:
            import tempfile
            cal_path = os.path.join(tempfile.mkdtemp(prefix="mfc_replay_"), "accel_drift_variables.json")
        if meta.get("calibration_start") is not None:
            with open(cal_path, "w") as fh:
                json.dump(meta["calibration_start"], fh)
        self.cal_path = cal_path
        self.proc = proc = Processor(cal_path)
        if meta.get("device") and any(f is not None for f in cfg.FSR_OFFLINE_SPLIT):
            _offline_contact(proc, path)
        proc.run_hook = run_hook
        self.dec = FrameDecoder(proc)
        self.text = text = StatusText()
        proc.status_text = text
        # A tracker recording keeps the unit's status block in its header, not as text records: feed
        # it first, as the UART does on a live connection (the FSR ring and the stored SYNC latency;
        # before 2026-10-15 neither reached the replay of an offline run).
        for line in ((meta.get("device") or {}).get("header") or {}).get("status") or ():
            text.feed((line + "\n").encode("utf-8"))
        self.arm_all, self.arm_once = arm_all, arm_once
        self.results, self.last, self.armed = [], None, False
        self.t = None

    def feed(self, kind, t, payload):
        """One record. Returns the WalkResult it published, or None."""
        proc = self.proc
        self.t = t
        proc.replay_t = t
        if kind == T_EVENT:
            name = payload.decode("utf-8")
            if name.startswith(STEPS_EVENT):
                # the tablet picks how many steps a G records and writes it just before the G
                from . import config as cfg
                cfg.STEP_COUNT = max(1, int(name[len(STEPS_EVENT):]))
            if name in KNOWN_EVENTS and not ((self.arm_all or self.arm_once) and name == "step"):
                setattr(proc, "request_" + name, True)
            if self.arm_once and name == "recal":
                # an R resets the step recorder: arm again once it has finished. (The
                # automatic initialisation at stream start armed it while the foot was
                # still being lifted; the handheld's recal comes after, 2026-10-14.)
                self.armed = False
        elif kind == T_TEXT:
            self.text.feed(payload)
        elif kind == T_MOTION:
            self.dec.feed(payload)
            walk = proc.step.result
            new = None
            if walk is not None and walk is not self.last:
                self.results.append((t, walk))
                self.last = new = walk
            if self.arm_all and proc.foot_active and proc.step.state == "idle":
                proc.request_step = True
            elif self.arm_once and not self.armed and proc.foot_active and proc.step.state == "idle":
                proc.request_step = True
                self.armed = True
            return new
        return None

    def finish(self):
        """The end of the data: an arm_once run publishes what it holds."""
        proc = self.proc
        if self.arm_once and proc.step.state != "idle":
            proc.step.cancel("end of the recording")
            if proc.step.result is not None and proc.step.result is not self.last:
                self.results.append((self.t, proc.step.result))


def replay(path, until=None, arm_all=False, run_hook=None, arm_once=False, step_count=None):
    """Feed a session through a fresh Processor, deterministically.

    The calibration file starts as the one the session began with (a temp copy:
    the calibrations in the session rewrite it, never the real one). Key events
    set the request flag just before the notification they preceded was fed.
    until: stop at this session time (seconds). arm_all: ignore recorded G
    presses and arm the step recorder whenever it is idle, so every step in the
    session is processed. run_hook(proc, walk, step_log) is called for every
    published run (raise StopReplay to end the replay there). arm_once: for
    recordings made without a G press (a tracker's own): arm the step recorder
    once, as soon as the initialisation has finished, and publish what it holds when
    the data ends. step_count: STEP_COUNT for this replay. Returns
    (processor, [(t, WalkResult)])."""
    from . import config as cfg

    meta = read_sidecar(path)
    check_versions(path, meta)
    rp = Replayer(meta, path, arm_all=arm_all, run_hook=run_hook, arm_once=arm_once)
    saved_count = cfg.STEP_COUNT
    if step_count is not None:
        cfg.STEP_COUNT = int(step_count)
    try:
        for kind, t, payload in read_records(path):
            if until is not None and t > until:
                break
            rp.feed(kind, t, payload)
        rp.finish()
    except StopReplay:
        pass
    finally:
        cfg.STEP_COUNT = saved_count
    return rp.proc, rp.results
