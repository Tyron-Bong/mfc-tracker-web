"""Every tunable setting of the receiver, grouped by subsystem.

Each setting carries a short reason (often a measurement). The long reasoning
behind each group is in docs/mfc_processing_reference.md, section named in the
group header. Runtime state never lives here.
"""

import os

WINDOW_S = 5.0               # seconds of history the plots show
START_FULLSCREEN = True      # open the window fullscreen (the F key toggles it)

# ---------------------------------------------------------------------------
# Attitude filter (ref: "Attitude filter")
# ---------------------------------------------------------------------------
ACC_KP = 3.0                 # 1/s, tilt pull, only while at rest
ACC_KI = 0.30                # 1/s^2, tilt disagreement into the gyro bias
MAG_KP = 0.25                # 1/s, heading pull, about 4 s of crossover
MAG_KI = 0.015               # 1/s^2, heading disagreement into the gyro bias
GYRO_BIAS_LIMIT_DPS = 2.0    # anti-windup, per axis, around the R measurement
MAG_DISTURB_TOL = 0.20       # reject the field if |m| is this far off its norm
MAG_TIMEOUT_S = 0.5          # no new distinct field sample in this long is stale
MAG_TRACK_WINDOW_S = 4.0     # compass test: regression window
MAG_TRACK_MIN_YAW_DEG = 25.0 # below this much turning the test cannot tell
MAG_TRACK_MAX_SLOPE = 0.35   # bearing-vs-yaw slope above this is not a compass

# Stationary gate (ref: "Stationary gate"). All three, held STILL_HOLD_S.
STILL_GYRO_DPS = 4.0         # rotation rate that still counts as at rest
STILL_ACC_TOL = 0.30         # m/s^2, how far |a| may sit from g
STILL_ACC_SPREAD = 0.15      # m/s^2, peak to peak within the window, per axis
STILL_ACC_WINDOW_S = 0.12    # sliding (not exponential) so it forgets on time
STILL_HOLD_S = 0.08          # both conditions must hold this long
STILL_HOLD_BIAS_S = 2.0      # gyro bias learning waits this long after R settles

# ---------------------------------------------------------------------------
# FSR calibration (U) and stance (ref: "FSR stance")
# ---------------------------------------------------------------------------
FSR_LABELS = ("Toe (D1)", "Heel (D0)")
FSR_CAL_PROMPT = "lift the foot clear of the ground"
FSR_CAL_SETTLE_S = 2.0       # time to get into position before the capture starts
FSR_CAL_HOLD_S = 1.0         # how long it must be steady, and what is averaged
FSR_CAL_SD = 30              # ADC counts, per-sensor spread within the window
FSR_CAL_DRIFT = 40           # ADC counts, first half of the window against the second
FSR_CAL_TIMEOUT_S = 12.0     # give up waiting for steady, take the window anyway
FSR_CONTACT_FRACTION = 0.20  # above the lifted level, per sensor
FSR_RELEASE = 0.50           # of that excess; 0.7 gave 21 changes in 5 s, 0.5 gave 9
FSR_DEBOUNCE_S = 0.03        # a new stance must hold this long to be reported
# Offline heel (and toe) contact level, for runs recorded on the tracker and rebuilt from their
# recording (2026-10-14, found on LAP-3). The lifted level is captured with the foot held up and
# the contact level is 20% above it (heel 15 to 23k), but in early swing the heel reads 13 to 30k
# (loaded: 45 to 58k), so 10 of 12 LAP-3 steps got a "heel" phase between the toe phase and the
# swing, and a heel-off that came late while the heel was already 20 to 60 mm up. (toe, heel)
# fraction of the way from the lifted level to the loaded level (the median of both sensors
# while the foot is still on the floor, measured in the recording itself); None keeps the
# FSR_CONTACT_FRACTION rule for that sensor. Contact is never set below that rule. Not used by
# Receiver Live (FSR_LIVE_SPLIT) so the live chain is unchanged.
FSR_LATENCY_APPLY = True     # shift the FSR times by the latency the tracker measured against the IMU (stomp
                             # calibration, stored on the tracker, sent as the SYNC status line); runs without
                             # one are untouched. Only used when n >= 3, spread <= 6 ms and |latency| <= 50 ms.
FSR_OFFLINE_SPLIT = (None, 0.5)
# With the FSR ring (the unit samples the FSRs in hardware, status line "FSR ring on", 2026-10-15),
# a toe in swing reads 0 to 100 and a foot held up for U reads the toe at 1.3 to 2.7k with
# hundreds of counts of noise, so the 20% rule put toe contact at 1.6 to 3.2k. The toe FSR sits
# under the ball and reads 2 to 9k into early swing (the shoe unbending), with spikes to about 2k
# in mid swing: LAP-4 had 0.4 to 0.6 s "toe" phases, swings chopped under STEP_MIN_SWING_S and
# 4 of 12 steps lost. (toe, heel) counts contact needs at least above the lifted level when the
# ring is on; None leaves that sensor alone. 5000 is about 0.1 of the way from lifted to loaded
# (55k): LAP-4 12 of 12 steps. Polled sessions (no ring line) are unchanged.
FSR_RING_MIN_EXCESS = (5000, None)
FSR_OFFLINE_STILL_DPS = 20.0   # the foot is still below this
FSR_OFFLINE_MIN_SAMPLES = 50   # loaded samples needed; fewer and the plain rule stays

# ---------------------------------------------------------------------------
# Two-segment foot model (ref: "Foot model")
# ---------------------------------------------------------------------------
FOOT_L1_M = 0.080            # toe tip to ball, until an I calibration exists
FOOT_L2_M = 0.220            # ball to heel, same
# Measured by Tyron 2026-10-09, same heel point as the foot calibration. A wrong value
# is worth a lot at forward toe-off (about 6 rad/s): 1 cm of error is 6 cm/s of start velocity.
IMU_FROM_HEEL_M = 0.130      # IMU forward of the heel contact point, along the sole
IMU_ABOVE_SOLE_M = 0.110     # IMU height over the floor-contact plane
IMU_LATERAL_M = 0.000        # IMU to the left of the foot's centre line
FOOT_FORWARD_BODY = (1.0, 0.0, 0.0)   # sensor axis that points heel to toe
FOOT_UP_BODY = (0.0, 0.0, 1.0)        # only used until the first R
FOOT_MODEL_FLIP_DEG = (0.0, 0.0, 180.0)  # x, y, z turns; z=180 reverses heel-to-toe
FOOT_SNAP_TO_GROUND = True   # re-anchor every contact onto the ground plane (level floor)
FOOT_MTP_RELAX_S = 0.15      # ball-joint angle at lift-off relaxes to straight (display only)
FOOT_SYNC_MAX_WAIT_S = 0.30  # IMU waits at most this long for the FSR stream
# After a gap in the IMU stream (a lost BLE batch, or the tracker's FIFO overflowing: LIN-4 lost
# 687 ms while the foot started to turn and the tilt came out 55 degrees off) the rotation in the
# gap was never integrated. The live gravity correction needs the foot still (STILL_GYRO_DPS),
# which a walking foot-flat never is, so the error stayed for the whole walk. After a gap the
# tilt is snapped to gravity at the first foot-flat held this long with the gyro under
# IMU_GAP_RELEVEL_DPS and |a| within IMU_GAP_RELEVEL_ACC of g (heading kept).
IMU_GAP_RELEVEL_S = 0.15
IMU_GAP_RELEVEL_DPS = 40.0
IMU_GAP_RELEVEL_ACC = 1.0     # m/s^2
FOOT_AXIS_CHECK_DEG = 60.0   # rotation seen in contact before the axis check runs

# ---------------------------------------------------------------------------
# Foot segment lengths, key I (ref: "Foot lengths")
# ---------------------------------------------------------------------------
FOOTCAL_GAUGES_MM = (50.0, 100.0)
FOOTCAL_SETTLE_S = 2.0       # time to place the shoe before a capture can start
FOOTCAL_HOLD_S = 1.0         # still for this long, and this is what is averaged
FOOTCAL_STILL_DPS = 3.0      # gyro magnitude that still counts as still
FOOTCAL_ACC_SD = 0.05        # m/s^2, per-axis spread allowed within the hold
FOOTCAL_MIN_MOVE_DEG = 4.0   # a gauge capture must be this far from the one before
FOOTCAL_REPEAT_DEG = 1.0     # flat at the end must match flat at the start
FOOTCAL_AGREE = 0.03         # the two gauges' lengths within 3% of the fit
FOOTCAL_L2_RANGE_M = (0.10, 0.35)      # plausible ball to heel
FOOTCAL_TOTAL_RANGE_M = (0.15, 0.45)   # plausible heel to toe tip
FOOTCAL_L1_RANGE_M = (0.02, 0.15)      # plausible toe tip to ball

# ---------------------------------------------------------------------------
# R, T and C procedures (ref: "Calibration procedures")
# ---------------------------------------------------------------------------
CAL_PHASE_S = 1.0            # each of the two initialisation phases of R
# R needs the foot still for its 2 s, and the automatic R at the first IMU frame can start while it
# moves (web app session 2026-10-15_144751: connected mid-step, gyro bias taken as -38/+13/-38 deg/s,
# every step turned 50 to 75 deg). A sample over either limit, or a phase-2 gyro trim over
# CAL_TRIM_MAX_DPS, starts R again from phase 1, so it completes once the foot has been still for
# 2 s. Measured: handling peaks at 150 to 360 deg/s and up to 4 g; a foot standing still reaches
# about 11 deg/s and 0.9 m/s^2 in single samples, and its trim stays under 1 deg/s (that session's
# was 30 to 40). Limits of 10 deg/s and 0.5 m/s^2 restarted R on still feet and never let it end.
CAL_STILL_DPS = 30.0         # |gyro| (raw in phase 1, bias-corrected in phase 2) above this: moved
CAL_STILL_ACC = 1.5          # m/s^2: |accel| off g (phase 1) or |world linear accel| (phase 2) above this: moved
CAL_TRIM_MAX_DPS = 2.0       # |phase-2 gyro trim| above this: the foot turned slowly during R
DRIFT_CAPTURE_S = 10.0       # T capture length
POSE_TARGET = 12             # C: captures before the fit runs on its own
POSE_MIN = 9                 # C: fewest that still get an ellipsoid fit
POSE_HOLD_S = 1.0            # C: stillness required before a pose is taken
POSE_STILL_DPS = 3.0         # C: gyro magnitude that still counts as stationary
POSE_STILL_MPS2 = 0.20       # C: accel deviation from its running mean
POSE_MOVE_DPS = 30.0         # C: must be exceeded before the next pose is armed
POSE_MIN_SEPARATION_DEG = 25.0
POSE_MIN_COVERAGE = 0.10     # smallest eigenvalue of the direction scatter
ACCEL_RADIUS_RANGE = (9.0, 10.5)     # m/s^2, a plausible local gravity
MAG_RADIUS_RANGE = (10.0, 120.0)     # uT, Earth's field runs about 25 to 65

# ---------------------------------------------------------------------------
# Single-step recording, key G (ref: "Step recording and swing integration")
# ---------------------------------------------------------------------------
STEP_COUNT = 3               # steps one G press records in a row; each needs the foot flat at mid-stance
STEP_PAD_S = 0.20            # flat time kept before heel-off, so the step starts at v = 0
STEP_MIN_FLAT_S = 0.10       # flat needed before leaving it counts as the start of a step
STEP_END_HOLD_S = 0.15       # flat held this long after swing means the step is complete
STEP_MIN_SWING_S = 0.15      # a swing shorter than this is a stance flicker, not a step
STEP_MAX_S = 5.0             # give up on a step that has not finished in this long
STEP_GAP_S = 0.05            # a gap between samples this long spoils the integration
# Offline swing trajectory (ref: "Swing trajectory methods"; code: swing.py, gait.py).
# Signal stages run first, in order: lag_compensation (advance accel and gyro by the on-die
# filter delays below), zero_phase (the same zero-phase low-pass on accel and gyro, then the
# attitude is re-integrated), tilt_dedrift (landing tilt from gravity at the end foot-flat
# spread back over the step as a gyro bias), start_level (first: re-level the step's starting tilt
# from gravity over its start foot-flat when the live attitude is grossly off, see below).
# Register more with @stage("accel").
STEP_ACCEL_STAGES = ("start_level", "zero_phase", "tilt_dedrift")
# start_level: the step starts from the live attitude, and a walking foot-flat is never still
# enough for the live filter's gravity correction, so after an IMU gap (LIN-4 2026-10-15: 687 ms
# lost while the foot started to turn) the tilt was 45 to 55 degrees off for the rest of the walk.
# If the mean accel over the quiet start foot-flat disagrees with the live tilt by more than this,
# the step's whole attitude is turned (about a horizontal axis, heading kept) to agree, and flagged.
# Small errors (walking drift, 1 to 8 degrees) are left to tilt_dedrift: re-levelling those helped
# some real steps and hurt others, the foot-flat is not still enough to beat the gyro there.
STEP_START_LEVEL_DEG = 10.0
STEP_START_LEVEL_STILL_DPS = 40.0   # the start foot-flat counts as quiet when its median gyro is under this (walking flats: 12 to 26)
STEP_FILTER_HZ = 20.0        # corner of the zero-phase filter
STEP_TILT_MAX_DEG = 5.0      # tilt_dedrift: a landing tilt error above this is not gyro drift (not applied, flagged)
STEP_ACCEL_LAG_S = 0.0       # lag_compensation: delay of the on-die accel filter (one pole: 1 / (2 pi fc))
STEP_GYRO_LAG_S = 0.0        # and of the on-die gyro filter; 0 leaves them alone
# Event refinement: move the FSR-timed events to a clear signature within STEP_EVENT_WINDOW_S.
# A tuple of the events to refine: "heel_strike" (the accel impact jump) and/or "toe_off" (the
# peak pitch rate). Empty = FSR times. Neither is on by default: the toe-off rule is unvalidated
# (it moves toe-off by 17 ms in a simulation that has no such signature).
STEP_REFINE_EVENTS = ()
STEP_EVENT_WINDOW_S = 0.040
STEP_EVENT_MIN_JUMP = 3.0    # m/s^2, the accel-magnitude jump that counts as an impact
STEP_EVENT_MIN_PEAK_DPS = 100.0   # deg/s, the pitch rate peak that counts as toe-off
# Toe-off guard (on whatever STEP_REFINE_EVENTS says): if at the FSR toe-off the pitch rate has
# fallen below this fraction of its push-off peak (or reversed), the foot had already left and
# the toe FSR was still reading contact; toe-off moves back to the peak, and the step is
# flagged. Found on 120cm-2 step 3 (2026-10-14): the toe read just over its release level
# 130 ms into the swing, the kinematic start velocity came out 2.1 m/s backwards and the
# stride 0.18 m (1.19 m with the guard); LAP-2 had 9 of 11 steps collapsed that way. Over the
# 13 captures it moves 17 of 64 steps, every one with a horizontal leftover of 100 mg or more
# (median 574 mg, 32 mg after; mean stride 0.40 to 1.24 m); the others sit at 0.68 or above.
# None = off.
STEP_TOEOFF_GUARD = 0.6
# Toe-phase repair (2026-10-14, found on 120cm-3 and LAP-3). The tracker's loop is blocked by every
# flash write for 120 to 400 ms and the FSRs are read in that loop, so a gap over the push-off
# leaves a step with no toe phase: the labels go flat > swing (or flat > heel > swing), the contact
# model has no pivot, the kinematic start velocity is 0 and the stride collapses (120cm-3 step 2
# 0.08 m, LAP-3 steps 11 and 12 0.11 and 0.24 m). The IMU has no gaps, so when a step has no toe row
# the heel rise is found from the gyro attitude (the foot's long axis against its still foot-flat),
# toe-off is the push-off pitch-rate peak (the rule of the toe-off guard) and the rows from the
# heel-off to it become the toe phase, ball anchored where the flat foot stood. The step is
# flagged. Steps that have a toe phase are not touched. Rise thresholds are measured: clean live
# heel-offs sit at 1.4 to 3.8 mm; a push-off is 15 mm of heel rise within a few frames.
STEP_TOE_REPAIR = True
STEP_TOE_REPAIR_PAD_S = 1.0       # flat rows the recorder keeps before a step, used only when a repair is needed
                                  # (the 0.2 s pad can start after the heel has begun to lift)
STEP_TOE_REPAIR_STILL_DPS = 20.0  # a row is still below this (foot-flat reads 3 to 15 deg/s)
STEP_TOE_REPAIR_RISE_M = 0.015    # the heel is up this far: the push-off has begun
STEP_TOE_REPAIR_HEELOFF_M = 0.003 # heel-off is the last row before that with the heel under this
STEP_TOE_REPAIR_SEARCH_S = 0.30   # how far past the FSR lift-off the push-off peak is searched
                                  # (a toe phase can sit inside a "swing" label)
STEP_TOE_REPAIR_MAX_S = 0.8       # longest plausible heel-off to toe-off
# The swing method drawn in the G window, and the others compared with it on the same steps
# (all are always computed). none: plain double integration from the kinematic toe-off state;
# benoussaad, quadratic_dz: flat-to-flat baselines; tilt: height-only rotation of the swing;
# contact_bounded: toe-off to heel strike with both ends from the contact model.
STEP_SWING_METHOD = "contact_bounded"
STEP_COMPARE_METHODS = ("benoussaad", "tilt")
# Start velocity of the plain integration ("none"): "kinematic" is w x (sensor - pivot) from
# the contact phase; "integrated" is the integral of the accel from foot-flat. Both are always
# reported side by side.
STEP_START_VELOCITY = "kinematic"
# Rolling contact (found on the first real steps, ref: "Rolling contact"). The real foot does not
# pivot about a fixed ball and heel: in the toe phase the pivot slides from the ball to the toe
# tip (228 to 236 mm from the heel at toe-off, ball 163, tip 240), and the heel is not pinned
# at the FSR heel strike (the sensor is still moving down 0.16 to 0.24 m/s, the implied heel
# pivot reaches 0 mm only 0.10 to 0.15 s later). STEP_TOEOFF_PIVOT: "toe_tip" (the pivot of the
# toe-off kinematic velocity) or "ball". STEP_END_CONDITION: "foot_flat" (contact_bounded takes
# the end height from the heel strike and the end velocity from the foot-flat ZUPT) or
# "heel_pinned" (the heel-pinned velocity at the FSR heel strike).
STEP_TOEOFF_PIVOT = "toe_tip"
# The toe-phase POSITION: the sensor rises more than the ball-pinned model says (the ball lifts
# as the heel comes up). STEP_TOE_ROLL is how far from the ball to the toe tip the foot is
# treated as pivoting for the position: 0 = ball pinned (the live foot model), 1 = toe tip on the
# floor. 0.41 on all three real steps (sensor rise at toe-off 17 to 18 mm from the foot-flat
# integration, ball model 0 mm, tip model 41 to 44 mm), from a single session: it is a measured
# parameter, checked per step (rise_model_mm against rise_int_mm), to be confirmed on more steps.
STEP_TOE_ROLL = 0.4
STEP_FIT_WINDOW_S = 0.12      # the IMU position fit uses this much of the end of the toe phase (toe-tip pivot)
STEP_END_CONDITION = "foot_flat"
# Heading of the chained walk, all from the live attitude's yaw (gyro, held by the magnetometer
# while the field is accepted), as angles from the first step's starting facing.
# "world": each step keeps the world direction it was measured in (its stride direction), so the
#   foot turns during the swing as it did and lands at its measured heading, and a turn draws as
#   the curve it was (2026-10-14, Tyron: the landing heading must follow the swing).
# "facing": each step's stride is laid along the way the foot faces at its starting foot-flat;
#   the foot's own turn in the swing is drawn against that line, so in a turn the stride is
#   pointed wrong and the heading snaps at the next foot-flat (the behaviour until 2026-10-14).
# "straight": every step on the first step's line.
STEP_HEADING = "world"
STEP_HEADING_ROWS = 5         # foot-flat rows averaged for the facing
# A step is flagged (never silently corrected) above these.
STEP_FLAG_LEFTOVER_MG = 12.8      # fitted constant accel error, twice the 6.4 mg budget for 5 mm
STEP_FLAG_HELDOUT_MM = 10.0       # end height predicted from the end velocity alone
STEP_FLAG_TILT_DEG = 2.0          # tilt error at landing
STEP_FLAG_PIVOT_MMS = 200.0       # kinematic toe-off velocity (the pivot in use) against the foot-flat integration
STEP_FLAG_RISE_MM = 12.0          # sensor rise at toe-off, model against the foot-flat integration
STEP_FLAG_APAV_MG = 10.0          # flat-to-flat: 2 dz / T^2 against v_end / T
GAIT_TRAILS = True           # draw growing heel and toe-tip trails in the G window
GAIT_TRAIL_LEN_S = None      # None keeps the whole path from the start; a number keeps the last N seconds
STEP_PLAYBACK_SPEED = 0.5    # animation speed against real time
STEP_PLAYBACK_PAUSE_S = 0.8  # hold on the final pose before the loop restarts

# ---------------------------------------------------------------------------
# Records for tuning (ref: "Run captures and sessions")
# ---------------------------------------------------------------------------
_PROJECT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SAVE_STEP_RUNS = True        # every G run saves its rows and the raw samples around it, to STEP_RUNS_DIR
STEP_RUNS_DIR = os.path.join(_PROJECT, "step_runs")
RECORD_SESSIONS = True       # every connection saves the raw BLE stream (about 5 KB/s), to SESSIONS_DIR
SESSIONS_DIR = os.path.join(_PROJECT, "sessions")
PACK_SESSIONS = True         # at the end of a connection the session is packed into a lossless .mfcrec (a third of the size)
SAVE_RUN_POINTERS = True     # with a session recorded, a G capture is its small sidecar only; its rows are replayed from the session
SESSIONS_OFFLINE_DIR = os.path.join(_PROJECT, "recordings")   # runs pulled from the tracker by Receiver Offline (packed sessions)
