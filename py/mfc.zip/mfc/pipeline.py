"""The processing chain: decoded rows in, calibrated pose and position out.

Processor is the FrameDecoder's sink and owns every piece of processing state.
Threading: the BLE thread is the only writer. The UI thread only reads, and
sets the request_* flags, which are acted on at the start of the next IMU
frame (never mid-sample).

States: wait -> cal1 -> cal2 -> run, plus poses (C), drift (T), footcal (I).
"""

import math
from collections import deque

import numpy as np

from . import config as cfg
from . import capture
from .attitude import AttitudeFilter
from .calfile import Calibration
from .foot import FootModel
from .gait import StepRecorder
from .mathutil import euler_from_q
from .procedures import DriftCal, FootCal, InitCal, PoseCal
from .stance import StanceDetector


class Processor:
    def __init__(self, cal_path):
        self.cal = Calibration(cal_path)
        self.stance = StanceDetector()
        self.foot = FootModel(self.cal, self.stance)
        self.att = AttitudeFilter()
        self.init_cal = InitCal()
        self.pose_cal = PoseCal()
        self.drift_cal = DriftCal()
        self.foot_cal = FootCal()
        self.step = StepRecorder()           # passive: reads the foot model, never feeds back
        self.step.on_publish = self._save_run
        self.capture_dir = None              # set by enable_capture(): where G runs are saved
        self.status_text = None              # the StatusText, if any (its filters go in captures)
        self._fsr_t = -1e18                  # newest FSR time handed on
        self.on_event = None                 # callback(name) when a key request is acted on
        self.session = None                  # the SessionWriter recording this connection, if any
        self.run_hook = None                 # callback(proc, walk, step_log) for every published run

        # Display buffers, written here and read by the plot. Row 1 buffers are
        # never rewritten, so the raw record stays raw.
        self.imu = deque(maxlen=4000)        # (t, ax, ay, az, gx, gy, gz)
        self.mag = deque(maxlen=2000)        # (t, mx, my, mz)
        self.fsr = deque(maxlen=2000)        # (t, toe, heel)
        # One row per IMU sample: 0 t | 1-3 roll pitch yaw deg | 4-6 world linear
        # accel | 7-9 velocity | 10-12 position | 13 the magnetometer's own heading
        self.out = deque(maxlen=4000)

        self.state = "wait"
        self.state_since = 0.0
        self.state_msg = "waiting for IMU data"
        self.pos = np.zeros(3)
        self.vel = np.zeros(3)
        self.last_t = None
        self.last_mag = None
        # IMU samples wait for the FSR stream to cover their time (stance lookup);
        # mag samples are released by timestamp in the same loop.
        self._imu_pending = deque()          # (t, acc, gyr)
        self._mag_pending = deque(maxlen=2000)   # (t, field)
        self.imu_gaps = []                   # (t, ms) gaps in the IMU stream while running (IMU_GAP_RELEVEL_*)
        self._relevel = None                 # after a gap: body accel samples of the foot-flat being collected, else None

        self.request_recal = False
        self.request_drift = False
        self.request_poses = False
        self.request_fsr_cal = False
        self.request_footcal = False
        self.request_step = False

        self.reload_calibration()            # active from the first sample

    # -- calibration ---------------------------------------------------------
    def reload_calibration(self):
        self.cal.load()
        if self.cal.fsr_present:
            self.stance.derive(self.cal)
        self.foot.build()

    def enable_capture(self, directory):
        """Save every published G run (rows and raw samples) into directory."""
        self.capture_dir = directory

    def _save_run(self, walk, step_log):
        if self.run_hook is not None:
            self.run_hook(self, walk, step_log)
        if self.capture_dir is None or not step_log:
            return
        try:
            path = capture.save_run(self, walk, step_log, self.capture_dir,
                                    session=self.session)
            print("[capture] saved", path)
        except Exception as exc:                     # noqa: BLE001, never lose a run to a disk problem
            print("[capture] could not save the run:", exc)

    def _event(self, name):
        if self.on_event is not None:
            self.on_event(name)

    @property
    def foot_active(self):
        return self.stance.cal_ok and self.state == "run"

    # -- sink for FrameDecoder -----------------------------------------------
    def _step_blocker(self):
        if not self.stance.cal_ok:
            return "press U to calibrate the FSRs first"
        if self.state != "run":
            return "wait for R to finish"
        return ""

    def on_imu(self, rows):
        # not exclusive with the calibration keys. A G during R (cal1, cal2) with U done waits for
        # R to finish instead of being refused: R now waits for a still foot, so it can take longer
        # than the 2 s a person expects (2026-10-15). Without U it is refused as before.
        if self.request_step and not (self.state in ("cal1", "cal2") and self.stance.cal_ok):
            self.request_step = False
            self._event("step")
            self.step.toggle(self._step_blocker())
        if self.request_poses:
            self.request_poses = False
            self._event("poses")
            self.pose_cal.finish(self) if self.state == "poses" else self.pose_cal.begin(self)
        elif self.request_recal:
            self.request_recal = False
            self._event("recal")
            self.init_cal.begin(self)
        elif self.request_drift:
            self.request_drift = False
            self._event("drift")
            self.drift_cal.begin(self)
        elif self.request_footcal:
            self.request_footcal = False
            self._event("footcal")
            self.foot_cal.finish(self, abort=True) if self.state == "footcal" \
                else self.foot_cal.begin(self)
        if self.state == "wait":
            self.init_cal.begin(self)       # the first IMU frame starts R
        for t, acc, gyr in rows:
            self.imu.append((t, acc[0], acc[1], acc[2], gyr[0], gyr[1], gyr[2]))
            self._imu_pending.append((t, acc, gyr))
        self._drain()

    def on_mag(self, rows):
        for t, vec in rows:
            self.mag.append((t, vec[0], vec[1], vec[2]))
            # Released to the IMU chain by timestamp, not on arrival: a field
            # reading up to 300 ms newer than the sample it corrects would turn
            # every rotation into a heading error.
            self._mag_pending.append((t, vec))

    def fsr_shift_s(self):
        """Seconds to take off every FSR time: the latency the tracker measured against its IMU in
        a stomp calibration (FSR_LATENCY_APPLY), 0 without one or when it does not look sound."""
        st = self.status_text
        lat = None if st is None or not cfg.FSR_LATENCY_APPLY else st.fsr_latency_us
        if lat is None or st.sync_n < 3 or st.sync_sd_us > 6000 or abs(lat) > 50000:
            return 0.0
        return lat / 1e6

    def _fsr_ring_rule(self):
        """FSR_RING_MIN_EXCESS once the unit says its FSRs come from the ring (the status block
        arrives a few seconds into a connection, or first in a replayed recording)."""
        st = self.status_text
        ring = st is not None and st.fsr_ring is not None and st.fsr_ring.startswith("on")
        want = cfg.FSR_RING_MIN_EXCESS if ring else None
        if want != self.stance.min_excess:
            self.stance.min_excess = want
            if self.stance.cal_ok:                   # lifted levels from the file or from a U this session
                self.stance.derive(self.cal)

    def on_fsr(self, rows):
        self._fsr_ring_rule()
        shift = self.fsr_shift_s()
        for t, f1, f2 in rows:
            if shift:
                # never backwards: the latency can arrive a few seconds into a live connection
                t = max(t - shift, self._fsr_t)
            self._fsr_t = t
            self.fsr.append((t, f1, f2))
            if self.request_fsr_cal:
                self.request_fsr_cal = False
                self._event("fsr_cal")
                self.stance.begin_cal()
            self.stance.process(t, f1, f2, self.cal)
        self._drain()                        # the stance just moved on

    def _gap_relevel(self, t, dt, acc, gyr):
        """After an IMU gap: collect a foot-flat held IMU_GAP_RELEVEL_S with the foot nearly still
        and snap the tilt to its mean accel (the rotation lost in the gap is otherwise never
        corrected while walking)."""
        flat = (self.stance.cal_ok and self.stance.at(t) == "flat"
                and float(np.linalg.norm(gyr)) < cfg.IMU_GAP_RELEVEL_DPS
                and abs(float(np.linalg.norm(acc)) - self.att.g_mag) < cfg.IMU_GAP_RELEVEL_ACC)
        if not flat:
            self._relevel = []
            return
        self._relevel.append((dt, acc))
        if sum(d for d, _ in self._relevel) >= cfg.IMU_GAP_RELEVEL_S:
            deg = self.att.level_tilt(np.mean([a for _, a in self._relevel], axis=0))
            self._relevel = None
            print("[attitude] re-levelled at {:.2f} s after the IMU gap: the tilt was {:.1f} deg off".format(t, deg))

    # -- IMU chain -----------------------------------------------------------
    def _drain(self):
        """Process queued IMU samples whose stance is known. Past
        FOOT_SYNC_MAX_WAIT_S they go through on the last known stance."""
        if not self._imu_pending:
            return
        newest = self._imu_pending[-1][0]
        horizon = newest
        if self.foot_active and self.fsr and not self.stance.calibrating:
            horizon = max(self.fsr[-1][0] - cfg.FSR_DEBOUNCE_S,
                          newest - cfg.FOOT_SYNC_MAX_WAIT_S)
        while self._imu_pending and self._imu_pending[0][0] <= horizon:
            t, acc, gyr = self._imu_pending.popleft()
            while self._mag_pending and self._mag_pending[0][0] <= t:
                self.last_mag = self._mag_pending.popleft()[1]
            self._process_imu(t, acc, gyr)

    def _process_imu(self, t, acc_raw, gyr_raw):
        cal, att = self.cal, self.att
        if self.step.state != "idle" and not self.foot_active:
            self.step.cancel("cancelled: a calibration or reset started")
        if self.state_since is None:
            self.state_since = t

        # C bias and scale come off first, in raw sensor units (the frame the
        # ellipsoid was fitted in); the in-session terms after, in output units.
        acc = ((acc_raw - cal.accel_bias) / cal.accel_scale
               - att.accel_bias_trim - cal.accel_drift_bias)
        gyr = gyr_raw - att.gyro_bias - att.gyro_bias_online

        if self.state == "poses":
            # Outside the attitude path: only still averages are needed. RAW
            # accel, so a repeat C is absolute rather than incremental.
            self.last_t = t
            self.pose_cal.update(self, t, acc_raw, gyr)
            return
        if self.state == "footcal":
            self.last_t = t
            self.foot_cal.update(self, t, acc, gyr)
            return
        if self.state == "cal1":
            self.init_cal.phase1_sample(self, t, acc, gyr_raw)
            return

        dt = 0.0 if self.last_t is None else t - self.last_t
        self.last_t = t
        if dt <= 0.0 or dt > 0.05:           # gap or reorder, skip forward
            if dt > 0.05 and self.state == "run":
                self.imu_gaps.append((t, dt * 1000.0))
                self._relevel = []
                print("[!] IMU gap of {:.0f} ms at {:.2f} s: the attitude may be off until the next "
                      "foot-flat".format(dt * 1000.0, t))
            return

        # During a drift capture the pose runs on the gyro alone even at rest;
        # the accel correction would absorb a constant accel bias into the
        # attitude and leave nothing quadratic for the fit to find.
        if self._relevel is not None:
            self._gap_relevel(t, dt, acc, gyr)
        rot, lin = att.update(t, dt, acc, gyr, self.last_mag, cal,
                              correcting=self.state != "drift",
                              in_run=self.state == "run")

        if self.state == "cal2":
            self.init_cal.phase2_sample(self, t, gyr, lin)
            return

        if self.foot_active:
            self.pos, self.vel = self.foot.step(t, dt, rot, np.radians(gyr), lin,
                                                self.pos, self.vel)
            self.step.sample(t, dt, self.foot, rot, np.radians(gyr), lin,
                             self.pos, self.vel, acc, att.g_mag)
        else:                                # plain dead reckoning until U is done
            self.vel = self.vel + lin * dt
            self.pos = self.pos + self.vel * dt

        roll, pitch, yaw = euler_from_q(att.q)
        self.out.append((t, math.degrees(roll), math.degrees(pitch), math.degrees(yaw),
                         lin[0], lin[1], lin[2], self.vel[0], self.vel[1], self.vel[2],
                         self.pos[0], self.pos[1], self.pos[2], att.yaw_mag))

        if self.state == "drift":
            self.drift_cal.sample(self, t, gyr)
