"""Single-step recording, the step results, and the chain of several steps.

StepRecorder watches the live foot model (passively: it never feeds anything
back) and, when one full step has been taken (flat, heel-off or toe-lift, swing,
landing, flat), hands the rows to process_step(). That runs the offline chain in
swing.py (signal stages, contact phases from kinematics, every swing method over
the same window) and packages the result in the display frame: a StepResult with
one Traj per method. Ref: "Step recording and swing integration" and "Swing
trajectory methods" in docs/mfc_processing_reference.md.

One G press records cfg.STEP_COUNT consecutive steps: the flat at the end of a
step is the start of the next, so the recorder re-arms with that flat already in
its pad. The finished steps are chained end to end into one WalkResult (build_walk)
for the step window.

Threading: the BLE thread is the only writer. A finished run is published as
one WalkResult by a single attribute assignment, which is all the UI reads.
"""

import math
from bisect import bisect_right
from collections import deque
from dataclasses import dataclass, field

import numpy as np

from . import config as cfg
from . import swing
from .swing import STAGES, stage          # noqa: F401, re-exported: @gait.stage("accel", name)

SHORT = {"contact_bounded": "CB", "benoussaad": "Benouss", "quadratic_dz": "quad dz",
         "tilt": "tilt", "none": "none"}


def _mfc(toe_z, s0, s1):
    """Provisional MFC: the valley after the first toe-height peak in swing
    (peak searched in the first 60% of the swing). Returns (peak, mfc, index)."""
    head = s0 + max(1, int(0.6 * (s1 - s0)))
    peak = s0 + int(np.argmax(toe_z[s0:head]))
    idx = peak + int(np.argmin(toe_z[peak:s1]))
    return float(toe_z[s0:s1].max()), float(toe_z[idx]), idx


# -- results -----------------------------------------------------------------
@dataclass(frozen=True)
class Traj:
    """One swing method's step in the display frame (origin at the start heel on
    the floor, x along the stride, z up from the floor)."""
    sensor: np.ndarray              # N x 3
    heel: np.ndarray
    ball: np.ndarray
    toe: np.ndarray
    land_point: np.ndarray          # the landing heel (or ball) at the first contact row
    land: str                       # "heel" or "ball"
    stride_m: float
    peak_toe_m: float
    mfc_m: float
    mfc_idx: int
    metrics: dict = field(default_factory=dict)


@dataclass(frozen=True)
class StepResult:
    """A finished step. The selected method's trajectory is `traj[method]`; the
    arrays and numbers of it are also available directly (res.sensor, res.mfc_m)."""
    t: np.ndarray                   # s from the start of the recording
    state: list                     # row labels after event refinement
    i0: int                         # last contact row before the swing (refined)
    i1: int                         # last swing row (refined)
    duration_s: float
    swing_s: float
    t_start: float                  # device time of the first row
    method: str
    traj: dict                      # method name -> Traj
    events: dict = field(default_factory=dict)
    metrics: dict = field(default_factory=dict)
    flags: tuple = ()
    diag: dict = field(default_factory=dict)

    @property
    def sensor(self): return self.traj[self.method].sensor

    @property
    def heel(self): return self.traj[self.method].heel

    @property
    def ball(self): return self.traj[self.method].ball

    @property
    def toe(self): return self.traj[self.method].toe

    @property
    def stride_m(self): return self.traj[self.method].stride_m

    @property
    def peak_toe_m(self): return self.traj[self.method].peak_toe_m

    @property
    def mfc_m(self): return self.traj[self.method].mfc_m

    @property
    def mfc_idx(self): return self.traj[self.method].mfc_idx

    @property
    def land_point(self): return self.traj[self.method].land_point

    def summary(self):
        """Short text lines for one step."""
        d, m = self.diag, self.metrics
        lines = ["method {}   stride {:.2f} m   {:.2f} s".format(
                     self.method, self.stride_m, self.duration_s),
                 "swing {:.2f} s   toe peak {:.0f} mm".format(self.swing_s,
                                                               self.peak_toe_m * 1000.0),
                 "MFC (provisional) {:.0f} mm".format(self.mfc_m * 1000.0),
                 "fitted accel leftover {:+.1f} mg vertical, {:.1f} mg horizontal".format(
                     m["az_mg"], m["ah_mg"]),
                 "start v ({}) gap {:.0f} mm/s".format(d["start_method"], d["dv_lift_mms"]),
                 "landing v gap {:.0f} mm/s".format(d["dv_land_mms"])]
        fit = d.get("mount_fit")
        if fit:
            lines.append("IMU fit {:.0f} / {:.0f} mm (model {:.0f} / {:.0f})".format(
                fit["x_m"] * 1000.0, fit["z_m"] * 1000.0, cfg.IMU_FROM_HEEL_M * 1000.0,
                cfg.IMU_ABOVE_SOLE_M * 1000.0))
        elif d.get("mount_fit_why"):
            lines.append("IMU fit: " + d["mount_fit_why"])
        return lines


# -- several steps chained ---------------------------------------------------
@dataclass(frozen=True)
class Chain:
    """The steps of a run laid end to end on one time base (device seconds from
    the first sample). Each step keeps its own display frame; step k+1 is shifted
    in x and y so its start heel sits where step k's end heel is. `starts` is the
    first sample index of each step, `ids` its number (0-based), so a chain that
    skipped a step (no post-processed path) still labels the rest correctly."""
    t: np.ndarray
    state: list
    sensor: np.ndarray
    heel: np.ndarray
    ball: np.ndarray
    toe: np.ndarray
    starts: tuple
    ids: tuple
    mfc_pts: np.ndarray                     # K x 3, the provisional MFC point of each step
    land_pts: object = None                 # K x 3 landing points (post-processed only)
    ghost: object = None                    # raw sensor paths, NaN row between steps

    @property
    def duration_s(self):
        return float(self.t[-1])

    def step_at(self, k):
        """Step number (0-based) that sample k belongs to."""
        return self.ids[max(0, bisect_right(self.starts, k) - 1)]


# Stance transitions the G window marks on the heel and toe trails:
# (from, to) -> (kind, which point's trail). Kinds: strike, flat, heel_off, off.
STANCE_EVENTS = {("swing", "heel"): ("strike", "heel"), ("swing", "toe"): ("strike", "toe"),
                 ("heel", "flat"): ("flat", "heel"), ("toe", "flat"): ("flat", "heel"),
                 ("flat", "toe"): ("heel_off", "heel"), ("flat", "heel"): ("heel_off", "toe"),
                 ("toe", "swing"): ("off", "toe"), ("heel", "swing"): ("off", "toe")}


def chain_events(state):
    """[(sample index, kind, point)] for every stance transition in a chain's
    state list, in time order."""
    out = []
    for k in range(1, len(state)):
        ev = STANCE_EVENTS.get((state[k - 1], state[k]))
        if ev is not None:
            out.append((k, ev[0], ev[1]))
    return out


def _shift_to(end_heel, start_heel):
    """x, y shift that puts a step's start heel on the previous step's end heel."""
    if end_heel is None:
        return np.zeros(3)
    s = np.asarray(end_heel) - np.asarray(start_heel)
    s[2] = 0.0
    return s


def facing_deg(pts):
    """World heading, degrees counter-clockwise from +x, of the foot over some rows:
    pts is K x 3 x 3 (heel, ball, toe per row). Circular mean of the horizontal
    heel-to-toe direction (heel to ball where the foot vector is degenerate); None if
    there is none."""
    pts = np.asarray(pts, dtype=float).reshape(-1, 3, 3)
    if len(pts) == 0:
        return None
    v = pts[:, 2, :2] - pts[:, 0, :2]
    short = np.hypot(v[:, 0], v[:, 1]) < 0.02
    v[short] = (pts[:, 1, :2] - pts[:, 0, :2])[short]
    ok = np.hypot(v[:, 0], v[:, 1]) > 1e-6
    if not ok.any():
        return None
    ang = np.arctan2(v[ok, 1], v[ok, 0])
    return float(np.degrees(np.arctan2(np.sin(ang).sum(), np.cos(ang).sum())))


def wrap_deg(a):
    return (a + 180.0) % 360.0 - 180.0


def step_turns(steps):
    """Per step, the heading change (degrees) of its start-flat facing from the previous
    step's (None for the first, or where a heading is missing)."""
    heads = [(s.diag.get("heading_deg") or {}).get("start") for s in steps]
    return [None if k == 0 or heads[k] is None or heads[k - 1] is None
            else wrap_deg(heads[k] - heads[k - 1]) for k in range(len(steps))]


def chain_angles(steps):
    """Rotation (degrees about the vertical, counter-clockwise) that lays each step's
    display frame (x along its own stride) in the chain.
    "world": the step's world stride direction minus the first step's start facing, which
    turns the display frame back into the world (the foot faces +x at the first start), so
    every row keeps the yaw it was measured with: the foot turns through the swing and
    lands at its measured heading.
    "facing": its start-flat facing minus the first step's.
    0 for STEP_HEADING "straight", and where a heading is missing."""
    if cfg.STEP_HEADING not in ("world", "facing", "straight"):
        raise ValueError("STEP_HEADING must be 'world', 'facing' or 'straight'")
    heads = [(s.diag.get("heading_deg") or {}) for s in steps]
    ref = heads[0].get("start") if heads else None
    if cfg.STEP_HEADING == "straight" or ref is None:
        return [0.0] * len(steps)
    key = "stride" if cfg.STEP_HEADING == "world" else "start"
    return [0.0 if h.get(key) is None else wrap_deg(h[key] - ref) for h in heads]


def _rot_z(deg):
    c, s = math.cos(math.radians(deg)), math.sin(math.radians(deg))
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def _join(parts):
    """Concatenate step parts in time order, dropping samples that an earlier
    part already covers (the flat pad the next step shares with the last one)."""
    cols = {k: [] for k in ("t", "sensor", "heel", "ball", "toe")}
    state, starts, ids, mfc, land, ghost = [], [], [], [], [], []
    n, last = 0, -np.inf
    for p in parts:
        f = int(np.searchsorted(p["t"], last, side="right"))
        starts.append(n)
        ids.append(p["id"])
        for key in cols:
            cols[key].append(p[key][f:])
        state += list(p["state"][f:])
        n += len(p["t"]) - f
        last = max(last, float(p["t"][-1]))
        mfc.append(p["mfc"])
        if p["land"] is not None:
            land.append(p["land"])
        if p["ghost"] is not None:
            ghost += [p["ghost"], np.full((1, 3), np.nan)]
    return Chain(state=state, starts=tuple(starts), ids=tuple(ids),
                 mfc_pts=np.array(mfc), land_pts=np.array(land) if land else None,
                 ghost=np.vstack(ghost[:-1]) if ghost else None,
                 **{k: np.concatenate(v) for k, v in cols.items()})


def _table(cols, rows, labels, cur):
    """Monospace table. cols: (title, format spec or None for text). rows: one
    value list per step, labels the step names. A mean row is added for two or
    more steps. `cur` is the row index to mark (the step being replayed)."""
    def fmt(v, spec):
        if v is None:
            return "-"
        return "{:{}}".format(v, spec) if spec else str(v)

    cells = [[fmt(v, spec) for v, (_, spec) in zip(r, cols)] for r in rows]
    labels = list(labels)
    if len(rows) > 1:
        mean = []
        for j, (_, spec) in enumerate(cols):
            vals = [r[j] for r in rows if r[j] is not None]
            mean.append("{:{}}".format(float(np.mean(vals)), spec) if spec and vals else "")
        cells.append(mean)
        labels.append("mean")
    widths = [max(len(title), *(len(c[j]) for c in cells))
              for j, (title, _) in enumerate(cols)]
    lines = ["       " + "  ".join("{:>{}}".format(title, w)
                                   for (title, _), w in zip(cols, widths))]
    for i, (label, c) in enumerate(zip(labels, cells)):
        lines.append("{} {:<5}".format(">" if cur == i else " ", label) + " "
                     + "  ".join("{:>{}}".format(v, w) for v, w in zip(c, widths)))
    return lines


@dataclass(frozen=True)
class WalkResult:
    """A finished run of steps: each StepResult, and the walk chained for the
    selected method and for every other method on the same steps. This is the
    one object the step window reads."""
    steps: tuple
    method: str
    chain: Chain                    # the selected method
    compare: dict                   # the other methods, name -> Chain (same steps, same places)

    @property
    def duration_s(self):
        return self.chain.duration_s

    def chains(self):
        """Every method's chain by name, the selected one first."""
        return {self.method: self.chain, **self.compare}

    def _cmp_names(self):
        return [self.method] + [m for m in cfg.STEP_COMPARE_METHODS if m in self.compare] \
            + (["none"] if "none" in self.compare and self.method != "none"
               and "none" not in cfg.STEP_COMPARE_METHODS else [])

    def table(self, cur=None):
        """Readout lines for the selected method: per step the numbers that say how
        far to trust it (fitted leftover accel, start velocity offset, tilt, the
        event shifts), then the flags, the IMU fit and the settings."""
        steps = self.steps
        rows = []
        turns = step_turns(steps)
        for s in steps:
            m, t = s.metrics, s.traj[self.method]
            ev = s.events.get("shift_ms")
            row = [t.stride_m, s.swing_s, t.peak_toe_m * 1000.0, t.mfc_m * 1000.0,
                   m["az_mg"], m["ah_mg"], m["dv_z_mms"], m.get("pivot_mm"),
                   m.get("res_used_mms"), m.get("rise_err_mm"), turns[len(rows)]]
            if cfg.STEP_REFINE_EVENTS:
                row.append("{:+.0f}/{:+.0f}".format(*ev) if ev else "-")
            rows.append(row)
        cols = [("stride m", ".2f"), ("swing s", ".2f"), ("toe pk mm", ".0f"),
                ("MFC? mm", ".0f"), ("a_z mg", "+.1f"), ("a_h mg", ".1f"),
                ("dv_z mm/s", "+.0f"), ("pivot mm", ".0f"), ("res mm/s", ".0f"),
                ("rise mm", "+.0f"), ("turn deg", "+.0f")]
        if cfg.STEP_REFINE_EVENTS:
            cols.append(("toe-off/heel ms", None))
        lines = _table(cols, rows, ["{}/{}".format(i + 1, len(steps)) for i in range(len(steps))],
                       cur)
        for i, s in enumerate(steps):
            if s.flags:
                lines.append("step {} flagged: {}".format(i + 1, "; ".join(s.flags)))
        d0 = steps[0].diag
        fits = [s.diag["mount_fit"] for s in steps if s.diag.get("mount_fit")]
        lines.append("turn: the way the foot faces at the step's start flat, from the previous step's "
                     "(gyro yaw with the magnetometer); the walk is drawn {}".format(
                         {"world": "as measured: each step in its own direction, the foot turning through "
                                   "the swing", "facing": "with each stride along its start facing"}.get(
                             cfg.STEP_HEADING, "with all steps on a straight line")))
        lines.append("pivot: where the data says the foot pivots at toe-off (ball {:.0f}, toe tip {:.0f} mm "
                     "from the heel)".format(1000.0 * d0["l2"], 1000.0 * (d0["l2"] + d0["l1"])))
        lines.append("res: kinematic start velocity (pivot {}) minus the foot-flat integration;  rise: toe-off "
                     "sensor rise, model (roll {:.2f}) minus integration".format(
                         cfg.STEP_TOEOFF_PIVOT, cfg.STEP_TOE_ROLL))
        lines.append("{}   filter {}   events {}   start velocity {}".format(
            self.method, ", ".join(
                n if n != "zero_phase" else "zero-phase {:.0f} Hz".format(cfg.STEP_FILTER_HZ)
                for n in cfg.STEP_ACCEL_STAGES) or "on-die only",
            "refined ({})".format(", ".join(cfg.STEP_REFINE_EVENTS)) if cfg.STEP_REFINE_EVENTS
            else "FSR", d0["start_method"]))
        if fits:
            xs = [f["x_m"] * 1000.0 for f in fits]
            zs = [f["z_m"] * 1000.0 for f in fits]
            lines.append("IMU fit {:.0f} / {:.0f} mm, spread {:.0f} / {:.0f}  (model {:.0f} / {:.0f})".format(
                np.mean(xs), np.mean(zs), np.ptp(xs), np.ptp(zs),
                cfg.IMU_FROM_HEEL_M * 1000.0, cfg.IMU_ABOVE_SOLE_M * 1000.0))
        else:
            lines.append("IMU fit: " + (d0.get("mount_fit_why") or "-"))
        return lines

    def compare_table(self, cur=None):
        """Readout lines comparing the methods on the same steps: the MFC each
        gives, the flat-to-flat accelerations that disagree when the error is not a
        constant acceleration, the held-out check, and the step-to-step spread."""
        steps = self.steps
        names = self._cmp_names()
        cols = [("MFC {} mm".format(SHORT.get(n, n)), ".0f") for n in names]
        cols += [("a_p mg", "+.1f"), ("a_v mg", "+.1f"), ("held-out mm", "+.1f"),
                 ("land err mm", "+.0f")]
        rows = []
        for s in steps:
            m = s.metrics
            rows.append([s.traj[n].mfc_m * 1000.0 for n in names]
                        + [m.get("ap_mg"), m.get("av_mg"), m.get("heldout_mm"),
                           m.get("land_err_mm")])
        lines = _table(cols, rows, ["{}/{}".format(i + 1, len(steps)) for i in range(len(steps))],
                       cur)
        if len(steps) >= 2:
            for n in names[:2]:
                pk = [s.traj[n].peak_toe_m * 1000.0 for s in steps]
                mf = [s.traj[n].mfc_m * 1000.0 for s in steps]
                lines.append("spread over {} steps, {}: toe peak {:.1f} mm, MFC {:.1f} mm (std)".format(
                    len(steps), SHORT.get(n, n), np.std(pk, ddof=1), np.std(mf, ddof=1)))
        lines.append("a_p = 2 dz / T^2 and a_v = v_end / T over foot-flat to foot-flat agree for a constant accel error")
        return lines

    def summary(self):
        """One console line for the run."""
        return "[steps] {} recorded ({}): stride mean {:.2f} m, MFC? mean {:.0f} mm".format(
            len(self.steps), self.method, float(np.mean([s.stride_m for s in self.steps])),
            1000.0 * float(np.mean([s.mfc_m for s in self.steps])))


def build_walk(steps):
    """Chain finished StepResults (in recording order) into a WalkResult. Every
    method is chained with the selected method's placement, so on the same steps
    their trajectories start each step at the same heel and differ only where the
    methods differ."""
    steps = tuple(steps)
    method = steps[0].method
    names = list(steps[0].traj)
    t0 = steps[0].t_start
    parts = {n: [] for n in names}
    end = None                                # chained end heel of the previous step
    angles = chain_angles(steps)
    for k, res in enumerate(steps):
        t_abs = res.t + (res.t_start - t0)
        # the step turned onto the way the foot faces, about the vertical through its start heel
        if angles[k] == 0.0:
            rot = lambda a: a                                       # noqa: E731
        else:
            R = _rot_z(angles[k])
            rot = lambda a, R=R: a @ R.T                            # noqa: E731
        sel = res.traj[method]
        sel_heel = rot(sel.heel)
        sh = _shift_to(end, sel_heel[0])
        end = sel_heel[-1] + sh
        for n in names:
            tr = res.traj[n]
            ghost = None
            if n == method and "none" in res.traj and method != "none":
                ghost = rot(res.traj["none"].sensor[:res.i1 + 1]) + sh   # the plain integration under it
            parts[n].append(dict(
                id=k, t=t_abs, state=res.state, sensor=rot(tr.sensor) + sh, heel=rot(tr.heel) + sh,
                ball=rot(tr.ball) + sh, toe=rot(tr.toe) + sh, mfc=rot(tr.toe[tr.mfc_idx]) + sh,
                land=rot(tr.land_point) + sh, ghost=ghost))
    chains = {n: _join(p) for n, p in parts.items()}
    return WalkResult(steps=steps, method=method, chain=chains[method],
                      compare={n: c for n, c in chains.items() if n != method})


# -- the offline chain -------------------------------------------------------
def fit_imu_position(dt, state, rot, omega_b, v_b, i0, mount):
    """Where the sensor must sit for the pivot kinematics to match the velocity
    integrated from foot-flat. During the last contact phase before swing the
    pivot (ball or heel) is still, so v_sensor = w_world x (R C d_f), linear in
    the two unknowns (distance from the heel, height above the sole). Returns
    (fit dict, "") or (None, reason)."""
    pivot = state[i0]
    if pivot not in ("toe", "heel"):
        return None, "no pivot phase before swing"
    j = i0
    while j > 0 and state[j - 1] == pivot:
        j -= 1
    x_p = mount["L2"] if pivot == "toe" else 0.0
    if pivot == "toe" and cfg.STEP_TOEOFF_PIVOT == "toe_tip" and "L1" in mount:
        # the pivot has rolled onto the toe tip by the end of the toe phase: use only that part
        x_p = mount["L2"] + mount["L1"]
        while j < i0 - 3 and float(np.sum(dt[j:i0 + 1])) > cfg.STEP_FIT_WINDOW_S:
            j += 1
    ks = list(range(j, i0 + 1))
    C, y_s = mount["C"], mount["y"]
    w = np.array([rot[k] @ omega_b[k] for k in ks])
    peak_dps = math.degrees(float(np.linalg.norm(w, axis=1).max()))
    span = float(np.sum(dt[j:i0 + 1]))
    if peak_dps < 100.0 or span < 0.08:
        return None, "too little rotation ({:.0f} deg/s peak)".format(peak_dps)
    rows_a, rows_b = [], []
    for wk, k in zip(w, ks):
        RC = rot[k] @ C
        rows_a.append(np.column_stack((np.cross(wk, RC[:, 0]), np.cross(wk, RC[:, 2]))))
        rows_b.append(v_b[k] - np.cross(wk, RC @ np.array([-x_p, y_s, 0.0])))
    A, b = np.vstack(rows_a), np.concatenate(rows_b)
    sol = np.linalg.lstsq(A, b, rcond=None)[0]
    rms = float(np.sqrt(np.mean((A @ sol - b) ** 2)))
    return {"x_m": float(sol[0]), "z_m": float(sol[1]), "rms_mms": 1000.0 * rms,
            "peak_dps": peak_dps, "pivot": pivot}, ""


def process_step(rows, ground_z, mount=None):
    """rows: the recorder's rows (see StepRecorder.sample). mount: the foot mount
    ({"C", "L2", "L1", "r", "y", "g_mag"}). Runs the signal stages, then every
    swing method over the same lift-off to heel-strike window, and packages each
    in the display frame. Returns a StepResult, or raises ValueError with a reason
    fit to display."""
    method = cfg.STEP_SWING_METHOD
    if method not in swing.METHODS:
        raise ValueError("STEP_SWING_METHOD must be one of {}".format(sorted(swing.METHODS)))
    if cfg.STEP_START_VELOCITY not in ("kinematic", "integrated"):
        raise ValueError("STEP_START_VELOCITY must be 'kinematic' or 'integrated'")
    d = swing.from_rows(rows, ground_z, mount)
    repair = swing.repair_toe_phase(d)
    swing.run_stages("accel", cfg.STEP_ACCEL_STAGES, d)
    paths, i0r, i1r, info, ctx = swing.run_methods(d, list(swing.METHODS))
    w = ctx["window"]
    n = len(d.t)
    floor = d.floor

    # Display frame: x along the stride (start heel to end heel of the selected
    # method), else the foot; the same transform for every method.
    sel = paths[method]
    o = sel.heel[0].copy()
    o[2] = floor
    h = sel.heel[-1] - sel.heel[0]
    h[2] = 0.0
    if np.linalg.norm(h) < 0.05:
        h = sel.ball[0] - sel.heel[0]
        h[2] = 0.0
    h_world = h.copy()
    h = h / max(float(np.linalg.norm(h)), 1e-9)
    side = np.array([-h[1], h[0], 0.0])

    def disp(a):
        x = a - o
        return np.stack((x @ h, x @ side, x[..., 2]), axis=-1)

    # Which way the foot faces at the two foot-flats and which way the stride went, in the
    # world frame of the live attitude (gyro yaw held by the magnetometer): build_walk lays
    # the steps out by the first of these.
    nrow = max(1, int(cfg.STEP_HEADING_ROWS))
    heading = {"start": facing_deg(d.pts_live[max(0, d.f0 - nrow + 1):d.f0 + 1]),
               "end": facing_deg(d.pts_live[d.f1:d.f1 + nrow]),
               "stride": float(np.degrees(np.arctan2(h_world[1], h_world[0])))}

    land = "ball" if w.land_state == "toe" else "heel"
    trajs = {}
    for name, p in paths.items():
        sensor, heel, ball, toe = disp(p.pos), disp(p.heel), disp(p.ball), disp(p.toe)
        peak, mfc, idx = _mfc(toe[:, 2], i0r + 1, i1r + 1)
        trajs[name] = Traj(
            sensor=sensor, heel=heel, ball=ball, toe=toe,
            land_point=(heel if land == "heel" else ball)[w.e].copy(), land=land,
            stride_m=float(np.linalg.norm(heel[-1, :2] - heel[0, :2])),
            peak_toe_m=peak, mfc_m=mfc, mfc_idx=idx, metrics=p.metrics)

    # Diagnostics, as before: the two start velocities, the landing velocity gap,
    # the height the plain integration ended at, and the IMU position fit.
    none_p, none_v = ctx["none_p"], ctx["none_v"]
    cb = ctx["cb"]
    f2f = paths["benoussaad"].metrics
    diag = {
        "v_lift_A": w.v0.copy(), "v_lift_B": ctx["v0_int"].copy(),
        "start_method": cfg.STEP_START_VELOCITY,
        "dv_lift_mms": 1000.0 * float(np.linalg.norm(w.v0 - ctx["v0_int"])),
        "v_land_int": none_v[-1].copy(), "v_land_kin": w.v_end.copy(),
        "dv_land_mms": 1000.0 * float(np.linalg.norm(none_v[-1] - w.v_end)),
        "land_dz_m": float(none_p[-1, 2] - w.z_end),
        "mount_fit": None, "mount_fit_why": "", "l1": d.L1, "l2": d.L2,
        "heading_deg": heading,
    }
    if mount is not None and "C" in mount and "L2" in mount and "y" in mount:
        diag["mount_fit"], diag["mount_fit_why"] = fit_imu_position(
            d.dt, d.state, d.rot, d.omega, ctx["v_b_all"], i0r, mount)

    g_mg = 1000.0 / d.g
    bm = ctx["boundary"]
    metrics = {
        "az_mg": cb["da_z"] * g_mg, "ah_mg": cb["da_h"] * g_mg, "dv_z_mms": cb["dv_z"] * 1000.0,
        "heldout_mm": cb["heldout_m"] * 1000.0, "ap_mg": f2f["a_p"] * g_mg,
        "av_mg": f2f["a_v"] * g_mg, "land_err_mm": diag["land_dz_m"] * 1000.0,
        "pivot_mm": bm["pivot_mm"], "rise_int_mm": bm["rise_int_mm"],
        "rise_model_mm": bm["rise_model_mm"],
        "rise_err_mm": bm["rise_model_mm"] - bm["rise_int_mm"],
        "res_ball_mms": bm["res_ball_mms"],
        "res_tip_mms": bm["res_tip_mms"], "res_heel_mms": bm["res_heel_mms"],
        "res_used_mms": bm["res_tip_mms"] if (cfg.STEP_TOEOFF_PIVOT == "toe_tip"
                                              and paths["none"].state[w.i0] == "toe")
        else bm["res_ball_mms"],
        "tilt_deg": d.notes.get("tilt_before_deg"),
        "tilt_after_deg": d.notes.get("tilt_after_deg"),
        "gyro_bias_dps": d.notes.get("gyro_bias_dps"),
    }
    flags = []
    if abs(metrics["az_mg"]) > cfg.STEP_FLAG_LEFTOVER_MG or metrics["ah_mg"] > cfg.STEP_FLAG_LEFTOVER_MG:
        flags.append("accel leftover {:+.0f}/{:.0f} mg (over {:.1f})".format(
            metrics["az_mg"], metrics["ah_mg"], cfg.STEP_FLAG_LEFTOVER_MG))
    if metrics["res_used_mms"] > cfg.STEP_FLAG_PIVOT_MMS:
        flags.append("toe-off kinematics {:.0f} mm/s from the data (over {:.0f}): the foot pivots "
                     "near {:.0f} mm from the heel, not where the model says".format(
                         metrics["res_used_mms"], cfg.STEP_FLAG_PIVOT_MMS, metrics["pivot_mm"]))
    if abs(metrics["rise_err_mm"]) > cfg.STEP_FLAG_RISE_MM:
        flags.append("sensor rise at toe-off {:.0f} mm in the model against {:.0f} mm from the "
                     "integration (over {:.0f})".format(metrics["rise_model_mm"],
                                                        metrics["rise_int_mm"], cfg.STEP_FLAG_RISE_MM))
    if cfg.STEP_END_CONDITION == "heel_pinned" and metrics["res_heel_mms"] > cfg.STEP_FLAG_PIVOT_MMS:
        flags.append("heel-pinned velocity at heel strike {:.0f} mm/s from the data (over {:.0f})".format(
            metrics["res_heel_mms"], cfg.STEP_FLAG_PIVOT_MMS))
    if abs(metrics["heldout_mm"]) > cfg.STEP_FLAG_HELDOUT_MM:
        flags.append("held-out {:+.0f} mm (over {:.0f})".format(
            metrics["heldout_mm"], cfg.STEP_FLAG_HELDOUT_MM))
    if abs(metrics["ap_mg"] - metrics["av_mg"]) > cfg.STEP_FLAG_APAV_MG:
        flags.append("a_p {:+.0f} vs a_v {:+.0f} mg: not a constant accel error".format(
            metrics["ap_mg"], metrics["av_mg"]))
    guard = info.get("toe_off_guard")
    if guard:
        flags.append("toe-off moved {:.0f} ms earlier: the toe FSR read contact after the push-off had "
                     "ended (pitch rate {})".format(-guard["ms"], "reversed" if guard["frac"] < 0 else
                                                    "down to {:.0f}% of its peak".format(100.0 * guard["frac"])))
    if repair and "refused" in repair:
        flags.append("toe phase not seen by the FSRs, not rebuilt: " + repair["refused"])
    elif repair:
        flags.append("toe phase rebuilt from the gyro: the FSRs said {}; heel-off {:+.0f} ms and toe-off {:+.0f} ms "
                     "from the FSR ones (heel up {:.0f} mm, pitch rate {:.0f} deg/s)".format(
                         repair["fsr"], repair["heel_off_ms"], repair["toe_off_ms"],
                         repair["rise_mm"], repair["peak_dps"]))
    if d.notes.get("start_level_deg"):
        flags.append("starting tilt re-levelled from the foot-flat: the live attitude was {:.0f} deg off "
                     "(an IMU gap?)".format(d.notes["start_level_deg"]))
    if d.notes.get("tilt_skipped"):
        flags.append(d.notes["tilt_skipped"] + ": attitude not de-drifted")
    elif metrics["tilt_deg"] is not None and metrics["tilt_deg"] > cfg.STEP_FLAG_TILT_DEG:
        flags.append("landing tilt {:.1f} deg (over {:.0f}), de-drifted to {:.2f}".format(
            metrics["tilt_deg"], cfg.STEP_FLAG_TILT_DEG, metrics["tilt_after_deg"]))

    i0_fsr = d.notes.get("fsr_i0", d.i0)
    events = {"i0": i0r, "i1": i1r, "i0_fsr": i0_fsr, "i1_fsr": d.i1, "f0": d.f0, "f1": d.f1,
              "f0_fsr": d.notes.get("fsr_f0", d.f0),
              "shift_ms": (1000.0 * float(d.t[i0r] - d.t[i0_fsr]), info["heel_strike_ms"]),
              "toe_off_guard": guard, "toe_repair": repair,
              "found": (info["toe_off_found"], info["heel_strike_found"]),
              "t_toe_off": float(d.t[i0r] - d.t[0]), "t_heel_strike": float(d.t[w.e] - d.t[0])}
    return StepResult(
        t=d.t - d.t[0], state=paths[method].state, i0=i0r, i1=i1r,
        duration_s=float(d.t[-1] - d.t[0]), swing_s=float(d.t[i1r] - d.t[i0r]),
        t_start=float(d.t[0]), method=method, traj=trajs, events=events, metrics=metrics,
        flags=tuple(flags), diag=diag)


def merge_rows(step_log):
    """The unique rows of a run in time order and each step's (start, stop) span.
    Consecutive steps share their flat pad as the very same row objects."""
    index, rows, spans = {}, [], []
    for step_rows, _mount in step_log:
        idx = []
        for r in step_rows:
            i = index.get(id(r))
            if i is None:
                i = index[id(r)] = len(rows)
                rows.append(r)
            idx.append(i)
        spans.append((idx[0], idx[-1] + 1))
    return rows, spans


def _jsonable(v):
    if isinstance(v, dict):
        return {str(k): _jsonable(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    if isinstance(v, np.ndarray):
        return v.tolist()
    if isinstance(v, (np.floating, np.integer)):
        return v.item()
    return v


def walk_to_dict(walk, paths=True):
    """A WalkResult as plain data (JSON): per step the numbers, diagnostics and,
    if paths, the display-frame paths of every chain the walk carries."""
    out = {"steps": []}
    for i, st in enumerate(walk.steps):
        out["steps"].append({
            "index": i, "t_start": st.t_start, "duration_s": st.duration_s,
            "swing_s": st.swing_s, "stride_m": st.stride_m, "peak_toe_m": st.peak_toe_m,
            "mfc_m": st.mfc_m, "i0": st.i0, "i1": st.i1, "method": st.method,
            "diag": _jsonable(st.diag), "metrics": _jsonable(st.metrics),
            "events": _jsonable(st.events), "flags": list(st.flags),
            "methods": {n: {"stride_m": tr.stride_m, "peak_toe_m": tr.peak_toe_m,
                            "mfc_m": tr.mfc_m, "land": tr.land, "metrics": _jsonable(tr.metrics)}
                        for n, tr in st.traj.items()}})
    if paths:
        for name, chain in walk.chains().items():
            out[name] = {"t": chain.t.tolist(), "state": list(chain.state),
                         "sensor": chain.sensor.tolist(), "heel": chain.heel.tolist(),
                         "ball": chain.ball.tolist(), "toe": chain.toe.tolist(),
                         "starts": list(chain.starts), "ids": list(chain.ids),
                         "mfc_pts": chain.mfc_pts.tolist()}
    return out


# -- the live recorder -------------------------------------------------------
def _steps_word(n):
    return "{} step{}".format(n, "" if n == 1 else "s")


class StepRecorder:
    """idle -> armed (G) -> recording (foot leaves flat) -> armed again, until
    cfg.STEP_COUNT steps are done -> idle with a WalkResult. The flat that ends a
    step is the flat the next one starts from, so the pad is carried over."""

    def __init__(self):
        self.state = "idle"
        self.msg = "press G to record {}".format(_steps_word(cfg.STEP_COUNT))
        self.result = None                   # latest WalkResult, replaced whole
        self.steps = []                      # StepResults of the current run
        self.target = cfg.STEP_COUNT         # steps this run records (set when G arms it)
        self.count = 0                       # steps recorded since start
        self.run_id = 0                      # +1 on every G press that arms or is refused: the UI opens its window
        self.on_publish = None               # callback(walk, step_log) when a run is published
        self._step_log = []                  # [(rows, mount)] of the finished steps of this run
        self._g_mag = None
        self._pad = deque()
        self._pre = []                       # older flat rows than the pad of a step: only used if it needs a toe-phase repair
        self._rows = []
        self._seen_swing = False
        self._flat_since = None
        self._last_t = None
        self._ground_z = None
        self._foot = None

    def status(self):
        """Short text for the status panel."""
        n = len(self.steps)
        if self.state == "recording":
            return "recording {}/{}".format(n + 1, self.target)
        if self.state == "armed":
            return "armed" if not n else "{}/{} done".format(n, self.target)
        return "{} recorded".format(_steps_word(n)) if self.result is not None else "press G"

    def toggle(self, blocker):
        """G pressed. blocker is "" when the foot model is live, else why not."""
        if self.state != "idle":
            self.cancel("stopped" if self.steps else "cancelled")
        elif blocker:
            self.msg = "cannot record: " + blocker
            self.run_id += 1                 # the window opens to show why
        else:
            self.result = None               # a new run replaces the shown one
            self.steps = []
            self._step_log = []
            self.target = max(1, int(cfg.STEP_COUNT))
            self.run_id += 1
            self._reset("armed", "armed: stand flat, then walk {}".format(
                _steps_word(self.target)))

    def cancel(self, why):
        """Stop a run. Steps already finished are kept and published."""
        if self.steps:
            self._publish("{}, kept {} of {}".format(why, len(self.steps), self.target))
        else:
            self._reset("idle", why)

    def _reset(self, state, msg, seed=()):
        self.state, self.msg = state, msg
        self._pad = deque(seed)
        self._pre = []
        self._rows = []
        self._seen_swing = False
        self._flat_since = None
        self._last_t = None

    @staticmethod
    def _pad_s():
        """How much flat the armed recorder keeps: the step's own pad, or the longer one the
        toe-phase repair may need (STEP_TOE_REPAIR_PAD_S)."""
        return max(cfg.STEP_PAD_S, cfg.STEP_TOE_REPAIR_PAD_S if cfg.STEP_TOE_REPAIR else 0.0)

    def _trailing_flat(self):
        """The flat rows at the end of the recording (up to the pad): the start
        of whatever comes next."""
        rows = self._rows
        j = len(rows)
        while j > 0 and rows[j - 1][2] == "flat":
            j -= 1
        tail = rows[j:]
        if not tail:
            return []
        return [r for r in tail if r[0] >= tail[-1][0] - self._pad_s()]

    def _short_pad(self):
        """The newest STEP_PAD_S of the pad: what a step starts from unless it needs a repair."""
        t_end = self._pad[-1][0]
        return [r for r in self._pad if r[0] >= t_end - cfg.STEP_PAD_S]

    def _publish(self, msg):
        self.result = build_walk(self.steps)
        print(self.result.summary())
        from . import readout                       # here: readout imports this module
        print("\n".join(readout.lines(self.result)))
        if self.on_publish is not None:
            self.on_publish(self.result, list(self._step_log))
        self._reset("idle", msg)

    def sample(self, t, dt, foot, rot, omega_b, lin, pos, vel, acc_b=None, g_mag=None):
        """One foot-model sample (foot is the FootModel, read for its state,
        points and floor height). acc_b is the calibrated body-frame accel and
        g_mag the gravity magnitude in use (so lin can be recomputed offline)."""
        if self.state == "idle":
            return
        self._foot = foot
        self._ground_z = foot.ground_z
        self._g_mag = g_mag
        foot_state = foot.state
        row = (t, dt, foot_state, lin, pos, vel, foot.pts, rot, omega_b,
               acc_b, foot.anchor, foot.mtp0, foot.lift_t, foot.toe_dir)
        if self._last_t is not None and t - self._last_t > cfg.STEP_GAP_S:
            self._reset("armed", "data gap, armed again")
        self._last_t = t

        if self.state == "armed":
            if foot_state == "flat":
                self._pad.append(row)
                while self._pad[0][0] < t - self._pad_s():
                    self._pad.popleft()
            elif self._pad and self._pad[-1][0] - self._short_pad()[0][0] >= cfg.STEP_MIN_FLAT_S:
                short = self._short_pad()
                self._pre = list(self._pad)[:len(self._pad) - len(short)]
                self._rows = short + [row]
                self._pad.clear()
                self._seen_swing = foot_state == "swing"
                self._flat_since = None
                self.state = "recording"
                self.msg = "recording step {}/{}...".format(len(self.steps) + 1, self.target)
            else:
                self._pad.clear()
            return

        self._rows.append(row)
        if t - self._rows[0][0] > cfg.STEP_MAX_S:
            self._reset("armed", "step took too long, armed again")
            return
        if foot_state == "swing":
            self._seen_swing = True
        if foot_state != "flat":
            self._flat_since = None
            return
        if self._flat_since is None:
            self._flat_since = t
        if t - self._flat_since < cfg.STEP_END_HOLD_S:
            return
        if not self._seen_swing:
            self._reset("armed", "no swing seen, armed again", self._trailing_flat())
            return
        self._finish()

    def _finish(self):
        foot = self._foot
        mount = {"C": foot.C.copy(), "L2": foot.cal.foot_L2, "L1": foot.cal.foot_L1,
                 "y": cfg.IMU_LATERAL_M, "r": {k: v.copy() for k, v in foot.r.items()},
                 "g_mag": self._g_mag}
        seed = self._trailing_flat()
        rows = self._rows
        if self._pre and swing.toe_phase_missing([r[2] for r in rows]):
            rows = self._pre + self._rows           # the push-off was not seen: the repair wants the still flat before it
        try:
            res = process_step(rows, self._ground_z, mount)
        except ValueError as exc:
            self._reset("armed", "{}, armed again".format(exc), seed)
            return
        self.count += 1
        self.steps.append(res)
        self._step_log.append((list(rows), mount))
        done = len(self.steps)
        d, m = res.diag, res.metrics
        fit = d.get("mount_fit")
        mfcs = "  ".join("{} {:.0f}".format(SHORT.get(n, n), tr.mfc_m * 1000.0)
                         for n, tr in res.traj.items())
        print("[step {}/{}] stride {:.3f} m  {:.2f} s  toe peak {:.0f} mm  MFC? {:.0f} mm ({})  "
              "start v ({}) A {} B {} (gap {:.0f} mm/s)  landing v gap {:.0f} mm/s  "
              "landing height error {:+.0f} mm  leftover accel {:+.1f}/{:.1f} mg  IMU fit {}{}".format(
                  done, self.target, res.stride_m, res.duration_s, res.peak_toe_m * 1000.0,
                  res.mfc_m * 1000.0, mfcs, d["start_method"], np.round(d["v_lift_A"], 3),
                  np.round(d["v_lift_B"], 3), d["dv_lift_mms"], d["dv_land_mms"],
                  d["land_dz_m"] * 1000.0, m["az_mg"], m["ah_mg"],
                  "{:.0f}/{:.0f} mm (model {:.0f}/{:.0f}, rms {:.0f} mm/s)".format(
                      fit["x_m"] * 1000, fit["z_m"] * 1000, cfg.IMU_FROM_HEEL_M * 1000,
                      cfg.IMU_ABOVE_SOLE_M * 1000, fit["rms_mms"]) if fit
                  else d["mount_fit_why"] or "-",
                  "  FLAGS: " + "; ".join(res.flags) if res.flags else ""))
        if done >= self.target:
            self._publish("{} recorded, press G for another".format(_steps_word(done)))
        else:
            self._reset("armed", "step {}/{} recorded, keep walking".format(done, self.target),
                        seed)
