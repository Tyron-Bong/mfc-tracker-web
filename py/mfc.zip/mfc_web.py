"""The web app's bridge into the receiver package (receiver/mfc, bundled with the page by
tools/build_web.py). It runs in the browser, in a worker, under Pyodide.

The page records the session itself, record by record, in the format of mfc/session.py, and
hands this module the very bytes it wrote. Live.feed() runs them through session.Replayer, the
body of session.replay, so what the tablet shows after a G is exactly what a PC replay of that
session gives (tools/check_web_bridge.py checks it on real sessions).

Values cross to JavaScript as JSON strings (strict: no NaN, None instead). The receiver's
console lines (prints) are kept and handed over by state(), for the page's log.
"""

import contextlib
import io
import json
import math
import os
import struct
import tempfile

import numpy as np

from mfc import config as cfg
from mfc import gait, readout
from mfc import session as sess
from mfc.wire import FLAG_FSR, FLAG_IMU, FLAG_MAG

WEB_VERSION = "2026.10.15-a"
WORK = os.path.join(tempfile.gettempdir(), "mfc_web")   # Pyodide: /tmp, in memory
_REC = struct.Struct("<BdI")


def _clean(x):
    """JSON-safe: numpy to lists, NaN and inf to None, floats rounded to 0.1 mm / 0.1 ms."""
    if isinstance(x, dict):
        return {str(k): _clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_clean(v) for v in x]
    if isinstance(x, np.ndarray):
        return _clean(x.tolist())
    if isinstance(x, (np.floating, float)):
        v = float(x)
        return None if not math.isfinite(v) else round(v, 4)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.bool_):
        return bool(x)
    return x


def _dumps(obj):
    return json.dumps(_clean(obj), allow_nan=False)


class _Log(io.TextIOBase):
    """stdout while the receiver runs: complete lines are kept for the page."""

    def __init__(self):
        self.lines, self._part = [], ""

    def write(self, s):
        self._part += s
        while "\n" in self._part:
            line, self._part = self._part.split("\n", 1)
            if line.strip():
                self.lines.append(line)
        return len(s)

    def take(self):
        out, self.lines = self.lines, []
        return out


def as_bytes(x):
    """bytes from what JavaScript passes (a Uint8Array arrives as a JsProxy)."""
    return x.to_bytes() if hasattr(x, "to_bytes") else bytes(x)


def record_stream(data):
    """The bare record stream (what Live.feed takes) of a session file: the page's .mfcraw or a
    PC's packed .mfcrec. For playing a saved session through the live path (demo, tests)."""
    data = bytes(data)
    if data[:len(sess.MAGIC)] == sess.MAGIC:
        return data[len(sess.MAGIC) + 2:]
    return b"".join(_REC.pack(k, t, len(p)) + p for k, t, p in sess.unpack_records(data))


def parse_records(buf):
    """(type, t, payload) records from the bytes of a session's record stream (no file head)."""
    mv, off, out = memoryview(buf), 0, []
    while off + _REC.size <= len(mv):
        kind, t, n = _REC.unpack_from(mv, off)
        off += _REC.size
        if off + n > len(mv):
            raise ValueError("a record runs past the end of the batch")
        out.append((kind, t, bytes(mv[off:off + n])))
        off += n
    return out


class Live:
    """One per connection (or per demo playback). cal_json: the calibration file's text, or ""
    for none yet. The Processor reads it and its calibrations (R, U, T, I, C) rewrite it;
    calibration() hands the new text back for the page to keep."""

    def __init__(self, cal_json=""):
        os.makedirs(WORK, exist_ok=True)
        self.cal_path = os.path.join(WORK, "accel_drift_variables.json")
        if os.path.exists(self.cal_path):
            os.remove(self.cal_path)
        cal = json.loads(cal_json) if cal_json else None
        self.log = _Log()
        self.walk, self.walk_id, self.records = None, 0, 0
        self.error = None
        with contextlib.redirect_stdout(self.log):
            self.rp = sess.Replayer({"calibration_start": cal}, cal_path=self.cal_path)
        self.proc = self.rp.proc
        self._cal_seen = self._read_cal()

    def _read_cal(self):
        try:
            with open(self.cal_path, "r") as fh:
                return fh.read()
        except OSError:
            return ""

    def feed(self, buf):
        """A batch of records, the bytes the page appended to the session. Returns the number
        of walks published by it."""
        new = 0
        with contextlib.redirect_stdout(self.log):
            for kind, t, payload in parse_records(bytes(buf)):
                self.records += 1
                try:
                    walk = self.rp.feed(kind, t, payload)
                except Exception as exc:                 # noqa: BLE001, shown on the page; the recording goes on
                    self.error = "{}: {} (at {:.2f} s)".format(type(exc).__name__, exc, t)
                    print("[web] processing error:", self.error)
                    continue
                if walk is not None:
                    self.walk = walk
                    self.walk_id += 1
                    new += 1
        return new

    def calibration(self):
        """The calibration file's text if a calibration rewrote it since the last call, else None."""
        now = self._read_cal()
        if now and now != self._cal_seen:
            self._cal_seen = now
            return now
        return None

    def step_count(self, n):
        cfg.STEP_COUNT = max(1, min(50, int(n)))

    def state(self):
        p, s, d, t = self.proc, self.proc.stance, self.rp.dec, self.rp.text
        out = {
            "state": p.state, "msg": p.state_msg, "foot_active": p.foot_active,
            "stance": s.stance, "fsr": s.raw, "fsr_on": s.on, "fsr_cal_ok": s.cal_ok,
            "fsr_calibrating": s.calibrating, "fsr_cal_msg": s.cal_msg,
            "rates": {"imu": d.rates[FLAG_IMU], "mag": d.rates[FLAG_MAG], "fsr": d.rates[FLAG_FSR]},
            "dropped": d.dropped, "frames": d.frames_ok, "batt": d.batt,
            "imu_gaps": len(p.imu_gaps), "records": self.records, "t": self.rp.t,
            "status": {"filters": t.filters, "ring": t.fsr_ring, "sync_us": t.fsr_latency_us,
                       "sync_n": t.sync_n, "sync_sd_us": t.sync_sd_us,
                       "imu_fifo": t.imu_fifo, "mag_fifo": t.mag_fifo, "fifo": t.fifo_health,
                       "sensors": t.sensors},
            "step": {"state": p.step.state, "msg": p.step.msg, "status": p.step.status(),
                     "done": len(p.step.steps), "target": p.step.target, "count": cfg.STEP_COUNT,
                     "pending": bool(p.request_step)},
            "walk_id": self.walk_id, "error": self.error, "log": self.log.take(),
        }
        if p.out:
            row = p.out[-1]
            out["attitude"] = {"roll": row[1], "pitch": row[2], "yaw": row[3]}
        if p.state == "poses":
            pc = p.pose_cal
            out["poses"] = {"n": len(pc.poses), "target": cfg.POSE_TARGET, "msg": pc.msg}
        if p.state == "footcal" and p.foot_cal.steps:
            fc = p.foot_cal
            out["footcal"] = {"step": fc.step + 1, "of": len(fc.steps), "msg": fc.msg, "angle": fc.angle}
        return _dumps(out)

    def result(self, since_id=-1):
        """The last published walk as JSON (None if there is none newer than since_id)."""
        if self.walk is None or self.walk_id <= since_id:
            return None
        return walk_json(self.walk, self.walk_id)

    def status_block(self):
        """The sidecar's "status", as SessionWriter writes it."""
        t = self.rp.text
        return _dumps({"filters": dict(t.filters), "sensors": t.sensors, "imu_fifo": t.imu_fifo,
                       "mag_fifo": t.mag_fifo, "fifo_health": t.fifo_health})


def open_session(data, sidecar_json, arm_all=False):
    """Replay a saved session (an .mfcraw as the page writes it, or a PC's packed .mfcrec)
    with session.replay itself. Returns {"walks": [walk JSON...], "log": [...]} as JSON."""
    os.makedirs(WORK, exist_ok=True)
    path = os.path.join(WORK, "open.mfcrec" if bytes(data[:7]) != sess.MAGIC else "open.mfcraw")
    for p in ("open.mfcrec", "open.mfcraw"):
        for q in (p, p + ".json"):
            if os.path.exists(os.path.join(WORK, q)):
                os.remove(os.path.join(WORK, q))
    with open(path, "wb") as fh:
        fh.write(bytes(data))
    with open(path + ".json", "w") as fh:
        fh.write(sidecar_json)
    log = _Log()
    with contextlib.redirect_stdout(log):
        _proc, results = sess.replay(path, arm_all=bool(arm_all))
    walks = [json.loads(walk_json(w, i + 1)) for i, (_t, w) in enumerate(results)]
    return json.dumps({"walks": walks, "log": log.take()}, allow_nan=False)


def _chain_json(ch):
    return {"t": ch.t, "state": list(ch.state), "sensor": ch.sensor, "heel": ch.heel, "ball": ch.ball,
            "toe": ch.toe, "starts": list(ch.starts), "ids": list(ch.ids), "mfc_pts": ch.mfc_pts,
            "land_pts": ch.land_pts,
            "events": [{"i": int(k), "kind": kind, "point": point} for k, kind, point in gait.chain_events(ch.state)]}


def walk_json(walk, walk_id):
    vals = readout.step_values(walk)
    steps = []
    for s, v in zip(walk.steps, vals):
        steps.append({"stride_m": s.stride_m, "mfc_m": s.mfc_m, "peak_toe_m": s.peak_toe_m,
                      "swing_s": s.swing_s, "duration_s": s.duration_s, "flags": list(s.flags),
                      "short_flags": [readout.short_flag(f) for f in s.flags],
                      "foot_max_mm": v["foot_max"], "heel_max_mm": v["heel_max"], "turn_deg": v["turn"],
                      "lands": v["lands"],
                      "mfc_by_method": {n: tr.mfc_m for n, tr in s.traj.items()}})
    parts = readout.readout(walk, vals=vals, short=True)
    return _dumps({
        "id": walk_id, "method": walk.method, "steps": steps,
        "chain": _chain_json(walk.chain),
        "readout": {"steps": parts[0], "timeline": parts[1], "summary": parts[2]},
        "readout_full": readout.summary_table(walk, vals),
    })
